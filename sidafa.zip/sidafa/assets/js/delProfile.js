/**
 * @author abduelmu
 */

jQuery(document).ready(function(){
	
	jQuery(document).on("click", ".deleteProfile", function(){
		var profileID = $(this).data("profileid"),
			hitURL = baseURL + "deleteProfile",
			currentRow = $(this);
		
		var confirmation = confirm("Are you sure to delete this data ?");
		
		if(confirmation)
		{
			jQuery.ajax({
			type : "POST",
			dataType : "json",
			url : hitURL,
			data : { profileID : profileID } 
			}).done(function(data){
				console.log(data);
				currentRow.parents('tr').remove();
				if(data.status = true) { alert("Profile successfully deleted"); }
				else if(data.status = false) { alert("Profile deletion failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});
	
	
	jQuery(document).on("click", ".searchList", function(){
		
	});
	
});