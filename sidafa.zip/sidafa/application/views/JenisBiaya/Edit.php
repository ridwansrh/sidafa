<?php

$id_biaya = '';
$id_kelas = '';
$jenis_biaya = '';
$harga = '';
$id_tahun_pelajaran = '';
$id_aktif = '';

if(!empty($jenisbiayaInfo))
{
    foreach ($jenisbiayaInfo as $jb)
    {
        $id_biaya = $jb->id_biaya;
        $id_kelas = $jb->id_kelas;
        $jenis_biaya = $jb->jenis_biaya;
        $harga = $jb->harga;
        $id_tahun_pelajaran = $jb->id_tahun_pelajaran;
        $id_aktif = $jb->id_aktif;
    }
}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Jenis Biaya Management
        <small>Add / Edit Jenis Biaya</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>edit-data-jenisbiaya" method="post" id="EditJenisBiaya" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="kelas">Kelas</label>
                                        <select class="form-control required" id="kelas" name="kelas">
                                        <option value="0">Kelas</option>
                                            <?php
                                            if(!empty($kelas))
                                            {
                                                foreach ($kelas as $kl)
                                                {
                                                    ?>
                                                    <option value="<?php echo $kl->id_kelas; ?>" <?php if($kl->id_kelas == $id_kelas) {echo "selected=selected";} ?>><?php echo $kl->nama_kelas ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="jenis_biaya">Jenis Biaya</label>
                                        <input type="text" class="form-control required" id="jenis_biaya" placeholder="Jenis Biaya" name="jenis_biaya" value="<?php echo $jenis_biaya; ?>" maxlength="50">
                                        <input type="hidden" value="<?php echo $id_biaya; ?>" name="id_biaya" id="id_biaya" />    
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="harga">Harga (Rp)</label>
                                        <input type="text" class="form-control required" id="harga" placeholder="Nominal" name="harga" value="<?php echo $harga; ?>" maxlength="20">    
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="tapel">Tahun Pelajaran</label>
                                        <select class="form-control required" id="tapel" name="tapel">
                                        <option value="0">Tahun Pelajaran</option>
                                            <?php
                                            if(!empty($tapel))
                                            {
                                                foreach ($tapel as $tp)
                                                {
                                                    ?>
                                                    <option value="<?php echo $tp->id_tahun_pelajaran; ?>" <?php if($tp->id_tahun_pelajaran == $id_tahun_pelajaran) {echo "selected=selected";} ?>><?php echo $tp->tahun_pelajaran ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                            <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status">Keaktifan</label>
                                        <select class="form-control required" id="status" name="status">
                                        <option value="0">Pilih Keaktifan</option>
                                            <?php
                                            if(!empty($status))
                                            {
                                                foreach ($status as $ak)
                                                {
                                                    ?>
                                                    <option value="<?php echo $ak->id_aktif; ?>" <?php if($ak->id_aktif == $id_aktif) {echo "selected=selected";} ?>><?php echo $ak->keaktifan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-flat btn-primary" value="Simpan" />
                            <a class="btn btn-flat btn-danger" href="<?php echo base_url(); ?>list-jenisbiaya"><i></i>Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script type="text/javascript">
    $(document).ready(function(){
    
    var EditJenisBiayaForm = $("#EditJenisBiaya");
    
    var validator = EditJenisBiayaForm.validate({
        
        rules:{
            kelas : { required : true, selected : true},
            jenis_biaya :{ required : true },
            harga : { required : true, numeric : true },
            tapel : { required : true, selected : true},
            status : { required : true, selected : true}
        },
        messages:{
            kelas : { required : "This field is required", selected : "Please select atleast one option" } ,
            jenis_biaya :{ required : "This field is required" },
            harga : { required : "This field is required", numeric : "Please input numerial only"},
            tapel : { required : "This field is required", selected : "Please select atleast one option" } ,
            status : { required : "This field is required", selected : "Please select atleast one option" }         
        }
    });
});
</script>