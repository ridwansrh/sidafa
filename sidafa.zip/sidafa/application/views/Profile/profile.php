<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> Profile Madrasah
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>addP"><i class="fa fa-plus"></i> Add New</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Profile List</h3>
                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="table" class="table table table-bordered table-hover">
                    <thead>
                    <tr>
                      <th class="text-center" width="5">NO</th>
                      <th class="text-center">NSM</th>
                      <th class="text-center">NPSN</th>
                      <th class="text-center">Nama Madrasah</th>
                      <th class="text-center">Alamat</th>
                      <th class="text-center">Actions</th>
                    </tr>
                    </thead>
                    <?php
                    if(!empty($profileRecords))
                    {
                      $i=1;
                        foreach($profileRecords as $record)
                        {
                    ?>
                    <tr>
                      <td class="text-center"><?php echo $i ?></td>
                      <td><?php echo $record->nsm ?></td>
                      <td><?php echo $record->npsn ?></td>
                      <td><?php echo $record->namamadrasah ?></td>
                      <td><?php echo $record->alamat ?></td>
                      <td class="text-center">
                          <a class="btn btn-sm btn-info" href="<?php echo base_url().'editP/'.$record->profileID; ?>"><i class="fa fa-pencil"></i></a>
                          <a class="btn btn-sm btn-danger deleteProfile" href="#" data-profileid="<?php echo $record->profileID; ?>"><i class="fa fa-trash"></i></a>
                      </td>
                    </tr>
                    <?php
                    $i++;
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
  jQuery(document).ready(function(){
  
  jQuery(document).on("click", ".deleteProfile", function(){
    var profileID = $(this).data("profileid"),
      hitURL = baseURL + "deleteProfile",
      currentRow = $(this);
    
    var confirmation = confirm("Are you sure to delete this data ?");
    
    if(confirmation)
    {
      jQuery.ajax({
      type : "POST",
      dataType : "json",
      url : hitURL,
      data : { profileID : profileID } 
      }).done(function(data){
        console.log(data);
        currentRow.parents('tr').remove();
        if(data.status = true) { alert("Profile successfully deleted"); }
        else if(data.status = false) { alert("Profile deletion failed"); }
        else { alert("Access denied..!"); }
      });
    }
  });
  
  
  jQuery(document).on("click", ".searchList", function(){
    
  });
  
});
</script>

<script type="text/javascript">
   $(document).ready(function() {
        //datatables
        table = $('#table').DataTable({ 
        });
    }); 
</script>

