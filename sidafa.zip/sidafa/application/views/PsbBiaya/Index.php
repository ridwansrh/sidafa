<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Data Jenis Biaya PSB
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-flat btn-primary" href="<?php echo base_url(); ?>add-new-biaya-psb"><i class="fa fa-plus"></i> Add New</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Daftar Jenis Biaya PSB</h3>
                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="table" class="table table table-bordered table-hover">
                    <thead>
                    <tr>
                      <th class="text-center" width="5">NO</th>
                      <th class="text-center">JENIS BIAYA</th>
                      <th class="text-center">HARGA</th>
                      <th class="text-center">TAHUN PELAJARAN</th>
                      <th class="text-center">KELAS</th>
                      <th class="text-center">KEAKTIFAN</th>
                      <th class="text-center">Actions</th>
                    </tr>
                    </thead>
                    <?php
                    if(!empty($PsbBiayaRecords))
                    { $i=1;
                        foreach($PsbBiayaRecords as $record) 
                        {
                    ?>
                    <tr>
                      <td class="text-center"><?php echo $i ?>.</td>
                      <td class="text-center"><?php echo $record->jenis_biaya ?></td>
                      <td class="text-center"><?php echo 'Rp. '.number_format($record->harga) ?></td>
                      <td class="text-center"><?php echo $record->tahun_pelajaran ?></td>
                      <td class="text-center"><?php echo $record->nama_kelas ?></td>
                      <td class="text-center"><?php echo $record->keaktifan ?></td>
                      <td class="text-center">
                          <a class="btn btn-flat btn-sm btn-info" href="<?php echo base_url().'edit-biaya-psb/'.$record->id_biaya_psb; ?>"><i class="fa fa-pencil"></i></a>
                          <a class="btn btn-flat btn-sm btn-danger deletePsbBiaya" href="#" data-id_biaya_psb="<?php echo $record->id_biaya_psb; ?>"><i class="fa fa-trash"></i></a>
                      </td>
                    </tr>
                    <?php
                    $i++;
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
  jQuery(document).ready(function(){
  
  jQuery(document).on("click", ".deletePsbBiaya", function(){
    var id_biaya_psb = $(this).data("id_biaya_psb"),
      hitURL = baseURL + "deletePsbBiaya",
      currentRow = $(this);
    
    var confirmation = confirm("Are you sure to delete this data ?");
    
    if(confirmation)
    {
      jQuery.ajax({
      type : "POST",
      dataType : "json",
      url : hitURL,
      data : { id_biaya_psb : id_biaya_psb } 
      }).done(function(data){
        console.log(data);
        currentRow.parents('tr').remove();
        if(data.status = true) { alert("Data successfully deleted"); }
        else if(data.status = false) { alert("Data deletion failed"); }
        else { alert("Access denied..!"); }
      });
    }
  });
  
  
  jQuery(document).on("click", ".searchList", function(){
    
  });
  
});
</script>

<script type="text/javascript">
   $(document).ready(function() {
        //datatables
        table = $('#table').DataTable({ 
        });
    }); 
</script>

