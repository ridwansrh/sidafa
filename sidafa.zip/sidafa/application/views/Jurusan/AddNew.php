<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Data Management
        <small>Add / Edit Data</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" id="AddJurusan" action="<?php echo base_url() ?>add-data-jurusan" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="kode_jurusan">Kode Jurusan</label>
                                        <input type="text" class="form-control required" id="kode_jurusan" placeholder="Kode Jurusan" name="kode_jurusan" maxlength="12">
                                    </div>
                                </div>    
                            	<div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status">Keaktifan</label>
                                        <select class="form-control" id="status" name="status">
                                        <option value="0">Pilih Keaktifan</option>
                                            <?php
                                            if(!empty($status))
                                            {
                                                foreach ($status as $ak)
                                                {
                                                    ?>
                                                    <option value="<?php echo $ak->id_aktif; ?>"><?php echo $ak->keaktifan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                            	</div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="nama_jurusan">Nama Jurusan</label>
                                        <input type="text" class="form-control required" id="nama_jurusan" placeholder="Keterangan" name="nama_jurusan" maxlength="50">
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-flat btn-primary" value="Simpan" />
                            <input type="reset" class="btn btn-flat btn-warning" value="Reset" />
                            <a class="btn btn-flat btn-danger" href="<?php echo base_url(); ?>list-jurusan"><i></i>Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script type="text/javascript">
	$(document).ready(function(){
	
	var AddJurusanForm = $("#AddJurusan");
	
	var validator = AddJurusanForm.validate({
		
		rules:{
			kode_jurusan :{ required : true },
			nama_jurusan : { required : true },
            status : { required : true, selected : true }
		},
		messages:{
			kode_jurusan :{ required : "This field is required"},
			nama_jurusan : { required : "This field is required"},
            status : { required : "This field is required", selected : "Please select atleast one option"}		
		}
	});
});
</script>