<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Data Jurusan
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                    <a class="btn btn-flat btn-primary" href="<?php echo base_url(); ?>add-new-jurusan"><i class="fa fa-plus"></i> Add New</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Daftar Jurusan</h3>
                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="table" class="table table table-bordered table-hover">
                    <thead>
                    <tr>
                      <th class="text-center" width="5">NO</th>
                      <th class="text-center">KODE JURUSAN</th>
                      <th class="text-center">NAMA JURUSAN</th>
                      <th class="text-center">KEAKTIFAN</th>
                      <th class="text-center">Actions</th>
                    </tr>
                    </thead>
                    <?php
                    if(!empty($jurusanRecords))
                    {	$i=1;
                        foreach($jurusanRecords as $record) 
                        {
                    ?>
                    <tr>
                      <td class="text-center"><?php echo $i ?></td>
                      <td class="text-center"><?php echo $record->kode_jurusan ?></td>
                      <td class="text-center"><?php echo $record->nama_jurusan ?></td>
                      <td class="text-center"><?php echo $record->keaktifan ?></td>
                      <td class="text-center">
                          <a class="btn btn-flat btn-sm btn-info" href="<?php echo base_url().'edit-jurusan/'.$record->id_jurusan; ?>"><i class="fa fa-pencil"></i></a>
                          <a class="btn btn-flat btn-sm btn-danger deleteJurusan" href="#" data-id_jurusan="<?php echo $record->id_jurusan; ?>"><i class="fa fa-trash"></i></a>
                      </td>
                    </tr>
                    <?php
                    $i++;
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
  jQuery(document).ready(function(){
  
  jQuery(document).on("click", ".deleteJurusan", function(){
    var id_jurusan = $(this).data("id_jurusan"),
      hitURL = baseURL + "deleteJurusan",
      currentRow = $(this);
    
    var confirmation = confirm("Are you sure to delete this data ?");
    
    if(confirmation)
    {
      jQuery.ajax({
      type : "POST",
      dataType : "json",
      url : hitURL,
      data : { id_jurusan : id_jurusan } 
      }).done(function(data){
        console.log(data);
        currentRow.parents('tr').remove();
        if(data.status = true) { alert("Data successfully deleted"); }
        else if(data.status = false) { alert("Data deletion failed"); }
        else { alert("Access denied..!"); }
      });
    }
  });
  
  
  jQuery(document).on("click", ".searchList", function(){
    
  });
  
});
</script>

<script type="text/javascript">
   $(document).ready(function() {
        //datatables
        table = $('#table').DataTable({ 
        });
    }); 
</script>

