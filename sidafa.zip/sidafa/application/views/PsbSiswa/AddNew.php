<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Data Management
        <small>Add / Edit Data</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-11">
              <!-- general form elements -->
                
                
                
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" id="AddPsbSiswa" action="<?php echo base_url() ?>add-data-siswa-psb" method="post" role="form">
                        <div class="box-body">
                            <!--Biodata-->
                            <h4><strong><center>BIODATA SISWA</center></strong></h4>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nisn">NISN *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-credit-card"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nisn" placeholder="NISN Siswa" name="nisn" maxlength="10">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nik">NIK *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-cc-mastercard"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nik" placeholder="NIK Siswa" name="nik" maxlength="16">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama">Nama Lengkap *</label>
                                        <input type="text" class="form-control required" id="nama" placeholder="Nama Lengkap Siswa" name="nama" maxlength="100">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" class="form-control" value="dafa123" id="password" placeholder="Password" name="password" maxlength="100" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="tmp_lahir">Tempat Lahir *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-pencil-square-o"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="tmp_lahir" placeholder="Tempat Lahir Siswa" name="tmp_lahir" maxlength="20">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="tgl_lahir">Tanggal Lahir *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                          <input type="text" class="form-control required" placeholder="dd/mm/yyyy" data-inputmask="'alias': 'mm/dd/yyyy'" name="tgl_lahir">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="gender">Jenis Kelamin *</label>
                                        <select class="form-control required" id="gender" name="gender">
                                        <option value="0">Pilih Jenis Kelamin</option>
                                            <?php
                                            if(!empty($gender))
                                            {
                                                foreach ($gender as $jk)
                                                {
                                                    ?>
                                                    <option value="<?php echo $jk->id_gender; ?>"><?php echo $jk->gender ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="tahun_masuk">Tahun Masuk</label>
                                        <input type="text" class="form-control" id="tahun_masuk" placeholder="2020" value="2020" name="tahun_masuk" maxlength="10" disabled>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="agama">Agama</label>
                                        <input type="text" class="form-control" id="agama" placeholder="ISLAM" name="agama" value="1" maxlength="10" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="anak_ke">Anak Ke *</label>
                                        <input type="text" class="form-control required" id="anak_ke" placeholder="Anak Ke" name="anak_ke" maxlength="2">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="jml_sdr">Jumlah Saudara *</label>
                                        <input type="text" class="form-control required" id="jml_sdr" placeholder="Jumlah Saudara Siswa" name="jml_sdr" maxlength="2">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="jalur_masuk">Jalur Masuk *</label>
                                        <select class="form-control required" id="jalur_masuk" name="jalur_masuk">
                                        <option value="0">Pilih Jalur Masuk</option>
                                            <?php
                                            if(!empty($jalur_masuk))
                                            {
                                                foreach ($jalur_masuk as $jr)
                                                {
                                                    ?>
                                                    <option value="<?php echo $jr->id_jalur_masuk; ?>"><?php echo $jr->jalur_masuk ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="jurusan">Jurusan *</label>
                                        <select class="form-control required" id="jurusan" name="jurusan">
                                        <option value="0">Pilih Jurusan</option>
                                            <?php
                                            if(!empty($jurusan))
                                            {
                                                foreach ($jurusan as $jr)
                                                {
                                                    ?>
                                                    <option value="<?php echo $jr->id_jurusan; ?>"><?php echo $jr->nama_jurusan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="pondok">Pondok *</label>
                                        <select class="form-control required" id="pondok" name="pondok">
                                        <option value="0">Pilih Pondok</option>
                                            <?php
                                            if(!empty($pondok))
                                            {
                                                foreach ($pondok as $pd)
                                                {
                                                    ?>
                                                    <option value="<?php echo $pd->id_pondok; ?>"><?php echo $pd->nama_pondok ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="jenis_tinggal">Jenis Tinggal *</label>
                                        <select class="form-control required" id="jenis_tinggal" name="jenis_tinggal">
                                        <option value="0">Pilih Jenis Tinggal</option>
                                            <?php
                                            if(!empty($jenis_tinggal))
                                            {
                                                foreach ($jenis_tinggal as $jt)
                                                {
                                                    ?>
                                                    <option value="<?php echo $jt->id_jenis_tinggal; ?>"><?php echo $jt->jenis_tinggal ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="desa">Desa *</label>
                                        <input type="text" class="form-control required" id="desa" placeholder="Desa" name="desa" maxlength="20">
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="dukuh">Dukuh *</label>
                                        <input type="text" class="form-control required" id="dukuh" placeholder="Dukuh" name="dukuh" maxlength="20">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="rt">RT *</label>
                                        <input type="text" class="form-control required" id="rt" placeholder="000" name="rt" maxlength="3">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="rw">RW *</label>
                                        <input type="text" class="form-control required" id="rw" placeholder="000" name="rw" maxlength="3">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="kecamatan">Kecamatan *</label>
                                        <input type="text" class="form-control required" id="kecamatan" placeholder="Kecamatan" name="kecamatan" maxlength="30">
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="kabupaten">Kabupaten *</label>
                                        <input type="text" class="form-control required" id="kabupaten" placeholder="Kabupaten" name="kabupaten" maxlength="30">
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="provinsi">Provinsi *</label>
                                        <input type="text" class="form-control required" id="provinsi" placeholder="Provinsi" name="provinsi" maxlength="30">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="kode_pos">Kode Pos *</label>
                                        <input type="text" class="form-control required" id="kode_pos" placeholder="Kode Pos" name="kode_pos" maxlength="6">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="jarak_tinggal">Jarak Tinggal *</label>
                                        <select class="form-control required" id="jarak_tinggal" name="jarak_tinggal">
                                        <option value="0">Pilih Jarak Tinggal</option>
                                            <?php
                                            if(!empty($jarak_tinggal))
                                            {
                                                foreach ($jarak_tinggal as $jt)
                                                {
                                                    ?>
                                                    <option value="<?php echo $jt->id_jarak; ?>"><?php echo $jt->jarak_tinggal ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="transportasi">Transportasi *</label>
                                        <select class="form-control required" id="transportasi" name="transportasi">
                                        <option value="0">Pilih Transportasi</option>
                                            <?php
                                            if(!empty($transportasi))
                                            {
                                                foreach ($transportasi as $ag)
                                                {
                                                    ?>
                                                    <option value="<?php echo $ag->id_transportasi; ?>"><?php echo $ag->transportasi ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="hobi">Hobi *</label>
                                        <select class="form-control required" id="hobi" name="hobi">
                                        <option value="0">Pilih Hobi</option>
                                            <?php
                                            if(!empty($hobi))
                                            {
                                                foreach ($hobi as $hb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $hb->id_hobi; ?>"><?php echo $hb->nama_hobi ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="citacita">Cita Cita *</label>
                                        <select class="form-control required" id="citacita" name="citacita">
                                        <option value="0">Pilih Cita Cita</option>
                                            <?php
                                            if(!empty($citacita))
                                            {
                                                foreach ($citacita as $ag)
                                                {
                                                    ?>
                                                    <option value="<?php echo $ag->id_cita_cita; ?>"><?php echo $ag->nama_cita_cita ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="hp_siswa">NO HP Siswa *</label>
                                        <input type="text" class="form-control required" id="hp_siswa" placeholder="NO HP Siswa" name="hp_siswa" maxlength="12">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="foto">FOTO</label>
                                        <input type="text" class="form-control" id="foto" placeholder="foto" name="foto" maxlength="20" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="no_kip">NO KIP</label>
                                        <input type="text" class="form-control" id="no_kip" placeholder="NO Kartu Indonesia Pintar" name="no_kip" maxlength="20">
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="no_kis">NO KIS</label>
                                        <input type="text" class="form-control" id="no_kis" placeholder="NO Kartu Indonesia Sehat" name="no_kis" maxlength="20">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_kartu_lain">NO KARTU LAIN</label>
                                        <input type="text" class="form-control" id="no_kartu_lain" placeholder="Nomor Kartu Lain" name="no_kartu_lain" maxlength="20">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="sekolah_asal">Asal Sekolah *</label>
                                        <select class="form-control required" id="sekolah_asal" name="sekolah_asal">
                                        <option value="0">Pilih Asal Sekolah</option>
                                            <?php
                                            if(!empty($sekolah_asal))
                                            {
                                                foreach ($sekolah_asal as $sa)
                                                {
                                                    ?>
                                                    <option value="<?php echo $sa->id_sekolah_asal; ?>"><?php echo $sa->sekolah_asal ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="nama_sekolah_asal">Nama Sekolah Asal *</label>
                                        <input type="text" class="form-control required" id="nama_sekolah_asal" placeholder="Nama Sekolah Asal" name="nama_sekolah_asal" maxlength="50">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="alamat_sekolah_asal">Alamat Sekolah Asal *</label>
                                        <input type="text" class="form-control required" id="alamat_sekolah_asal" placeholder="Alamat Sekolah Asal" name="alamat_sekolah_asal" maxlength="50">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_peserta_ujian">NO Peserta Ujian</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="no_peserta_ujian" placeholder="Nomor Peserta Ujian" name="no_peserta_ujian" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_ijazah">No Ijazah</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="no_ijazah" placeholder="Nomor Ijazah" name="no_ijazah" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_shun">NO SHUN</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="no_shun" placeholder="Nomor Surat Hasil Ujian Nasional" name="no_shun" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nilai_un">Nilai Rata-rata UN</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nilai_un" placeholder="Nilai Rata-rata Ujian Nasional" name="nilai_un" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_shuambn">NO SHUAMBN</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="no_shuambn" placeholder="Nilai Surat Hasil Ujian Akhir Madrasah Berstandar Nasional" name="no_shuambn" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nilai_uambn">Nilai UAMBN</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nilai_uambn" placeholder="Nilai Ujian Akhir Madrasah Berstandar Nasional" name="nilai_uambn" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Prestasi-->
                            <h3><center>PRESTASI SISWA</center></h3>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_empat_gasal">Peringkat Kelas IV Gasal</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_empat_gasal" placeholder="Peringkat ..." name="p_smt_empat_gasal" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_empat_genap">Peringkat Kelas IV Genap</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_empat_genap" placeholder="Peringkat ..." name="p_smt_empat_genap" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_lima_gasal">Peringkat Kelas V Gasal</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_lima_gasal" placeholder="Peringkat ..." name="p_smt_lima_gasal" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_lima_genap">Peringkat Kelas V Genap</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_lima_genap" placeholder="Peringkat ..." name="p_smt_lima_genap" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_enam_gasal">Peringkat Kelas VI Gasal</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_enam_gasal" placeholder="Peringkat ..." name="p_smt_enam_gasal" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_enam_genap">Peringkat Kelas VI Genap</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_enam_genap" placeholder="Peringkat ..." name="p_smt_enam_genap" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_satu">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_satu" placeholder="Prestasi Lainnya" name="prestasi_satu" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_dua">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_dua" placeholder="Prestasi Lainnya" name="prestasi_dua" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_tiga">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_tiga" placeholder="Prestasi Lainnya" name="prestasi_tiga" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_empat">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_empat" placeholder="Prestasi Lainnya" name="prestasi_empat" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_lima">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_lima" placeholder="Prestasi Lainnya" name="prestasi_lima" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_enam">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_enam" placeholder="Prestasi Lainnya" name="prestasi_enam" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Ayah-->
                            <br>
                            <h3><center>BIODATA AYAH</center></h3>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama_ayah_kandung">Nama Ayah Kandung *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nama_ayah_kandung" placeholder="Nama Ayah Kandung" name="nama_ayah_kandung" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5">                                
                                    <div class="form-group">
                                        <label for="nama_ayah_tiri">Nama Ayah Tiri</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user-md"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nama_ayah_tiri" placeholder="Nama Ayah Tiri" name="nama_ayah_tiri" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="nik_ayah">NIK Ayah</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-info"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nik_ayah" placeholder="NIK Ayah" name="nik_ayah" maxlength="16">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="thn_lahir_ayah">Tahun Lahir Ayah</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                          <input type="text" class="form-control" placeholder="yyyy" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask="thn_lahir_ayah">
                                        </div>
                                        <!--input type="text" class="form-control required" id="tgl_lahir" placeholder="Tanggal Lahir Siswa" name="tgl_lahir" maxlength="16"-->
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="pendidikan_ayah">Pendidikan Ayah</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-question-circle"></i>
                                        </div>
                                        <select class="form-control" id="pendidikan_ayah" name="pendidikan_ayah">
                                        <option value="0">Pilih Pendidikan Ayah</option>
                                            <?php
                                            if(!empty($pendidikan_ayah))
                                            {
                                                foreach ($pendidikan_ayah as $pena)
                                                {
                                                    ?>
                                                    <option value="<?php echo $pena->id_pendidikan_terakhir; ?>"><?php echo $pena->pendidikan_terakhir ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="pekerjaan_ayah">Pekerjaan Ayah</label>
                                        <select class="form-control" id="pekerjaan_ayah" name="pekerjaan_ayah">
                                        <option value="0">Pilih Pekerjaan Ayah</option>
                                            <?php
                                            if(!empty($pekerjaan_ayah))
                                            {
                                                foreach ($pekerjaan_ayah as $peka)
                                                {
                                                    ?>
                                                    <option value="<?php echo $peka->id_pekerjaan; ?>"><?php echo $peka->pekerjaan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="penghasilan_ayah">Penghasilan Ayah</label>
                                        <select class="form-control" id="penghasilan_ayah" name="penghasilan_ayah">
                                        <option value="0">Pilih Penghasilan Ayah</option>
                                            <?php
                                            if(!empty($penghasilan_ayah))
                                            {
                                                foreach ($penghasilan_ayah as $penga)
                                                {
                                                    ?>
                                                    <option value="<?php echo $penga->id_penghasilan; ?>"><?php echo $penga->penghasilan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="alamat_ayah">Alamat Ayah</label>
                                        <input type="text" class="form-control" id="alamat_ayah" placeholder="Alamat Ayah" name="alamat_ayah" maxlength="100">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="hp_ayah">Nomor HP Ayah</label>
                                        <input type="text" class="form-control" id="hp_ayah" placeholder="Nomor HP Ayah" name="hp_ayah" maxlength="12">
                                    </div>
                                </div>
                            </div> 
                            <!-- IBU-->
                            <br>
                            <h3><center>BIODATA IBU</center></h3>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama_ibu_kandung">Nama Ibu Kandung *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-female"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nama_ibu_kandung" placeholder="Nama Ibu Kandung" name="nama_ibu_kandung" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5">                                
                                    <div class="form-group">
                                        <label for="nama_ibu_tiri">Nama Ibu Tiri</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user-md"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nama_ibu_tiri" placeholder="Nama Ibu Tiri" name="nama_ibu_tiri" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="nik_ibu">NIK IBU</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-info"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nik_ibu" placeholder="NIK IBU" name="nik_ibu" maxlength="16">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="thn_lahir_ibu">Tahun Lahir Ibu</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                          <input type="text" class="form-control" placeholder="yyyy" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask="thn_lahir_ibu">
                                        </div>
                                        <!--input type="text" class="form-control required" id="tgl_lahir" placeholder="Tanggal Lahir Siswa" name="tgl_lahir" maxlength="16"-->
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="pendidikan_ibu">Pendidikan Ibu</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-question-circle"></i>
                                        </div>
                                        <select class="form-control" id="pendidikan_ibu" name="pendidikan_ibu">
                                        <option value="0">Pilih Pendidikan Ibu</option>
                                            <?php
                                            if(!empty($pendidikan_ibu))
                                            {
                                                foreach ($pendidikan_ibu as $peni)
                                                {
                                                    ?>
                                                    <option value="<?php echo $peni->id_pendidikan_terakhir; ?>"><?php echo $peni->pendidikan_terakhir ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="pekerjaan_ibu">Pekerjaan Ibu</label>
                                        <select class="form-control" id="pekerjaan_ibu" name="pekerjaan_ibu">
                                        <option value="0">Pilih Pekerjaan Ibu</option>
                                            <?php
                                            if(!empty($pekerjaan_ibu))
                                            {
                                                foreach ($pekerjaan_ibu as $pekib)
                                                {
                                                    ?>
                                                    <option value="<?php echo $pekib->id_pekerjaan; ?>"><?php echo $pekib->pekerjaan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="penghasilan_ibu">Penghasilan Ibu</label>
                                        <select class="form-control" id="penghasilan_ibu" name="penghasilan_ibu">
                                        <option value="0">Pilih Penghasilan Ibu</option>
                                            <?php
                                            if(!empty($penghasilan_ibu))
                                            {
                                                foreach ($penghasilan_ibu as $pengi)
                                                {
                                                    ?>
                                                    <option value="<?php echo $pengi->id_penghasilan; ?>"><?php echo $pengi->penghasilan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="alamat_ibu">Alamat Ibu</label>
                                        <input type="text" class="form-control" id="alamat_ibu" placeholder="Alamat Ibu" name="alamat_ibu" maxlength="100">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="hp_ibu">Nomor HP Ibu</label>
                                        <input type="text" class="form-control" id="hp_ibu" placeholder="Nomor HP Ibu" name="hp_ibu" maxlength="12">
                                    </div>
                                </div>
                            </div>
                            <!-- Wali-->
                            <br>
                            <h3><center>BIODATA WALI/SAUDARA TERDEKAT</center></h3>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama_wali">Nama Wali Siswa *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nama_wali" placeholder="Nama Wali Siswa" name="nama_wali" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="nik_wali">NIK Wali Siswa</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-info"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nik_wali" placeholder="NIK Wali Siswa" name="nik_wali" maxlength="16">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="thn_lahir_wali">Tahun Lahir Wali Siswa</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                          <input type="text" class="form-control" placeholder="yyyy" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask="thn_lahir_wali">
                                        </div>
                                        <!--input type="text" class="form-control required" id="tgl_lahir" placeholder="Tanggal Lahir Siswa" name="tgl_lahir" maxlength="16"-->
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="pendidikan_wali">Pendidikan Wali Siswa</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-question-circle"></i>
                                        </div>
                                        <select class="form-control" id="pendidikan_wali" name="pendidikan_wali">
                                        <option value="0">Pilih Pendidikan</option>
                                            <?php
                                            if(!empty($pendidikan_wali))
                                            {
                                                foreach ($pendidikan_wali as $penwa)
                                                {
                                                    ?>
                                                    <option value="<?php echo $penwa->id_pendidikan_terakhir; ?>"><?php echo $penwa->pendidikan_terakhir ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="pekerjaan_wali">Pekerjaan Wali Siswa</label>
                                        <select class="form-control" id="pekerjaan_wali" name="pekerjaan_wali">
                                        <option value="0">Pilih Pekerjaan Wali Siswa</option>
                                            <?php
                                            if(!empty($pekerjaan_wali))
                                            {
                                                foreach ($pekerjaan_wali as $pekwa)
                                                {
                                                    ?>
                                                    <option value="<?php echo $pekwa->id_pekerjaan; ?>"><?php echo $pekwa->pekerjaan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="penghasilan_wali">Penghasilan Wali Siswa</label>
                                        <select class="form-control" id="penghasilan_wali" name="penghasilan_wali">
                                        <option value="0">Pilih Penghasilan Wali Siswa</option>
                                            <?php
                                            if(!empty($penghasilan_wali))
                                            {
                                                foreach ($penghasilan_wali as $pengwa)
                                                {
                                                    ?>
                                                    <option value="<?php echo $pengwa->id_penghasilan; ?>"><?php echo $pengwa->penghasilan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="alamat_wali">Alamat Wali Siswa</label>
                                        <input type="text" class="form-control" id="alamat_wali" placeholder="Alamat Wali Siswa" name="alamat_wali" maxlength="100">
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="hp_wali">Nomor HP Wali Siswa *</label>
                                        <input type="text" class="form-control required" id="hp_wali" placeholder="Nomor HP Wali Siswa" name="hp_wali" maxlength="12">
                                    </div>
                                </div>
                            </div>
                            <br>
                            <br>
                            <label>__________________</label></br>
                            <label>*) Kolom Wajib diisi</label>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-flat btn-primary" value="Simpan" />
                            <input type="reset" class="btn btn-flat btn-warning" value="Reset" />
                            <a class="btn btn-flat btn-danger" href="<?php echo base_url(); ?>list-siswa-psb"><i></i>Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>


<!-- InputMask -->
<script src="<? php echo base_url(); ?>/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<? php echo base_url(); ?>/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<? php echo base_url(); ?>/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
	
	var AddPsbSiswaForm = $("#AddPsbSiswa");
	
	var validator = AddPsbSiswaForm.validate({
		
		rules:{
			nisn                : { required : true },
			nik                 : { required : true },
            nama                : { required : true },
            tmp_lahir           : { required : true },
            tgl_lahir           : { required : true },
            gender              : { required : true , selected : true },
            anak_ke             : { required : true },
            jml_sdr             : { required : true },
            desa                : { required : true },
            dukuh               : { required : true },
            rt                  : { required : true },
            rw                  : { required : true },
            kecamatan           : { required : true },
            kabupaten           : { required : true },
            provinsi            : { required : true },
            kode_pos            : { required : true },
            jalur_masuk         : { required : true , selected : true },
            jurusan             : { required : true , selected : true },
            pondok              : { required : true , selected : true },
            jenis_tinggal       : { required : true , selected : true },
            jarak_tinggal       : { required : true , selected : true },
            transportasi        : { required : true , selected : true },
            hobi                : { required : true , selected : true },
            citacita            : { required : true , selected : true },
            hp_siswa            : { required : true },
            sekolah_asal        : { required : true , selected : true },
            nama_sekolah_asal   : { required : true },
            alamat_sekolah_asal : { required : true },
            nama_ayah_kandung   : { required : true },
            pendidikan_ayah     : { required : true , selected : true },
            pekerjaan_ayah      : { required : true , selected : true },
            penghasilan_ayah    : { required : true , selected : true },
            nama_ibu_kandung    : { required : true },
            pendidikan_ibu      : { required : true , selected : true },
            pekerjaan_ibu       : { required : true , selected : true },
            penghasilan_ibu     : { required : true , selected : true },
            nama_wali           : { required : true },
            hp_wali             : { required : true }

            //status : { required : true , selected : true }
		},
		messages:{
			nisn                : { required : "NISN wajib diisi."},
            nik                 : { required : "NIK wajib diisi."},
            nama                : { required : "Nama wajib diisi."},
            tmp_lahir           : { required : "Tempat lahir wajib diisi."},
            tgl_lahir           : { required : "Tanggal lahir wajib diisi."},
            gender              : { required : "Jenis Kelamin wajib diisi." , selected : "Pilih salah satu."},
			anak_ke             : { required : "Kolom wajib diisi."},
            jml_sdr             : { required : "Jumlah saudara wajib diisi."},
            desa                : { required : "Kolom wajib diisi." },
            dukuh               : { required : "Kolom wajib diisi." },
            rt                  : { required : "Kolom wajib diisi." },
            rw                  : { required : "Kolom wajib diisi." },
            kecamatan           : { required : "Kolom wajib diisi." },
            kabupaten           : { required : "Kolom wajib diisi." },
            provinsi            : { required : "Kolom wajib diisi." },
            kode_pos            : { required : "Kolom wajib diisi." },
            jalur_masuk         : { required : "Jalur masuk wajib diisi." , selected : "Pilih salah satu." },
            jurusan             : { required : "Jurusan wajib diisi." , selected : "Pilih salah satu." },
            pondok              : { required : "Pondok wajib diisi." , selected : "Pilih salah satu." },
            jenis_tinggal       : { required : "Jenis tinggal wajib diisi." , selected : "Pilih salah satu." },
            jarak_tinggal       : { required : "Jarak tinggal wajib diisi." , selected : "Pilih salah satu." },
            transportasi        : { required : "Transportasi wajib diisi." , selected : "Pilih salah satu." },
            hobi                : { required : "Hobi wajib diisi." , selected : "Pilih salah satu." },
            citacita            : { required : "Cita cita wajib diisi." , selected : "Pilih salah satu." },
            hp_siswa            : { required : "Nomor HP wajib diisi." },
            sekolah_asal        : { required : "Asal sekolah wajib diisi." , selected : "Pilih salah satu." },
            nama_sekolah_asal   : { required : "Nama sekolah asal wajib diisi." },
            alamat_sekolah_asal : { required : "Alamat sekolah asal wajib diisi." },
            nama_ayah_kandung   : { required : "Nama ayah wajib diisi." },
            pendidikan_ayah     : { required : "Pendidikan Ayah wajib diisi." , selected : "Pilih salah satu." },
            pekerjaan_ayah      : { required : "Pekerjaan Ayah wajib diisi." , selected : "Pilih salah satu." },
            penghasilan_ayah    : { required : "Penghasilan Ayah wajib diisi." , selected : "Pilih salah satu." },
            nama_ibu_kandung    : { required : "Nama ibu wajib diisi." },
            pendidikan_ibu      : { required : "Pendidikan Ibu wajib diisi." , selected : "Pilih salah satu." },
            pekerjaan_ibu       : { required : "Pekerjaan Ibu wajib diisi." , selected : "Pilih salah satu." },
            penghasilan_ibu     : { required : "Penghasilan Ibu wajib diisi." , selected : "Pilih salah satu." },
            nama_wali           : { required : "Nama Wali wajib diisi."},
            hp_wali             : { required : "Nomor HP Wali wajib diisi."}
            //status : {required : "This fiel is required" , selected : "Please select atleas one option"}		
		}
	});
});
</script>