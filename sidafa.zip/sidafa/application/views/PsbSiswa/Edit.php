<?php

$id_pendaftaran     = '';
$nisn               = '';
$nik                = '';
$nama               = '';
$tmp_lahir          = '';
$tgl_lahir          = '';
$id_gender          = '';
$tahun_masuk        = '';
$id_agama              = '';
$anak_ke            = '';
$jml_sdr            = '';
$id_jalur_masuk     = ''; 
$id_jurusan         = '';
$id_pondok          = '';
$id_jenis_tinggal   = '';
$desa               = '';
$dukuh              = '';
$rt                 = '';
$rw                 = '';
$kecamatan          = '';  
$kabupaten          = '';
$provinsi           = '';
$kode_pos           = '';
$id_jarak           = '';
$id_transportasi    = '';
$id_hobi            = '';
$id_cita_cita       = '';
$hp_siswa           = '';
$foto               = '';
$no_kip             = '';
$no_kis             = '';
$no_kartu_lain      = '';
$id_sekolah_asal    = '';
$nama_sekolah_asal  = '';
$alamat_sekolah_asal= '';
$no_peserta_ujian   = '';
$no_ijazah          = '';
$no_shun            = '';
$nilai_un           = '';
$no_shuambn         = '';
$nilai_uambn        = '';
$p_smt_empat_gasal  = '';
$p_smt_empat_genap  = '';
$p_smt_lima_gasal   = '';
$p_smt_lima_genap   = '';
$p_smt_enam_gasal   = '';
$p_smt_enam_genap   = '';
$prestasi_satu      = '';
$prestasi_dua       = '';
$prestasi_tiga      = '';
$prestasi_empat     = '';
$prestasi_lima      = '';
$prestasi_enam      = '';
$nama_ayah_kandung  = '';
$nama_ayah_tiri     = '';
$nik_ayah           = '';
$thn_lahir_ayah     = '';
$id_pendidikan_ayah    = '';
$id_pekerjaan_ayah     = '';
$id_penghasilan_ayah   = '';
$alamat_ayah        = '';
$hp_ayah            = '';
$nama_ibu_kandung   = '';
$nama_ibu_tiri      = '';
$nik_ibu            = '';
$thn_lahir_ibu      = '';
$id_pendidikan_ibu     = '';
$id_pekerjaan_ibu      = '';
$id_penghasilan_ibu    = '';
$alamat_ibu         = '';
$hp_ibu             = '';
$nama_wali          = '';
$nik_wali           = '';
$thn_lahir_wali     = '';
$id_id_pendidikan_wali    = '';
$id_id_pekerjaan_wali     = '';
$id_id_penghasilan_wali   = '';
$alamat_wali        = '';
$hp_wali            = '';
$isDeleted          = '';
$CreatedBy          = '';
$CreatedDate        = '';
$UpdatedBy          = '';
$UpdatedDate        = '';
$ip_akses           = '';
$sistem_operasi     = '';
$id_aktif           = '';

if(!empty($psbsiswaInfo))
{
    foreach ($psbsiswaInfo as $psb)
    {
        $id_pendaftaran     = $psb->id_pendaftaran;
        $nisn               = $psb->nisn;
        $nik                = $psb->nik;
        $nama               = $psb->nama;
        $tmp_lahir          = $psb->tmp_lahir;
        $tgl_lahir          = $psb->tgl_lahir;
        $id_gender          = $psb->id_gender;
        $tahun_masuk        = $psb->tahun_masuk;
        $id_agama           = $psb->id_agama;
        $anak_ke            = $psb->anak_ke;
        $jml_sdr            = $psb->jml_sdr;
        $id_jalur_masuk     = $psb->id_jalur_masuk; 
        $id_jurusan         = $psb->id_jurusan;
        $id_pondok          = $psb->id_pondok;
        $id_jenis_tinggal   = $psb->id_jenis_tinggal;
        $desa               = $psb->desa;
        $dukuh              = $psb->dukuh;
        $rt                 = $psb->rt;
        $rw                 = $psb->rw;
        $kecamatan          = $psb->kecamatan;  
        $kabupaten          = $psb->kabupaten;
        $provinsi           = $psb->provinsi;
        $kode_pos           = $psb->kode_pos;
        $id_jarak           = $psb->id_jarak;
        $id_transportasi    = $psb->id_transportasi;
        $id_hobi            = $psb->id_hobi;
        $id_cita_cita       = $psb->id_cita_cita;
        $hp_siswa           = $psb->hp_siswa;
        $foto               = $psb->foto;
        $no_kip             = $psb->no_kip;
        $no_kis             = $psb->no_kis;
        $no_kartu_lain      = $psb->no_kartu_lain;
        $id_sekolah_asal    = $psb->id_sekolah_asal;
        $nama_sekolah_asal  = $psb->nama_sekolah_asal;
        $alamat_sekolah_asal= $psb->alamat_sekolah_asal;
        $no_peserta_ujian   = $psb->no_peserta_ujian;
        $no_ijazah          = $psb->no_ijazah;
        $no_shun            = $psb->no_shun;
        $nilai_un           = $psb->nilai_un;
        $no_shuambn         = $psb->no_shuambn;
        $nilai_uambn        = $psb->nilai_uambn;
        $p_smt_empat_gasal  = $psb->p_smt_empat_gasal;
        $p_smt_empat_genap  = $psb->p_smt_empat_genap;
        $p_smt_lima_gasal   = $psb->p_smt_lima_gasal;
        $p_smt_lima_genap   = $psb->p_smt_lima_genap;
        $p_smt_enam_gasal   = $psb->p_smt_enam_gasal;
        $p_smt_enam_genap   = $psb->p_smt_enam_genap;
        $prestasi_satu      = $psb->prestasi_satu;
        $prestasi_dua       = $psb->prestasi_dua;
        $prestasi_tiga      = $psb->prestasi_tiga;
        $prestasi_empat     = $psb->prestasi_empat;
        $prestasi_lima      = $psb->prestasi_lima;
        $prestasi_enam      = $psb->prestasi_enam;
        $nama_ayah_kandung  = $psb->nama_ayah_kandung;
        $nama_ayah_tiri     = $psb->nama_ayah_tiri;
        $nik_ayah           = $psb->nik_ayah;
        $thn_lahir_ayah     = $psb->thn_lahir_ayah;
        $id_pendidikan_ayah = $psb->id_pendidikan_ayah;
        $id_pekerjaan_ayah  = $psb->id_pekerjaan_ayah;
        $id_penghasilan_ayah= $psb->id_penghasilan_ayah;
        $alamat_ayah        = $psb->alamat_ayah;
        $hp_ayah            = $psb->hp_ayah;
        $nama_ibu_kandung   = $psb->nama_ibu_kandung;
        $nama_ibu_tiri      = $psb->nama_ibu_tiri;
        $nik_ibu            = $psb->nik_ibu;
        $thn_lahir_ibu      = $psb->thn_lahir_ibu;
        $id_pendidikan_ibu  = $psb->id_pendidikan_ibu;
        $id_pekerjaan_ibu   = $psb->id_pekerjaan_ibu;
        $id_penghasilan_ibu = $psb->id_penghasilan_ibu;
        $alamat_ibu         = $psb->alamat_ibu;
        $hp_ibu             = $psb->hp_ibu;
        $nama_wali          = $psb->nama_wali;
        $nik_wali           = $psb->nik_wali;
        $thn_lahir_wali     = $psb->thn_lahir_wali;
        $id_pendidikan_wali = $psb->id_pendidikan_wali;
        $id_pekerjaan_wali  = $psb->id_pekerjaan_wali;
        $id_penghasilan_wali= $psb->id_penghasilan_wali;
        $alamat_wali        = $psb->alamat_wali;
        $hp_wali            = $psb->hp_wali;
        $isDeleted          = $psb->isDeleted;
        $CreatedBy          = $psb->CreatedBy;
        $CreatedDate        = $psb->CreatedDate;
        $UpdatedBy          = $psb->UpdatedBy;
        $UpdatedDate        = $psb->UpdatedDate;
        $ip_akses           = $psb->ip_akses;
        $sistem_operasi     = $psb->sistem_operasi;
        $id_aktif           = $psb->id_aktif;
    }
}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> PSB Management
        <small>Add / Edit Data</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-11">
              <!-- general form elements -->
                
                
                
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>edit-data-siswa-psb" method="post" id="EditPsbSiswa" role="form">
                        <div class="box-body">
                            <!--Biodata-->
                            <h4><strong><center>BIODATA SISWA</center></strong></h4>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nisn">NISN *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-credit-card"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nisn" placeholder="NISN Siswa" name="nisn" maxlength="10" value="<?php echo $nisn; ?>">
                                        <input type="hidden" value="<?php echo $id_pendaftaran; ?>" name="id_pendaftaran" id="id_pendaftaran" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nik">NIK *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-cc-mastercard"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nik" placeholder="NIK Siswa" name="nik" value="<?php echo $nik; ?>" maxlength="16">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama">Nama Lengkap *</label>
                                        <input type="text" class="form-control required" id="nama" placeholder="Nama Lengkap Siswa" name="nama" value="<?php echo $nama; ?>" maxlength="100">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" class="form-control" value="dafa123" id="password" placeholder="Password" name="password" maxlength="100" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="tmp_lahir">Tempat Lahir *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-pencil-square-o"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="tmp_lahir" placeholder="Tempat Lahir Siswa" name="tmp_lahir" value="<?php echo $tmp_lahir; ?>" maxlength="20">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="tgl_lahir">Tanggal Lahir *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                          <input type="text" class="form-control required" placeholder="dd/mm/yyyy" name="tgl_lahir" value="<?php echo $tgl_lahir; ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="gender">Jenis Kelamin *</label>
                                        <select class="form-control required" id="gender" name="gender">
                                        <option value="0">Pilih Jenis Kelamin</option>
                                            <?php
                                            if(!empty($gender))
                                            {
                                                foreach ($gender as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_gender; ?>" <?php if($psb->id_gender == $id_gender) {echo "selected=selected";} ?>><?php echo $psb->gender ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="tahun_masuk">Tahun Masuk</label>
                                        <input type="text" class="form-control required" id="tahun_masuk" placeholder="2020" value="<?php echo $tahun_masuk; ?>" name="tahun_masuk" maxlength="10">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="agama">Agama</label>
                                        <select class="form-control" id="agama" name="agama">
                                        <option value="0">Pilih Agama</option>
                                            <?php
                                            if(!empty($agama))
                                            {
                                                foreach ($agama as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_agama; ?>" <?php if($psb->id_agama == $id_agama) {echo "selected=selected";} ?>><?php echo $psb->agama ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="anak_ke">Anak Ke *</label>
                                        <input type="text" class="form-control required" id="anak_ke" placeholder="Anak Ke" name="anak_ke" value="<?php echo $anak_ke; ?>" maxlength="2">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="jml_sdr">Jumlah Saudara *</label>
                                        <input type="text" class="form-control required" id="jml_sdr" placeholder="Jumlah Saudara Siswa" name="jml_sdr" value="<?php echo $jml_sdr; ?>" maxlength="2">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="jalur_masuk">Jalur Masuk *</label>
                                        <select class="form-control required" id="jalur_masuk" name="jalur_masuk">
                                        <option value="0">Pilih Jalur Masuk</option>
                                            <?php
                                            if(!empty($jalur_masuk))
                                            {
                                                foreach ($jalur_masuk as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_jalur_masuk; ?>" <?php if($psb->id_jalur_masuk == $id_jalur_masuk) {echo "selected=selected";} ?>><?php echo $psb->jalur_masuk ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="jurusan">Jurusan *</label>
                                        <select class="form-control required" id="jurusan" name="jurusan">
                                        <option value="0">Pilih Jurusan</option>
                                            <?php
                                            if(!empty($jurusan))
                                            {
                                                foreach ($jurusan as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_jurusan; ?>" <?php if($psb->id_jurusan == $id_jurusan) {echo "selected=selected";} ?>><?php echo $psb->nama_jurusan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="pondok">Pondok *</label>
                                        <select class="form-control required" id="pondok" name="pondok">
                                        <option value="0">Pilih Pondok</option>
                                            <?php
                                            if(!empty($pondok))
                                            {
                                                foreach ($pondok as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_pondok; ?>" <?php if($psb->id_pondok == $id_pondok) {echo "selected=selected";} ?>><?php echo $psb->nama_pondok ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="jenis_tinggal">Jenis Tinggal *</label>
                                        <select class="form-control required" id="jenis_tinggal" name="jenis_tinggal">
                                        <option value="0">Pilih Jenis Tinggal</option>
                                            <?php
                                            if(!empty($jenis_tinggal))
                                            {
                                                foreach ($jenis_tinggal as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_jenis_tinggal; ?>" <?php if($psb->id_jenis_tinggal == $id_jenis_tinggal) {echo "selected=selected";} ?>><?php echo $psb->jenis_tinggal ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="desa">Desa *</label>
                                        <input type="text" class="form-control required" id="desa" placeholder="Desa" name="desa" value="<?php echo $desa; ?>" maxlength="20">
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="dukuh">Dukuh *</label>
                                        <input type="text" class="form-control required" id="dukuh" placeholder="Dukuh" name="dukuh" value="<?php echo $dukuh; ?>" maxlength="20">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="rt">RT *</label>
                                        <input type="text" class="form-control required" id="rt" placeholder="000" name="rt" value="<?php echo $rt; ?>" maxlength="3">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="rw">RW *</label>
                                        <input type="text" class="form-control required" id="rw" placeholder="000" name="rw" value="<?php echo $rw; ?>" maxlength="3">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="kecamatan">Kecamatan *</label>
                                        <input type="text" class="form-control required" id="kecamatan" placeholder="Kecamatan" name="kecamatan" value="<?php echo $kecamatan; ?>" maxlength="30">
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="kabupaten">Kabupaten *</label>
                                        <input type="text" class="form-control required" id="kabupaten" placeholder="Kabupaten" name="kabupaten" value="<?php echo $kabupaten; ?>" maxlength="30">
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="provinsi">Provinsi *</label>
                                        <input type="text" class="form-control required" id="provinsi" placeholder="Provinsi" name="provinsi" value="<?php echo $provinsi; ?>" maxlength="30">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="kode_pos">Kode Pos *</label>
                                        <input type="text" class="form-control required" id="kode_pos" placeholder="Kode Pos" name="kode_pos" value="<?php echo $kode_pos; ?>" maxlength="6">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="jarak_tinggal">Jarak Tinggal *</label>
                                        <select class="form-control required" id="jarak_tinggal" name="jarak_tinggal">
                                        <option value="0">Pilih Jarak Tinggal</option>
                                            <?php
                                            if(!empty($jarak_tinggal))
                                            {
                                                foreach ($jarak_tinggal as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_jarak; ?>" <?php if($psb->id_jarak == $id_jarak) {echo "selected=selected";} ?>><?php echo $psb->jarak_tinggal ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="transportasi">Transportasi *</label>
                                        <select class="form-control required" id="transportasi" name="transportasi">
                                        <option value="0">Pilih Transportasi</option>
                                            <?php
                                            if(!empty($transportasi))
                                            {
                                                foreach ($transportasi as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_transportasi; ?>" <?php if($psb->id_transportasi == $id_transportasi) {echo "selected=selected";} ?>><?php echo $psb->transportasi ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="hobi">Hobi *</label>
                                        <select class="form-control required" id="hobi" name="hobi">
                                        <option value="0">Pilih Hobi</option>
                                            <?php
                                            if(!empty($hobi))
                                            {
                                                foreach ($hobi as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_hobi; ?>" <?php if($psb->id_hobi == $id_hobi) {echo "selected=selected";} ?>><?php echo $psb->nama_hobi ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="citacita">Cita Cita *</label>
                                        <select class="form-control required" id="citacita" name="citacita">
                                        <option value="0">Pilih Cita Cita</option>
                                            <?php
                                            if(!empty($citacita))
                                            {
                                                foreach ($citacita as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_cita_cita; ?>" <?php if($psb->id_cita_cita == $id_cita_cita) {echo "selected=selected";} ?>><?php echo $psb->nama_cita_cita ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="hp_siswa">NO HP Siswa *</label>
                                        <input type="text" class="form-control required" id="hp_siswa" placeholder="NO HP Siswa" name="hp_siswa" value="<?php echo $hp_siswa; ?>" maxlength="12">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="foto">FOTO</label>
                                        <input type="text" class="form-control" id="foto" placeholder="foto" name="foto" maxlength="20" value="<?php echo $foto; ?>" disabled>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="no_kip">NO KIP</label>
                                        <input type="text" class="form-control" id="no_kip" placeholder="NO Kartu Indonesia Pintar" name="no_kip" value="<?php echo $no_kip; ?>" maxlength="20">
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="no_kis">NO KIS</label>
                                        <input type="text" class="form-control" id="no_kis" placeholder="NO Kartu Indonesia Sehat" name="no_kis" value="<?php echo $no_kis; ?>" maxlength="20">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_kartu_lain">NO KARTU LAIN</label>
                                        <input type="text" class="form-control" id="no_kartu_lain" placeholder="Nomor Kartu Lain" name="no_kartu_lain" value="<?php echo $no_kartu_lain; ?>" maxlength="20">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="sekolah_asal">Asal Sekolah *</label>
                                        <select class="form-control required" id="sekolah_asal" name="sekolah_asal">
                                        <option value="0">Pilih Asal Sekolah</option>
                                            <?php
                                            if(!empty($sekolah_asal))
                                            {
                                                foreach ($sekolah_asal as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_sekolah_asal; ?>" <?php if($psb->id_sekolah_asal == $id_sekolah_asal) {echo "selected=selected";} ?>><?php echo $psb->sekolah_asal ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="nama_sekolah_asal">Nama Sekolah Asal *</label>
                                        <input type="text" class="form-control required" id="nama_sekolah_asal" placeholder="Nama Sekolah Asal" name="nama_sekolah_asal" value="<?php echo $nama_sekolah_asal; ?>" maxlength="30">
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="alamat_sekolah_asal">Alamat Sekolah Asal *</label>
                                        <input type="text" class="form-control required" id="alamat_sekolah_asal" placeholder="Alamat Sekolah Asal" name="alamat_sekolah_asal" value="<?php echo $alamat_sekolah_asal; ?>" maxlength="30">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_peserta_ujian">NO Peserta Ujian</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="no_peserta_ujian" placeholder="Nomor Peserta Ujian" name="no_peserta_ujian" value="<?php echo $no_peserta_ujian; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_ijazah">No Ijazah</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="no_ijazah" placeholder="Nomor Ijazah" name="no_ijazah" value="<?php echo $no_ijazah; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_shun">NO SHUN</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="no_shun" placeholder="Nomor Surat Hasil Ujian Nasional" name="no_shun" value="<?php echo $no_shun; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nilai_un">Nilai Rata-rata UN</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nilai_un" placeholder="Nilai Rata-rata Ujian Nasional" name="nilai_un" value="<?php echo $nilai_un; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_shuambn">NO SHUAMBN</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="no_shuambn" placeholder="Nilai Surat Hasil Ujian Akhir Madrasah Berstandar Nasional" name="no_shuambn" value="<?php echo $no_shuambn; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nilai_uambn">Nilai UAMBN</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-graduation-cap"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nilai_uambn" placeholder="Nilai Ujian Akhir Madrasah Berstandar Nasional" name="nilai_uambn" value="<?php echo $nilai_uambn; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Prestasi-->
                            <h3><center>PRESTASI SISWA</center></h3>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_empat_gasal">Peringkat Kelas IV Gasal</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_empat_gasal" placeholder="Peringkat ..." name="p_smt_empat_gasal" value="<?php echo $p_smt_empat_gasal; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_empat_genap">Peringkat Kelas IV Genap</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_empat_genap" placeholder="Peringkat ..." name="p_smt_empat_genap" value="<?php echo $p_smt_empat_genap; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_lima_gasal">Peringkat Kelas V Gasal</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_lima_gasal" placeholder="Peringkat ..." name="p_smt_lima_gasal" value="<?php echo $p_smt_lima_gasal; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_lima_genap">Peringkat Kelas V Genap</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_lima_genap" placeholder="Peringkat ..." name="p_smt_lima_genap" value="<?php echo $p_smt_lima_genap; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_enam_gasal">Peringkat Kelas VI Gasal</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_enam_gasal" placeholder="Peringkat ..." name="p_smt_enam_gasal" value="<?php echo $p_smt_enam_gasal; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="p_smt_enam_genap">Peringkat Kelas VI Genap</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-stack-overflow"></i>
                                        </div>
                                        <input type="text" class="form-control" id="p_smt_enam_genap" placeholder="Peringkat ..." name="p_smt_enam_genap" value="<?php echo $p_smt_enam_genap; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_satu">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_satu" placeholder="Prestasi Lainnya" name="prestasi_satu" value="<?php echo $prestasi_satu; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_dua">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_dua" placeholder="Prestasi Lainnya" name="prestasi_dua" value="<?php echo $prestasi_dua; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_tiga">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_tiga" placeholder="Prestasi Lainnya" name="prestasi_tiga" value="<?php echo $prestasi_tiga; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_empat">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_empat" placeholder="Prestasi Lainnya" name="prestasi_empat" value="<?php echo $prestasi_empat; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_lima">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_lima" placeholder="Prestasi Lainnya" name="prestasi_lima" value="<?php echo $prestasi_lima; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="prestasi_enam">Prestasi Lainnya</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-google-wallet"></i>
                                        </div>
                                        <input type="text" class="form-control" id="prestasi_enam" placeholder="Prestasi Lainnya" name="prestasi_enam" value="<?php echo $prestasi_enam; ?>" maxlength="30">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Ayah-->
                            <br>
                            <h3><center>BIODATA AYAH</center></h3>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama_ayah_kandung">Nama Ayah Kandung *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nama_ayah_kandung" placeholder="Nama Ayah Kandung" name="nama_ayah_kandung" value="<?php echo $nama_ayah_kandung; ?>" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5">                                
                                    <div class="form-group">
                                        <label for="nama_ayah_tiri">Nama Ayah Tiri</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user-md"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nama_ayah_tiri" placeholder="Nama Ayah Tiri" name="nama_ayah_tiri" value="<?php echo $nama_ayah_tiri; ?>" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="nik_ayah">NIK Ayah</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-info"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nik_ayah" placeholder="NIK Ayah" name="nik_ayah" value="<?php echo $nik_ayah; ?>" maxlength="16">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="thn_lahir_ayah">Tahun Lahir Ayah</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                          <input type="text" class="form-control" placeholder="yyyy" id="thn_lahir_ayah" value="<?php echo $thn_lahir_ayah; ?>" name="thn_lahir_ayah">
                                        </div>
                                        <!--input type="text" class="form-control required" id="tgl_lahir" placeholder="Tanggal Lahir Siswa" name="tgl_lahir" maxlength="16"-->
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="pendidikan_ayah">Pendidikan Ayah</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-question-circle"></i>
                                        </div>
                                        <select class="form-control" id="pendidikan_ayah" name="pendidikan_ayah">
                                        <option value="0">Pilih Pendidikan Ayah</option>
                                            <?php
                                            if(!empty($pendidikan_ayah))
                                            {
                                                foreach ($pendidikan_ayah as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_pendidikan_terakhir; ?>" <?php if($psb->id_pendidikan_terakhir == $id_pendidikan_ayah) {echo "selected=selected";} ?>><?php echo $psb->pendidikan_terakhir ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="pekerjaan_ayah">Pekerjaan Ayah</label>
                                        <select class="form-control" id="pekerjaan_ayah" name="pekerjaan_ayah">
                                        <option value="0">Pilih Pekerjaan Ayah</option>
                                            <?php
                                            if(!empty($pekerjaan_ayah))
                                            {
                                                foreach ($pekerjaan_ayah as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_pekerjaan; ?>" <?php if($psb->id_pekerjaan == $id_pekerjaan_ayah) {echo "selected=selected";} ?>><?php echo $psb->pekerjaan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="penghasilan_ayah">Penghasilan Ayah</label>
                                        <select class="form-control" id="penghasilan_ayah" name="penghasilan_ayah">
                                        <option value="0">Pilih Penghasilan Ayah</option>
                                            <?php
                                            if(!empty($penghasilan_ayah))
                                            {
                                                foreach ($penghasilan_ayah as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_penghasilan; ?>" <?php if($psb->id_penghasilan == $id_penghasilan_ayah) {echo "selected=selected";} ?>><?php echo $psb->penghasilan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="alamat_ayah">Alamat Ayah</label>
                                        <input type="text" class="form-control" id="alamat_ayah" placeholder="Alamat Ayah" name="alamat_ayah" value="<?php echo $alamat_ayah; ?>" maxlength="100">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="hp_ayah">Nomor HP Ayah</label>
                                        <input type="text" class="form-control" id="hp_ayah" placeholder="Nomor HP Ayah" name="hp_ayah" value="<?php echo $alamat_ayah; ?>" maxlength="12">
                                    </div>
                                </div>
                            </div> 
                            <!-- IBU-->
                            <br>
                            <h3><center>BIODATA IBU</center></h3>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama_ibu_kandung">Nama Ibu Kandung *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-female"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nama_ibu_kandung" placeholder="Nama Ibu Kandung" name="nama_ibu_kandung" value="<?php echo $nama_ibu_kandung; ?>" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5">                                
                                    <div class="form-group">
                                        <label for="nama_ibu_tiri">Nama Ibu Tiri</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user-md"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nama_ibu_tiri" placeholder="Nama Ibu Tiri" name="nama_ibu_tiri" value="<?php echo $nama_ibu_tiri ?>" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="nik_ibu">NIK IBU</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-info"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nik_ibu" placeholder="NIK IBU" name="nik_ibu" value="<?php echo $nik_ibu ?>" maxlength="16">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="thn_lahir_ibu">Tahun Lahir Ibu</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                          <input type="text" class="form-control" placeholder="yyyy" id="thn_lahir_ibu" name="thn_lahir_ibu" value="<?php echo $thn_lahir_ibu ?>" data-mask="thn_lahir_ibu">
                                        </div>
                                        <!--input type="text" class="form-control required" id="tgl_lahir" placeholder="Tanggal Lahir Siswa" name="tgl_lahir" maxlength="16"-->
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label for="pendidikan_ibu">Pendidikan Ibu</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-question-circle"></i>
                                        </div>
                                        <select class="form-control" id="pendidikan_ibu" name="pendidikan_ibu">
                                        <option value="0">Pilih Pendidikan Ibu</option>
                                            <?php
                                            if(!empty($pendidikan_ibu))
                                            {
                                                foreach ($pendidikan_ibu as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_pendidikan_terakhir; ?>" <?php if($psb->id_pendidikan_terakhir == $id_pendidikan_ibu) {echo "selected=selected";} ?>><?php echo $psb->pendidikan_terakhir ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="pekerjaan_ibu">Pekerjaan Ibu</label>
                                        <select class="form-control" id="pekerjaan_ibu" name="pekerjaan_ibu">
                                        <option value="0">Pilih Pekerjaan Ibu</option>
                                            <?php
                                            if(!empty($pekerjaan_ibu))
                                            {
                                                foreach ($pekerjaan_ibu as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_pekerjaan; ?>" <?php if($psb->id_pekerjaan == $id_pekerjaan_ibu) {echo "selected=selected";} ?>><?php echo $psb->pekerjaan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="penghasilan_ibu">Penghasilan Ibu</label>
                                        <select class="form-control" id="penghasilan_ibu" name="penghasilan_ibu">
                                        <option value="0">Pilih Penghasilan Ibu</option>
                                            <?php
                                            if(!empty($penghasilan_ibu))
                                            {
                                                foreach ($penghasilan_ibu as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_penghasilan; ?>" <?php if($psb->id_penghasilan == $id_penghasilan_ibu) {echo "selected=selected";} ?>><?php echo $psb->penghasilan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="alamat_ibu">Alamat Ibu</label>
                                        <input type="text" class="form-control" id="alamat_ibu" placeholder="Alamat Ibu" name="alamat_ibu" value="<?php echo $alamat_ibu ?>" maxlength="100">
                                    </div>
                                </div>
                                <div class="col-md-2">                                
                                    <div class="form-group">
                                        <label for="hp_ibu">Nomor HP Ibu</label>
                                        <input type="text" class="form-control" id="hp_ibu" placeholder="Nomor HP Ibu" name="hp_ibu" value="<?php echo $hp_ibu ?>" maxlength="12">
                                    </div>
                                </div>
                            </div>
                            <!-- Wali-->
                            <br>
                            <h3><center>BIODATA WALI/SAUDARA TERDEKAT</center></h3>
                            <br>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama_wali">Nama Wali Siswa *</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-user"></i>
                                        </div>
                                        <input type="text" class="form-control required" id="nama_wali" placeholder="Nama Wali Siswa" name="nama_wali" value="<?php echo $nama_wali ?>" maxlength="50">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="nik_wali">NIK Wali Siswa</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-info"></i>
                                        </div>
                                        <input type="text" class="form-control" id="nik_wali" placeholder="NIK Wali Siswa" name="nik_wali" value="<?php echo $nik_wali ?>" maxlength="16">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="thn_lahir_wali">Tahun Lahir Wali Siswa</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                          <input type="text" class="form-control" placeholder="yyyy" id="thn_lahir_wali" name="thn_lahir_wali" value="<?php echo $thn_lahir_wali ?>" data-mask="thn_lahir_wali">
                                        </div>
                                        <!--input type="text" class="form-control required" id="tgl_lahir" placeholder="Tanggal Lahir Siswa" name="tgl_lahir" maxlength="16"-->
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="pendidikan_wali">Pendidikan Wali Siswa</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-question-circle"></i>
                                        </div>
                                        <select class="form-control" id="pendidikan_wali" name="pendidikan_wali">
                                        <option value="0">Pilih Pendidikan</option>
                                            <?php
                                            if(!empty($pendidikan_wali))
                                            {
                                                foreach ($pendidikan_wali as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_pendidikan_terakhir; ?>" <?php if($psb->id_pendidikan_terakhir == $id_pendidikan_wali) {echo "selected=selected";} ?>><?php echo $psb->pendidikan_terakhir ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="pekerjaan_wali">Pekerjaan Wali Siswa</label>
                                        <select class="form-control" id="pekerjaan_wali" name="pekerjaan_wali">
                                        <option value="0">Pilih Pekerjaan Wali Siswa</option>
                                            <?php
                                            if(!empty($pekerjaan_wali))
                                            {
                                                foreach ($pekerjaan_wali as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_pekerjaan; ?>" <?php if($psb->id_pekerjaan == $id_pekerjaan_wali) {echo "selected=selected";} ?>><?php echo $psb->pekerjaan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="penghasilan_wali">Penghasilan Wali Siswa</label>
                                        <select class="form-control" id="penghasilan_wali" name="penghasilan_wali">
                                        <option value="0">Pilih Penghasilan Wali Siswa</option>
                                            <?php
                                            if(!empty($penghasilan_wali))
                                            {
                                                foreach ($penghasilan_wali as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_penghasilan; ?>" <?php if($psb->id_penghasilan == $id_penghasilan_wali) {echo "selected=selected";} ?>><?php echo $psb->penghasilan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">                                
                                    <div class="form-group">
                                        <label for="alamat_wali">Alamat Wali Siswa</label>
                                        <input type="text" class="form-control" id="alamat_wali" placeholder="Alamat Wali Siswa" name="alamat_wali" value="<?php echo $alamat_wali ?>" maxlength="100">
                                    </div>
                                </div>
                                <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="hp_wali">Nomor HP Wali Siswa *</label>
                                        <input type="text" class="form-control required" id="hp_wali" placeholder="Nomor HP Wali Siswa" name="hp_wali" value="<?php echo $hp_wali ?>" maxlength="12">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                            <div class="col-xs-3">
                                    <div class="form-group has-warning">
                                        <label for="status">Keaktifan</label>
                                        <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-question-circle"></i>
                                        </div>
                                        <select class="form-control" id="status" name="status">
                                        <option value="0">Pilih Keaktifan</option>
                                            <?php
                                            if(!empty($status))
                                            {
                                                foreach ($status as $psb)
                                                {
                                                    ?>
                                                    <option value="<?php echo $psb->id_aktif; ?>" <?php if($psb->id_aktif == $id_aktif) {echo "selected=selected";} ?>><?php echo $psb->keaktifan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                            <br>
                            <label>__________________</label></br>
                            <label>*) Kolom Wajib diisi</label>
                        </div><!-- /.box-body -->

                        <div class="box-footer">
                            <input type="submit" class="btn btn-flat btn-primary" value="Simpan" />
                            <a class="btn btn-flat btn-danger" href="<?php echo base_url(); ?>list-siswa-psb"><i></i>Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script type="text/javascript">
	$(document).ready(function(){
	
	var EditPsbSiswaForm = $("#EditPsbSiswa");
	
	var validator = EditPsbSiswaForm.validate({
		
		rules:{
            nisn                : { required : true },
            nik                 : { required : true },
            nama                : { required : true },
            tmp_lahir           : { required : true },
            tgl_lahir           : { required : true },
            gender              : { required : true , selected : true },
            anak_ke             : { required : true },
            jml_sdr             : { required : true },
            desa                : { required : true },
            dukuh               : { required : true },
            rt                  : { required : true },
            rw                  : { required : true },
            kecamatan           : { required : true },
            kabupaten           : { required : true },
            provinsi            : { required : true },
            kode_pos            : { required : true },
            jalur_masuk         : { required : true , selected : true },
            jurusan             : { required : true , selected : true },
            pondok              : { required : true , selected : true },
            jenis_tinggal       : { required : true , selected : true },
            jarak_tinggal       : { required : true , selected : true },
            transportasi        : { required : true , selected : true },
            hobi                : { required : true , selected : true },
            citacita            : { required : true , selected : true },
            hp_siswa            : { required : true },
            sekolah_asal        : { required : true , selected : true },
            nama_sekolah_asal   : { required : true },
            alamat_sekolah_asal : { required : true },
            nama_ayah_kandung   : { required : true },
            pendidikan_ayah     : { required : true , selected : true },
            pekerjaan_ayah      : { required : true , selected : true },
            penghasilan_ayah    : { required : true , selected : true },
            nama_ibu_kandung    : { required : true },
            pendidikan_ibu      : { required : true , selected : true },
            pekerjaan_ibu       : { required : true , selected : true },
            penghasilan_ibu     : { required : true , selected : true },
            nama_wali           : { required : true },
            hp_wali             : { required : true }
            status              : { required : true , selected : true }
        },
        messages:{
            nisn                : { required : "NISN wajib diisi."},
            nik                 : { required : "NIK wajib diisi."},
            nama                : { required : "Nama wajib diisi."},
            tmp_lahir           : { required : "Tempat lahir wajib diisi."},
            tgl_lahir           : { required : "Tanggal lahir wajib diisi."},
            gender              : { required : "Jenis Kelamin wajib diisi." , selected : "Pilih salah satu."},
            anak_ke             : { required : "Kolom wajib diisi."},
            jml_sdr             : { required : "Jumlah saudara wajib diisi."},
            desa                : { required : "Kolom wajib diisi." },
            dukuh               : { required : "Kolom wajib diisi." },
            rt                  : { required : "Kolom wajib diisi." },
            rw                  : { required : "Kolom wajib diisi." },
            kecamatan           : { required : "Kolom wajib diisi." },
            kabupaten           : { required : "Kolom wajib diisi." },
            provinsi            : { required : "Kolom wajib diisi." },
            kode_pos            : { required : "Kolom wajib diisi." },
            jalur_masuk         : { required : "Jalur masuk wajib diisi." , selected : "Pilih salah satu." },
            jurusan             : { required : "Jurusan wajib diisi." , selected : "Pilih salah satu." },
            pondok              : { required : "Pondok wajib diisi." , selected : "Pilih salah satu." },
            jenis_tinggal       : { required : "Jenis tinggal wajib diisi." , selected : "Pilih salah satu." },
            jarak_tinggal       : { required : "Jarak tinggal wajib diisi." , selected : "Pilih salah satu." },
            transportasi        : { required : "Transportasi wajib diisi." , selected : "Pilih salah satu." },
            hobi                : { required : "Hobi wajib diisi." , selected : "Pilih salah satu." },
            citacita            : { required : "Cita cita wajib diisi." , selected : "Pilih salah satu." },
            hp_siswa            : { required : "Nomor HP wajib diisi." },
            sekolah_asal        : { required : "Asal sekolah wajib diisi." , selected : "Pilih salah satu." },
            nama_sekolah_asal   : { required : "Nama sekolah asal wajib diisi." },
            alamat_sekolah_asal : { required : "Alamat sekolah asal wajib diisi." },
            nama_ayah_kandung   : { required : "Nama ayah wajib diisi." },
            pendidikan_ayah     : { required : "Pendidikan Ayah wajib diisi." , selected : "Pilih salah satu." },
            pekerjaan_ayah      : { required : "Pekerjaan Ayah wajib diisi." , selected : "Pilih salah satu." },
            penghasilan_ayah    : { required : "Penghasilan Ayah wajib diisi." , selected : "Pilih salah satu." },
            nama_ibu_kandung    : { required : "Nama ibu wajib diisi." },
            pendidikan_ibu      : { required : "Pendidikan Ibu wajib diisi." , selected : "Pilih salah satu." },
            pekerjaan_ibu       : { required : "Pekerjaan Ibu wajib diisi." , selected : "Pilih salah satu." },
            penghasilan_ibu     : { required : "Penghasilan Ibu wajib diisi." , selected : "Pilih salah satu." },
            nama_wali           : { required : "Nama Wali wajib diisi."},
            hp_wali             : { required : "Nomor HP Wali wajib diisi."}
            status              : {required  : "This fiel is required" , selected : "Please select atleas one option"}      
        }
	});
});
</script>