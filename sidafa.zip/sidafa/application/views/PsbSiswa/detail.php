
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> PSB Management
        <small>Add / Detail Data</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Data Siswa Details</h3>                         
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>print-siswa-psb" method="post" id="PrintPsbSiswa" role="form">
                    	<div class="button" align="right">
        <input type="submit" class="btn btn-flat btn-danger" value="Cetak" />
            <a class="btn btn-flat btn-primary" href="<?php echo base_url(); ?>list-siswa-psb"><i></i>Kembali</a>
        </div>
                        <div class="box-body">
                            <!--Biodata-->
                            <div align="center">
                            <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url() ?>assets/dist/img/user.png" alt="User profile picture">
                            </div>
                            <?php

							  if(!empty($psbsiswaInfoDetail))
							  {	
							      foreach($psbsiswaInfoDetail as $record) 
							      {
							      	
							?>
                            <h4 class="profile-username text-center"><strong><?php echo $record->nama ?></strong></h4>
                            <p align="center">Status :<a> <?php echo $record->keaktifan ?></a></p>
                            <br>
                            <div class="col-xs-6">
                            	<p class="lead" align="center">Biodata Siswa</p>
	                            <div class="table-responsive">
	                            <table class="table">
					              <tbody>
					              <tr>
					                <th style="width:50%">NISN </th>
					                <td><a><?php echo $record->nisn ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">NIK </th>
					                <td><a><?php echo $record->nik ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Nama Lengkap </th>
					                <td><a><?php echo $record->nama ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Password </th>
					                <td><a>********</a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Tempat Lahir </th>
					                <td><a><?php echo $record->tmp_lahir ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Tanggal Lahir </th>
					                <td><a><?php echo $record->tgl_lahir ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Jenis Kelamin </th>
					                <td><a><?php echo $record->gender ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Tahun Masuk </th>
					                <td><a><?php echo $record->tahun_masuk ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Agama </th>
					                <td><a><?php echo $record->agama ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Anak Ke </th>
					                <td><a><?php echo $record->anak_ke ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Jumlah Saudara </th>
					                <td><a><?php echo $record->jml_sdr ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Jalur Masuk </th>
					                <td><a><?php echo $record->jalur_masuk ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Jurusan </th>
					                <td><a><?php echo $record->nama_jurusan ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Pondok </th>
					                <td><a><?php echo $record->nama_pondok ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Jenis Tinggal </th>
					                <td><a><?php echo $record->jenis_tinggal ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Desa </th>
					                <td><a><?php echo $record->desa ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Dukuh </th>
					                <td><a><?php echo $record->dukuh ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">RT </th>
					                <td><a><?php echo $record->rt ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">RW </th>
					                <td><a><?php echo $record->rw ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Kecamatan </th>
					                <td><a><?php echo $record->kecamatan ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Kabupaten </th>
					                <td><a><?php echo $record->kabupaten ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Provinsi </th>
					                <td><a><?php echo $record->provinsi ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Kode Pos </th>
					                <td><a><?php echo $record->kode_pos ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Jarak Tinggal </th>
					                <td><a><?php echo $record->jarak_tinggal ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Transportasi </th>
					                <td><a><?php echo $record->transportasi ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Hobi </th>
					                <td><a><?php echo $record->nama_hobi ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Cita Cita </th>
					                <td><a><?php echo $record->nama_cita_cita ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Nomor HP Siswa </th>
					                <td><a><?php echo $record->hp_siswa ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Nomor KIP </th>
					                <td><a><?php echo $record->no_kip ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Nomor KIS </th>
					                <td><a><?php echo $record->no_kis ?></a></td>
					              </tr>
					              <tr>
					                <th style="width:50%">Nomor Kartu Lain </th>
					                <td><a><?php echo $record->no_kartu_lain ?></a></td>
					              </tr>
					            </tbody></table>
					        	</div>
				        	
                                <p class="lead" align="center">Biodata Sekolah Asal</p>
                                <div class="table-responsive">
                                <table class="table">
                                  <tbody>
                                  <tr>
                                    <th style="width:50%">Asal Sekolah </th>
                                    <td><a><?php echo $record->sekolah_asal ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nama Sekolah Asal </th>
                                    <td><a><?php echo $record->nama_sekolah_asal ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Alamat Sekolah Asal </th>
                                    <td><a><?php echo $record->alamat_sekolah_asal ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nomor Peserta Ujian </th>
                                    <td><a><?php echo $record->no_peserta_ujian ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nomor Ijazah </th>
                                    <td><a><?php echo $record->no_ijazah ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nomor SHUN </th>
                                    <td><a><?php echo $record->no_shun ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nilai Rata-rata UN </th>
                                    <td><a><?php echo $record->nilai_un  ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nomor SHUAMBN </th>
                                    <td><a><?php echo $record->no_shuambn ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nilai UAMBN </th>
                                    <td><a><?php echo $record->nilai_uambn ?></a></td>
                                  </tr>
                                </tbody></table>
                                </div>
                            </div>

                            <div class="col-xs-6">
                                <p class="lead" align="center">Prestasi Siswa</p>
                                <div class="table-responsive">
                                <table class="table">
                                  <tbody>
                                  <tr>
                                    <th style="width:50%">Peringkat Kelas IV Gasal </th>
                                    <td><a><?php echo $record->p_smt_empat_gasal ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Peringkat Kelas IV Genap </th>
                                    <td><a><?php echo $record->p_smt_empat_genap ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Peringkat Kelas V Gasal </th>
                                    <td><a><?php echo $record->p_smt_lima_gasal ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Peringkat Kelas V Genap </th>
                                    <td><a><?php echo $record->p_smt_empat_genap ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Peringkat Kelas VI Gasal </th>
                                    <td><a><?php echo $record->p_smt_enam_gasal ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Peringkat Kelas VI Genap </th>
                                    <td><a><?php echo $record->p_smt_enam_genap ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Prestasi Lainnya </th>
                                    <td><a><?php echo $record->prestasi_satu  ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Prestasi Lainnya </th>
                                    <td><a><?php echo $record->prestasi_dua ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Prestasi Lainnya </th>
                                    <td><a><?php echo $record->prestasi_tiga ?></a>
                                    </td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Prestasi Lainnya </th>
                                    <td><a><?php echo $record->prestasi_empat  ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Prestasi Lainnya </th>
                                    <td><a><?php echo $record->prestasi_lima ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Preastasi Lainnya </th>
                                    <td><a><?php echo $record->prestasi_enam ?></a>
                                    </td>
                                  </tr>
                                </tbody></table>
                                </div>
                            </div>
                            <br>
                            <div class="col-xs-6">
                                <p class="lead" align="center">Biodata Keluarga</p>
                                <div class="table-responsive">
                                <table class="table">
                                  <tbody>
                                  <tr>
                                    <th style="width:50%">Nama Ayah Kadung </th>
                                    <td><a><?php echo $record->nama_ayah_kandung ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nama Ayah Tiri </th>
                                    <td><a><?php echo $record->nama_ayah_tiri ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Tahun Lahir Ayah </th>
                                    <td><a><?php echo $record->thn_lahir_ayah ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Pendidikan Ayah </th>
                                    <td><a><?php echo $record->pendidikan_terakhir ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Pekerjaan Ayah </th>
                                    <td><a><?php echo $record->pekerjaan ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Penghasilan Ayah </th>
                                    <td><a><?php echo $record->penghasilan ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Alamat Ayah </th>
                                    <td><a><?php echo $record->alamat_ayah  ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nomor HP Ayah </th>
                                    <td><a><?php echo $record->hp_ayah ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nama Ibu Kadung </th>
                                    <td><a><?php echo $record->nama_ibu_kandung ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nama Ibu Tiri </th>
                                    <td><a><?php echo $record->nama_ibu_tiri ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Tahun Lahir Ibu </th>
                                    <td><a><?php echo $record->thn_lahir_ibu ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Pendidikan Ibu </th>
                                    <td><a><?php echo $record->pendidikan_terakhir ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Pekerjaan Ibu </th>
                                    <td><a><?php echo $record->pekerjaan ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Penghasilan Ibu </th>
                                    <td><a><?php echo $record->penghasilan ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Alamat Ibu </th>
                                    <td><a><?php echo $record->alamat_ibu  ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nomor HP Ibu </th>
                                    <td><a><?php echo $record->hp_ibu ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nama Wali </th>
                                    <td><a><?php echo $record->nama_wali ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Tahun Lahir Wali </th>
                                    <td><a><?php echo $record->thn_lahir_wali ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Pendidikan Wali </th>
                                    <td><a><?php echo $record->pendidikan_terakhir ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Pekerjaan Wali </th>
                                    <td><a><?php echo $record->pekerjaan ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Penghasilan Wali </th>
                                    <td><a><?php echo $record->penghasilan ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Alamat Wali </th>
                                    <td><a><?php echo $record->alamat_wali  ?></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:50%">Nomor HP Wali </th>
                                    <td><a><?php echo $record->hp_wali ?></a></td>
                                  </tr>
                                </tbody></table>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
                    </form>
                </div>
            </div>
        </div>    
    </section>
</div>
<?php
}
}
?>