<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Data Pendaftaran Siswa Baru 2020
        <small>Add, Edit, Delete</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12 text-right">
                <div class="form-group">
                  <a class="btn btn-flat btn-warning" href="<?php echo base_url(); ?>list-bayar-psb"><i class="fa  fa-paper-plane"></i> Pembayaran</a>
                    <a class="btn btn-flat btn-primary" href="<?php echo base_url(); ?>add-new-siswa-psb"><i class="fa fa-plus"></i> Add New</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                    <h3 class="box-title">Daftar Siswa Pendaftar</h3>
                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="table" class="table table table-bordered table-hover">
                    <thead>
                    <tr>
                      <th class="text-center" width="5">NO</th>
                      <th class="text-center">NISN</th>
                      <th class="text-center">NAMA</th>
                      <th class="text-center">TTL</th>
                      <th class="text-center">L/P</th>
                      <th class="text-center">ALAMAT</th>
                      <th class="text-center">JURUSAN</th>
                      <th class="text-center">SEKOLAH ASAL</th>
                      <th class="text-center" width="70">Actions</th>
                    </tr>
                    </thead>
                    <?php
                    if(!empty($psbsiswaRecords))
                    {	$i=1;
                        foreach($psbsiswaRecords as $record) 
                        {
                    ?>
                    <tr>
                      <td class="text-center"><?php echo $i ?>.</td>
                      <td><?php echo $record->nisn ?></td>
                      <td><?php echo $record->nama ?></td>
                      <td><?php echo $record->tmp_lahir?>, <?php echo  $record->tgl_lahir?></td>
                      <td class="text-center"><?php echo $record->kd_gender ?></td>
                      <td><?php echo $record->desa ?> <?php echo $record->dukuh ?>, RT <?php echo $record->rt ?> RW <?php echo $record->rw ?></td>
                      <td><?php echo $record->nama_jurusan ?></td>
                      <td class="text-center"><?php echo $record->nama_sekolah_asal ?></td>
                      <td class="text-center" width="120">
                          <a class="btn btn-flat btn-sm btn-info" href="<?php echo base_url().'edit-siswa-psb/'.$record->id_pendaftaran; ?>"><i class="fa fa-pencil"></i></a>
                          <!--a class="btn btn-flat btn-sm btn-success" href="<?php echo base_url().'detail-siswa-psb/'.$record->id_pendaftaran; ?>"><i class="fa fa-search"></i></a-->
                          <a class="btn btn-flat btn-sm btn-warning" href="<?php echo base_url().'print-siswa-psb/'.$record->id_pendaftaran; ?>"><i class="fa fa-print"></i></a>
                          <a class="btn btn-flat btn-sm btn-danger deletePsbSiswa" href="#" data-id_pendaftaran="<?php echo $record->id_pendaftaran; ?>"><i class="fa fa-trash"></i></a>
                      </td>
                    </tr>
                    <?php
                    $i++;
                        }
                    }
                    ?>
                  </table>
                  
                </div><!-- /.box-body -->
                <div class="box-footer clearfix">
                    <?php echo $this->pagination->create_links(); ?>
                </div>
              </div><!-- /.box -->
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
  jQuery(document).ready(function(){
  
  jQuery(document).on("click", ".deletePsbSiswa", function(){
    var id_pendaftaran = $(this).data("id_pendaftaran"),
      hitURL = baseURL + "deletePsbSiswa",
      currentRow = $(this);
    
    var confirmation = confirm("Are you sure to delete this data ?");
    
    if(confirmation)
    {
      jQuery.ajax({
      type : "POST",
      dataType : "json",
      url : hitURL,
      data : { id_pendaftaran : id_pendaftaran } 
      }).done(function(data){
        console.log(data);
        currentRow.parents('tr').remove();
        if(data.status = true) { alert("Data successfully deleted"); }
        else if(data.status = false) { alert("Data deletion failed"); }
        else { alert("Access denied..!"); }
      });
    }
  });
  
  
  jQuery(document).on("click", ".searchList", function(){
    
  });
  
});
</script>

<script type="text/javascript">
   $(document).ready(function() {
        //datatables
        table = $('#table').DataTable({ 
        });
    }); 
</script>

