<?php

$id_transportasi = '';
$transportasi = '';
$id_aktif = '';

if(!empty($transportasiInfo))
{
    foreach ($transportasiInfo as $hb)
    {
        $id_transportasi = $hb->id_transportasi;
        $transportasi = $hb->transportasi;
        $id_aktif = $hb->id_aktif;
    }
}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Transportasi Management
        <small>Add / Edit Transportasi</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>edit-data-transportasi" method="post" id="EditTransportasi" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="transportasi">Nama Transportasi</label>
                                        <input type="text" class="form-control" id="transportasi" placeholder="Nama Transportasi" name="transportasi" value="<?php echo $transportasi; ?>" maxlength="12">
                                        <input type="hidden" value="<?php echo $id_transportasi; ?>" name="id_transportasi" id="id_transportasi" />    
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status">Keaktifan</label>
                                        <select class="form-control" id="status" name="status">
                                        <option value="0">Pilih Keaktifan</option>
                                            <?php
                                            if(!empty($status))
                                            {
                                                foreach ($status as $ak)
                                                {
                                                    ?>
                                                    <option value="<?php echo $ak->id_aktif; ?>" <?php if($ak->id_aktif == $id_aktif) {echo "selected=selected";} ?>><?php echo $ak->keaktifan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-flat btn-primary" value="Simpan" />
                            <a class="btn btn-flat btn-danger" href="<?php echo base_url(); ?>list-transportasi"><i></i>Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script type="text/javascript">
	$(document).ready(function(){
	
	var EditTransportasiForm = $("#EditTransportasi");
	
	var validator = EditTransportasiForm.validate({
		
		rules:{
			transportasi :{ required : true },
			status : { required : true, selected : true}
		},
		messages:{
			transportasi :{ required : "This field is required" },
			status : { required : "This field is required", selected : "Please select atleast one option" }			
		}
	});
});
</script>