<?php

$id_pondok = '';
$nama_pondok = '';
$alamat = '';
$no_hp = '';
$pengasuh = '';
$id_aktif = '';

if(!empty($pondokInfo))
{
    foreach ($pondokInfo as $pd)
    {
        $id_pondok = $pd->id_pondok;
        $nama_pondok = $pd->nama_pondok;
        $alamat = $pd->alamat;
        $no_hp = $pd->no_hp;
        $pengasuh = $pd->pengasuh;
        $id_aktif = $pd->id_aktif;
    }
}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Pondok Management
        <small>Add / Edit Pondok</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>edit-data-pondok" method="post" id="EditPondok" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="nama_pondok">Nama Pondok</label>
                                        <input type="text" class="form-control" id="nama_pondok" placeholder="Nama Pondok" name="nama_pondok" value="<?php echo $nama_pondok; ?>" maxlength="12">
                                        <input type="hidden" value="<?php echo $id_pondok; ?>" name="id_pondok" id="id_pondok" />    
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="alamat">Alamat</label>
                                        <input type="text" class="form-control" id="alamat" placeholder="Alamat Pondok" name="alamat" value="<?php echo $alamat; ?>" maxlength="12">    
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="no_hp">Kontak (No Hp)</label>
                                        <input type="text" class="form-control" id="no_hp" placeholder="Kontak (Telp/No Hp)" name="no_hp" value="<?php echo $no_hp; ?>" maxlength="12">   
                                    </div>
                                </div>
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="pengasuh">Pengasuh Pondok</label>
                                        <input type="text" class="form-control" id="pengasuh" placeholder="Nama Pengasuh Pondok" name="pengasuh" value="<?php echo $pengasuh; ?>" maxlength="12">    
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                            	<div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status">Keaktifan</label>
                                        <select class="form-control" id="status" name="status">
                                        <option value="0">Pilih Keaktifan</option>
                                            <?php
                                            if(!empty($status))
                                            {
                                                foreach ($status as $ak)
                                                {
                                                    ?>
                                                    <option value="<?php echo $ak->id_aktif; ?>" <?php if($ak->id_aktif == $id_aktif) {echo "selected=selected";} ?>><?php echo $ak->keaktifan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-flat btn-primary" value="Simpan" />
                            <a class="btn btn-flat btn-danger" href="<?php echo base_url(); ?>list-pondok"><i></i>Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script type="text/javascript">
	$(document).ready(function(){
	
	var EditPondokForm = $("#EditPondok");
	
	var validator = EditPondokForm.validate({
		
		rules:{
			nama_pondok :{ required : true },
			alamat : { required : true },
            no_hp : { required : true },
            pengasuh : { required : true },
			status : { required : true, selected : true}
		},
		messages:{
			nama_pondok :{ required : "This field is required" },
			alamat : { required : "This field is required"},
            no_hp : { required : "This field is required"},
            pengasuh : { required : "This field is required"},
			status : { required : "This field is required", selected : "Please select atleast one option" }			
		}
	});
});
</script>