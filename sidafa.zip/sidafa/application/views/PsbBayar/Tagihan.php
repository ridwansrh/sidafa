<?php 
$id_pendaftaran= '';
$id_biaya_psb = '';

if(!empty($psbbayarInfo))
{
    foreach ($psbbayarInfo as $hb)
    {
        $id_biaya_psb = $hb->id_biaya_psb;
    }
}
?>
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Pembayaran Siswa Baru
        <small>Management Data</small>
        <div class="button" align="right">
	        <a class="btn btn-flat btn-primary" href="<?php echo base_url(); ?>list-bayar-psb"><i></i>Kembali</a>
	    </div>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
                <div class="box box-warning">
                    <div class="box-header with-border">
                        <h3 class="box-title">Data Siswa Baru</h3>                        
                    </div><!-- /.box-header -->
                    <!-- form start -->
                        <div class="box-body">
                            <?php

							  if(!empty($psbsiswaInfo))
							  {	
							      foreach($psbsiswaInfo as $record) 
							      {	
							?>
                            <!--p align="center">Status :<a> <?php echo $record->keaktifan ?></a></p-->
                            <div class="col-xs-12">
	                            <div class="table-responsive">
	                            <table class="table table-bordered">
					              <tbody>
					              <tr>
					                <th style="width:10px">Nama Lengkap </th> 
					                <td style="width:120px"><a><strong><?php echo $record->nama ?></strong></a></td>
					                <th style="width:10px">Tahun Masuk </th>
					                <td style="width:120px"><a><strong><?php echo $record->tahun_masuk ?></strong></a></td>
					              </tr>
					              <tr>
					                <th style="width:10px">NISN </th> 
					                <td style="width:120px"><a><strong><?php echo $record->nisn ?></strong></a></td>
					                <th style="width:10px">Alamat </th>
					                <td style="width:120px"><a><strong><?php echo $record->desa ?>, RT <?php echo $record->rt ?> RW <?php echo $record->rw ?> <?php echo $record->kecamatan ?> - <?php echo $record->kabupaten ?></strong></a></td>
					              </tr>
					            </tbody></table>
					        	</div>
                            </div>
                        </div><!-- /.box-body -->
                </div>
            </div>
        <!-- filter -->
        <div class="col-xs-4">

          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Filter Data</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <!--?php
                    echo form_open('PsbBayar/cetak_bayar');
                ?-->
                <table class="table table-bordered">
                    <!--tr>
                        <td>Pembayaran</td>
                        <td>
                            <?php echo cmb_dinamis('PsbBiaya', 'tbl_kategori', 'nama_kategori', 'id', null, "id='kategori' onChange='loadKategori()'") 
                            ?>        
                        </td>
                    </tr-->
                    <tr>
                        <td>Jenis Pembayaran</td>
                        <td>
                            <?php echo cmb_dinamis('PsbBiaya', 'tbl_psb_biaya', 'jenis_biaya', 'id_biaya_psb', null, "id='Biaya' onChange='loadTagihan()'") 
                            ?>        
                        </td>
                    </tr>
                    <tr>
                        <td>Tagihan</td>
                        <td>
                            <!-- kelas dipanggil melalui serverside karena harus melakukan penyesuaian agar sesuai pada tingkatan apa kelasnya ada apa saja -->
                            <div id="tampilTagihan"></div>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal">
                            <i class="fa fa-cogs" aria-hidden="true"></i> Generate
                            </button>
                            <button type="submit" name="export_jadwal" class="btn btn-danger btn-sm"><i class="fa fa-print" aria-hidden="true"></i> Cetak Kwitansi</button>
                        </td>
                    </tr>
                </table>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->

            <!--div class="col-md-8">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title">RINCIAN PEMBIAYAAN</h3>                        
                    </div>< /.box-header >
                    <div class="box-body">
                            <div>
	                            <table class="table table-bordered">
	                            	<thead>
				                    <tr>
				                      <th class="text-center" width="5px">NO</th>
				                      <th class="text-center">JENIS BIAYA</th>
				                      <th class="text-center">JUMLAH</th>
				                      <th class="text-center">TGL BAYAR</th>
				                      <th class="text-center">TERBAYAR</th>
				                      <th class="text-center" width="150px">Actions</th>
				                    </tr>
				                    </thead>
					              <?php
				                    if(!empty($PsbTagihanRecords))
				                    { $i=1;
				                        foreach($PsbTagihanRecords as $record) 
				                        {
				                    ?>
				                    <tr>
				                      <td class="text-center"><?php echo $i ?>.</td>
				                      <td><?php echo $record->jenis_biaya ?></td>
				                      <td><?php echo 'Rp. '.number_format($record->harga) ?></td>
				                      <td><?php echo $record->DateCreated ?></td>
				                      <td><?php echo 'Rp. '.number_format($record->jumlah_bayar) ?></td>
				                      <td class="text-center">
				                          <a class="btn btn-flat btn-xs btn-success" href="<?php echo base_url().'bayar/'.$record->id_psb_harus_bayar; ?>"><i class="fa  fa-paper-plane"> </i>  BAYAR</a>
				                          <a class="btn btn-flat btn-xs btn-danger" href="<?php echo base_url().'bayar/'.$record->id_psb_harus_bayar; ?>"><i class="fa  fa-print"> </i>  PRINT</a>
				                      </td>
				                    </tr>
				                    <?php
				                    $i++;
				                        }
				                    }
				                    ?>
				                </table>
				                <div class="button" align="right">
							        <a class="btn btn-flat btn-success" href="<?php echo base_url(); ?>list-bayar-psb"><i></i>BAYAR</a>
							    </div>
					        	</div-->
					        	<div class="modal fade" id="modal-default">
						          <div class="modal-dialog">
						            <div class="modal-content">
						            	<form role="form" action="<?php echo base_url() ?>add-beban-bayar" method="post" role="form">
						              <div class="modal-header">
						                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						                  <span aria-hidden="true">&times;</span></button>
						                <h4 class="modal-title">Pembiayaan Peserta Didik Baru</h4>
						              </div>
						              <div class="modal-body">
						              	<div class="table-responsive">
						                <table class="table table-bordered"> 
	                            	<thead>
				                    <tr>
				                      <th class="text-center" width="5">NO</th>
				                      <th class="text-center">JENIS BIAYA</th>
				                      <th class="text-center">HARGA</th>
				                      <th class="text-center">Actions</th>
				                    </tr>
				                    </thead>
					              <?php
				                    if(!empty($PsbBiayaRecords))
				                    { $i=1;
				                        foreach($PsbBiayaRecords as $record) 
				                        {
				                    ?>
				                    <tr>
				                      <td class="text-center"><?php echo $i ?>.</td>
				                      <td><?php echo $record->jenis_biaya ?></td>
				                      <td><?php echo 'Rp. '.number_format($record->harga) ?></td>
				                      <td class="text-center">
				                          <input type="checkbox" name="check_list[]" alt="Checkbox" value="<?php echo $id_biaya_psb; ?>" onclick="select($row->$id_biaya_psb)">
				                          <input type="hidden" value="<?php echo $id_pendaftaran; ?>" name="id_pendaftaran" id="id_pendaftaran"/>
				                          <input type="hidden" value="<?php echo $id_biaya_psb; ?>" name="id_biaya_psb" id="id_biaya_psb"/>
				                      </td>
				                    </tr>
				                    <?php
				                    $i++;
				                        }
				                    }
				                    ?>
				                		</table>
					                </div>
						              </div>
						              <div class="modal-footer">
						                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						                <button type="submit" name="submit" class="btn btn-primary">Save changes</button>
						              </div>
						          </form>
						            </div>
						            <!-- /.modal-content -->
						          </div>
						          <!-- /.modal-dialog -->
						        </div>
						        <!-- /.modal -->
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
        </div>    
    </section>
</div>
</div>
<?php
}
}
?>

<script type="text/javascript">
	function loadBiaya()
    {
        var kategori = $("#filter_kategori").val();
        var Biaya         = $("#filter_biaya").val();
        $.ajax({
            type    : 'GET',
            url     : '<?php echo base_url() ?>PsbBiaya/tampil_biaya', 
            data    : 'id='+kategori+'&id_biaya_psb='+Biaya,
            success : function(html) {
                $("#tampilBiaya").html(html);
                loadTagihan();
            }
        })
    }

    function loadTagihan()
    {
        var kategori = $("#filter_kategori").val();
        var Biaya         = $("#filter_biaya").val();
        //var kelas          = $("#kelas").val();
        $.ajax({
            type    : 'GET',
            url     : '<?php echo base_url() ?>PsbBayar/dataTagihan',
            data    : 'id='+kategori+'&id_biaya_psb='+Biaya,
            success : function(html) {
                $("#table_tagihan").html(html);
            }
        })
    }
</script>