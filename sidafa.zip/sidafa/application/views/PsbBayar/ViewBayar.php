
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Pembayaran Siswa Baru
        <small>Management Data</small>
        <div class="button" align="right">
	        <a class="btn btn-flat btn-primary" href="<?php echo base_url(); ?>list-bayar-psb"><i></i>Kembali</a>
	    </div>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Data Siswa Baru</h3>                        
                    </div><!-- /.box-header -->
                    <!-- form start -->
                        <div class="box-body">
                            <?php

							  if(!empty($psbsiswaInfo))
							  {	
							      foreach($psbsiswaInfo as $record) 
							      {	
							?>
                            <!--p align="center">Status :<a> <?php echo $record->keaktifan ?></a></p-->
                            <div class="col-xs-12">
	                            <div class="table-responsive">
	                            <table class="table table-bordered">
					              <tbody>
					              <tr>
					                <th style="width:10px">Nama Lengkap </th> 
					                <td style="width:120px"><a><strong><?php echo $record->nama ?></strong></a></td>
					                <th style="width:10px">Tahun Masuk </th>
					                <td style="width:120px"><a><strong><?php echo $record->tahun_masuk ?></strong></a></td>
					              </tr>
					              <tr>
					                <th style="width:10px">NISN </th> 
					                <td style="width:120px"><a><strong><?php echo $record->nisn ?></strong></a></td>
					                <th style="width:10px">Alamat </th>
					                <td style="width:120px"><a><strong><?php echo $record->desa ?>, RT <?php echo $record->rt ?> RW <?php echo $record->rw ?> <?php echo $record->kecamatan ?> - <?php echo $record->kabupaten ?></strong></a></td>
					              </tr>
					            </tbody></table>
					        	</div>
                            </div>
                        </div><!-- /.box-body -->
                </div>
            </div>
            <!--div class="col-md-6">
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">RINCIAN PEMBIAYAAN</h3>                        
                    </div><!-- /.box-header -->
                    <!-- form start -->
                        <!--div class="box-body">
                            <div class="col-xs-12">
                            	<h4 class="box-title">Jenis Biaya</h4> 
	                            <div class="table-responsive">
	                            <table class="table table-bordered">
	                            	<thead>
				                    <tr>
				                      <th class="text-center" width="5">NO</th>
				                      <th class="text-center">JENIS BIAYA</th>
				                      <th class="text-center">HARGA</th>
				                      <th class="text-center">Actions</th>
				                    </tr>
				                    </thead>
					              <?php
				                    if(!empty($Psb_Records))
				                    { $i=1;
				                        foreach($Psb_Records as $record) 
				                        {
				                    ?>
				                    <tr>
				                      <td class="text-center"><?php echo $i ?>.</td>
				                      <td><?php echo $record->jenis_biaya ?></td>
				                      <td><?php echo 'Rp. '.number_format($record->harga) ?></td>
				                      <td class="text-center">
				                          <a class="add_cart btn btn-flat btn-sm btn-warning" href="<?php echo base_url().'add-to-cart/'.$record->id_biaya_psb; ?>"><i class="fa fa-shopping-cart"></i></a>
				                      </td>
				                    </tr>
				                    <?php
				                    $i++;
				                        }
				                    }
				                    ?>
				                </table>
					        	</div>
                            </div>
                        </div>
                    </div>
                </div-->
                <div class="col-md-6">
                <div class="box box-success">
                	<h3></h3>
                    <div class="col-xs-12 text-right">
                    	<button type="button" class="btn btn-flat btn-warning" data-toggle="modal" data-target="#modal-tambah">TAMBAH <i class="fa fa-shopping-cart"></i></button>                        
                    </div><!-- /.box-header -->
                    <div class="box-body">
                            <div class="col-xs-12">
                            	<h4 class="box-title"><i class="fa fa-shopping-cart"></i> Biaya yang harus dibayar</h4>
	                            <div id="tabel"></div>
				                <p>Jumlah yang harus dibayar ....</p>
				                <div class="button" align="right">
							        <!--a class="btn btn-flat btn-success" href="<?php echo base_url(); ?>list-bayar-psb"><i></i>BAYAR</a-->
							    </div>
							    <button type="button" class="btn btn-flat btn-success" data-toggle="modal" data-target="#modal-default">BAYAR</button>
					        	</div>


					        	<div class="modal fade" id="modal-default">
						          <div class="modal-dialog">
						            <div class="modal-content">
						              <div class="modal-header">
						                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						                  <span aria-hidden="true">&times;</span></button>
						                <h4 class="modal-title">Pembiayaan Peserta Didik Baru</h4>
						              </div>
						              <div class="modal-body">
						              	<div class="table-responsive">
						                <table class="table table-bordered">
		                            	<thead>
					                    <tr>
					                      <th class="text-center" width="5">NO</th>
					                      <th class="text-center">JENIS BIAYA</th>
					                      <th class="text-center">HARGA</th>
					                      <th class="text-center">BAYAR</th>
					                    </tr>
					                    </thead>
					                    <td class="text-center">1</td>
					                    <td class="text-center">Infaq</td>
					                    <td class="text-center">Rp.350.000,-</td>
					                    <td class="text-center"><input type="text" name=""></td>
					                    </table>
					                </div>
						              </div>
						              <div class="modal-footer">
						                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
						                <button type="button" class="btn btn-primary">Save changes</button>
						              </div>
						            </div>
						            <!-- /.modal-content -->
						          </div>
						          <!-- /.modal-dialog -->
						        </div>
						        <!-- /.modal -->

						        <!--Modal-Tambah-->
						        <div class="modal fade" id="modal-tambah">
						          <div class="modal-dialog">
						            <div class="modal-content">
						              <div class="modal-header">
						                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						                  <span aria-hidden="true">&times;</span></button>
						                <h4 class="modal-title">Pembiayaan Peserta Didik Baru</h4>
						              </div>
						              <form role="form" id="AddBeban" action="<?php echo base_url() ?>PsbBayar/AddBeban" method="post" role="form">
						              <div class="modal-body">
						              	<div class="table-responsive">
						                <table class="table table-bordered">
		                            	<thead>
					                    <tr>
					                      <th class="text-center" width="5">NO</th>
					                      <th class="text-center">JENIS BIAYA</th>
					                      <th class="text-center">HARGA</th>
					                      <th class="text-center"><input type="checkbox" name="select_all" onclick="AddBeban()"></th>
					                    </tr>
					                    </thead>
					                    	<?php
						                    if(!empty($PsbBiayaRecords))
						                    { $i=1;
						                        foreach($PsbBiayaRecords as $record) 
						                        {
						                    ?>
						                    <tr>
						                      <td class="text-center"><?php echo $i ?>.</td>
						                      <td><?php echo $record->jenis_biaya ?></td>
						                      <td><?php echo 'Rp. '.number_format($record->harga) ?></td>
						                      <td class="text-center">
						                          <input type="checkbox" name="tambahbeban" onclick="AddBeban()">
						                      </td>
						                    </tr>
						                    <?php
						                    $i++;
						                        }
						                    }
						                    ?>
							                    </table>
							                </div>
						            </div>
						              <div class="modal-footer">
						                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
						                <button type="submit" class="btn btn-primary">Save changes</button>
						              </div>
						          </form>
						            </div>
						            <!-- /.modal-content -->
						          </div>
						          <!-- /.modal-dialog -->
						        </div>
						        <!-- /.modal -->
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
        </div>    
    </section>
</div>
<?php
}
}
?>

<script type="text/javascript">
	$(document ).ready(function(){
		loadData();
	});
</script>

<script type="text/javascript">
	function loadData(){
		//var pendaftaran = $id_pendaftaran;
		$.ajax({
			url: '<?php echo base_url(); ?>PsbBayar/dataPSBBayar',
			type: 'GET',
			//dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
			data: '',
			success: function(html){
				$("#tabel").html(html);
			}
		});
	}

	function filterData(){
		alert('filter');
	}
</script>

<script type="text/javascript">
	function AddBeban($id_pendaftaran){
		var tambahbeban = $("tambahbeban").val();
		$.$.ajax({
			type: 'GET',
			url: '<?php echo base_url(); ?>PsbBayar/AddBeban',
			//dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
			data: 'tambahbeban'+tambahbeban+'&id_pendaftaran='+id_pendaftaran,
			success:function(html){
				alert('Woi');
			}
		});
		
		
	}
</script>

<!--script type="text/javascript">
	$(document).ready(function(){
        $('.add_cart').click(function(){
            var id_psb_harus_bayar    = $(this).data("id_psb_harus_bayar   ");
            var id_pendaftaran = $(this).data("id_pendaftaran");
            var id_biaya_psb = $(this).data("id_biaya_psb");
			var status = $(this).data("status");
            //var quantity     = $('#' + produk_id).val();
            $.ajax({
                url : "<?php echo base_url();?>PsbBayar/add_to_cart",
                method : "POST",
                data : {id_psb_harus_bayar   : id_psb_harus_bayar   , id_pendaftaran: id_pendaftaran, id_biaya_psb: id_biaya_psb, status: status},
                success: function(data){
                    $('#detail_cart').html(data);
                }
            });
        });
 
        // Load shopping cart
        $('#detail_cart').load("<?php echo base_url();?>PsbBayar/load_cart");
 
        //Hapus Item Cart
        $(document).on('click','.hapus_cart',function(){
            var row_id=$(this).attr("id"); //mengambil row_id dari artibut id
            $.ajax({
                url : "<?php echo base_url();?>PsbBayar/hapus_cart",
                method : "POST",
                data : {row_id : row_id},
                success :function(data){
                    $('#detail_cart').html(data);
                }
            });
        });
    });
</script-->