
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Pembayaran Siswa Baru
        <small>Management Data</small>
        <div class="button" align="right">
	        <a class="btn btn-flat btn-primary" href="<?php echo base_url(); ?>list-bayar-psb"><i></i>Kembali</a>
	    </div>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Data Siswa Baru</h3>                        
                    </div><!-- /.box-header -->
                    <!-- form start -->
                        <div class="box-body">
                            <?php

							  if(!empty($psbsiswaInfo))
							  {	
							      foreach($psbsiswaInfo as $record) 
							      {	
							?>
                            <!--p align="center">Status :<a> <?php echo $record->keaktifan ?></a></p-->
                            <div class="col-xs-12">
	                            <div class="table-responsive">
	                            <table class="table table-bordered">
					              <tbody>
					              <tr>
					                <th style="width:10px">Nama Lengkap </th> 
					                <td style="width:120px"><a><strong><?php echo $record->nama ?></strong></a></td>
					                <th style="width:10px">Tahun Masuk </th>
					                <td style="width:120px"><a><strong><?php echo $record->tahun_masuk ?></strong></a></td>
					              </tr>
					              <tr>
					                <th style="width:10px">NISN </th> 
					                <td style="width:120px"><a><strong><?php echo $record->nisn ?></strong></a></td>
					                <th style="width:10px">Alamat </th>
					                <td style="width:120px"><a><strong><?php echo $record->desa ?>, RT <?php echo $record->rt ?> RW <?php echo $record->rw ?> <?php echo $record->kecamatan ?> - <?php echo $record->kabupaten ?></strong></a></td>
					              </tr>
					            </tbody></table>
					            <div>
					            	<button type="button" class="btn btn-flat btn-warning" data-toggle="modal" data-target="#modal-tambah">TAMBAH PEMBAYARAN <i class="fa fa-shopping-cart"></i></button>
					            </div>
					        	</div>
                            </div>
                        </div><!-- /.box-body -->
                </div>
            </div>
                <div class="col-md-12">
                <div class="box box-success">
                	<h3></h3>
                    <div class="box-body">
                            <div class="col-xs-12">
                            	<h4 class="box-title"><i class="fa fa-shopping-cart"></i> Biaya yang harus dibayar</h4>
                            	<div class="table-responsive">
						                <table class="table table-bordered">
		                            	<thead>
					                    <tr>
					                      <th class="text-center" width="5">NO</th>
					                      <th class="text-center">JENIS BIAYA</th>
					                      <th class="text-center">NOMINAL</th>
					                      <th class="text-center">DIBAYAR</th>
					                      <th class="text-center">Status</th>
					                      <th class="text-center" width="10">Action</th>
					                      <!--th class="text-center"><input type="checkbox" name="select_all" onclick="AddBeban()"></th-->
					                    </tr>
					                    </thead>
					                    	<?php
						                    if(!empty($PsbBayarRecords))
						                    { $i=1;
						                        foreach($PsbBayarRecords as $record) 
						                        {
						                    ?>
						                    <tr>
						                      <td class="text-center"><?php echo $i ?>.</td>
						                      <td><?php echo $record->jenis_biaya ?></td>
						                      <td><?php echo 'Rp. '.number_format($record->harga) ?></td>
						                      <td class="text-center">
						                       <td></td>
						                       <td><a class="btn btn-flat btn-sm btn-info" href="">Bayar</a></td>
						                    </tr>
						                    <?php
						                    $i++;
						                        }
						                    }
						                    ?>
							                    </table>
							                </div>
						            </div>
				                <p>Jumlah yang harus dibayar ....</p>
							    <div class="col-xs-12 text-right">
                    	<button type="button" class="btn btn-flat btn-success" data-toggle="modal" data-target="#">BAYAR <i class="fa fa-shopping-cart"></i></button>                        
                    </div><!-- /.box-header -->
					        	</div>

						        <!--Modal-Tambah-->
						        <div class="modal fade" id="modal-tambah">
						          <div class="modal-dialog">
						            <div class="modal-content">
						              <div class="modal-header">
						                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						                  <span aria-hidden="true">&times;</span></button>
						                <h4 class="modal-title">Pembiayaan Peserta Didik Baru</h4>
						              </div>
						              <form role="form" id="AddBeban" action="<?php echo base_url() ?>PsbBayar/AddBeban" method="post" role="form">
						              <div class="modal-body">
						              	<div class="table-responsive">
						                <table class="table table-bordered">
		                            	<thead>
					                    <tr>
					                      <th class="text-center" width="5">NO</th>
					                      <th class="text-center">JENIS BIAYA</th>
					                      <th class="text-center">HARGA</th>
					                      <th class="text-center"><input type="checkbox" name="select_all" onclick="AddBeban()"></th>
					                    </tr>
					                    </thead>
					                    	<?php
						                    if(!empty($PsbBiayaRecords))
						                    { $i=1;
						                        foreach($PsbBiayaRecords as $record) 
						                        {
						                    ?>
						                    <tr>
						                      <td class="text-center"><?php echo $i ?>.</td>
						                      <td><?php echo $record->jenis_biaya ?></td>
						                      <td><?php echo 'Rp. '.number_format($record->harga) ?></td>
						                      <td class="text-center">
						                          <input type="checkbox" name="tambahbeban" onchange="AddBeban($record->id_pendaftaran)">
						                      </td>
						                    </tr>
						                    <?php
						                    $i++;
						                        }
						                    }
						                    ?>
							                    </table>
							                </div>
						            </div>
						              <div class="modal-footer">
						                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
						                <button type="submit" class="btn btn-primary">Save changes</button>
						              </div>
						          </form>
						            </div>
						            <!-- /.modal-content -->
						          </div>
						          <!-- /.modal-dialog -->
						        </div>
						        <!-- /.modal -->
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
        </div>    
    </section>
</div>
<?php
}
}
?>

<script type="text/javascript">
	function AddBeban(id_pendaftaran){
		var tambahbeban = $("#tambahbeban").val();
		$.ajax({
			type: 'GET',
			url: '<?php echo base_url(); ?>PsbBayar/AddBeban',
			//dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
			data: 'tambahbeban'+tambahbeban+'&id_pendaftaran='+id_pendaftaran,
			success:function(html){
				alert('Woi');
			}
		})
		
		
	}
</script>