<?php

$id_penghasilan = '';
$penghasilan = '';
$ket_penghasilan = '';
$id_aktif = '';

if(!empty($penghasilanInfo))
{
    foreach ($penghasilanInfo as $phs)
    {
        $id_penghasilan = $phs->id_penghasilan;
        $penghasilan = $phs->penghasilan;
        $ket_penghasilan = $phs->ket_penghasilan;
        $id_aktif = $phs->id_aktif;
    }
}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Penghasilan Management
        <small>Add / Edit Penghasilan</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>edit-data-penghasilan" method="post" id="EditPenghasilan" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="penghasilan">Penghasilan</label>
                                        <input type="text" class="form-control" id="penghasilan" placeholder="Jumlah Penghasilan" name="penghasilan" value="<?php echo $penghasilan; ?>" maxlength="30">
                                        <input type="hidden" value="<?php echo $id_penghasilan; ?>" name="id_penghasilan" id="id_penghasilan" />    
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status">Keaktifan</label>
                                        <select class="form-control required" id="status" name="status">
                                        <option value="0">Pilih Keaktifan</option>
                                            <?php
                                            if(!empty($status))
                                            {
                                                foreach ($status as $ak)
                                                {
                                                    ?>
                                                    <option value="<?php echo $ak->id_aktif; ?>" <?php if($ak->id_aktif == $id_aktif) {echo "selected=selected";} ?>><?php echo $ak->keaktifan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                            	<div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="ket_penghasilan">Keterangan</label>
                                        <input type="text" class="form-control required" id="ket_penghasilan" placeholder="Keterangan Penghasilan" name="ket_penghasilan" value="<?php echo $ket_penghasilan; ?>" maxlength="50">    
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-flat btn-primary" value="Simpan" />
                            <a class="btn btn-flat btn-danger" href="<?php echo base_url(); ?>list-penghasilan"><i></i>Kembali</a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script type="text/javascript">
	$(document).ready(function(){
	
	var EditPenghasilanForm = $("#EditPenghasilan");
	
	var validator = EditPenghasilanForm.validate({
		
		rules:{
			penghasilan :{ required : true },
			ket_penghasilan : { required : true },
			status : { required : true, selected : true}
		},
		messages:{
			penghasilan :{ required : "This field is required" },
			ket_penghasilan : { required : "This field is required"},
			status : { required : "This field is required", selected : "Please select atleast one option" }			
		}
	});
});
</script>