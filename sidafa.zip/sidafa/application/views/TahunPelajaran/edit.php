<?php

$id_tahun_pelajaran = '';
$tahun_pelajaran = '';
$ket_tahun_pelajaran = '';
$id_aktif = '';

if(!empty($tpInfo))
{
    foreach ($tpInfo as $tp)
    {
        $id_tahun_pelajaran = $tp->id_tahun_pelajaran;
        $tahun_pelajaran = $tp->tahun_pelajaran;
        $ket_tahun_pelajaran = $tp->ket_tahun_pelajaran;
        $id_aktif = $tp->id_aktif;
    }
}


?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Tahun Pelajaran
        <small>Add / Edit Data</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Data Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" action="<?php echo base_url() ?>editData" method="post" id="editTP" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="tahun_pelajaran">Tahun Pelajaran</label>
                                        <input type="text" class="form-control" id="tahun_pelajaran" placeholder="Tahun Pelajaran" name="tahun_pelajaran" value="<?php echo $tahun_pelajaran; ?>" maxlength="20">
                                        <input type="hidden" value="<?php echo $id_tahun_pelajaran; ?>" name="id_tahun_pelajaran" id="id_tahun_pelajaran" />    
                                    </div>
                                    
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status">Keaktifan</label>
                                        <select class="form-control" id="status" name="status">
                                        <option value="0">Pilih Keaktifan</option>
                                            <?php
                                            if(!empty($status))
                                            {
                                                foreach ($status as $ak)
                                                {
                                                    ?>
                                                    <option value="<?php echo $ak->id_aktif; ?>" <?php if($ak->id_aktif == $id_aktif) {echo "selected=selected";} ?>><?php echo $ak->keaktifan ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="ket_tahun_pelajaran">Keterangan</label>
                                        <input type="text" class="form-control" id="ket_tahun_pelajaran" placeholder="Keterangan Tahun Pelajaran" name="ket_tahun_pelajaran" value="<?php echo $ket_tahun_pelajaran; ?>" maxlength="50">
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>

<script type="text/javascript">
    $(document).ready(function(){
    
    var editTPForm = $("#editTP");
    
    var validator = editTPForm.validate({
        
        rules:{
            tahun_pelajaran :{ required : true},
            ket_tahun_pelajaran : { required : true},
            status : { required : true, selected : true}
        },
        messages:{
            tahun_pelajaran :{ required : "This field is required" },
            ket_tahun_pelajaran : { required : "This field is required" },
            status : { required : "This field is required", selected : "Please select atleast one option" }           
        }
    });
});
</script>