Add.php<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Data Pembayaran
        <small>Management Data</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-5">
              <div class="box box-warning">
                <div class="box-header">
                    <h3 class="box-title">Filter Data</h3>
                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
            <div class="box-body">
            <table class="table table-bordered">
                <tr><td width="30%">Kelas</td><td><?php echo cmb_dinamis('kelas', 'tbl_kelas', 'nama_kelas', 'id_kelas', null, "id='kelas' class='select2' onChange='loadRombel()'") ?></td></tr>
                <tr><td width="30%">Rombel</td><td><div id="showRombel"></div></td></tr>
                <tr><td width="30%">Nama Siswa</td><td><div id="showSiswa"></div></td></tr>
                <tr><td colspan="2">
                    <!--?php echo anchor('Pembayaran/AddTagihan/'.$this->uri->segment(3), '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> Tambah Data', "title='Tambah Data' class='btn btn-flat btn-danger btn-sm'"); ?>
                    <!?php echo anchor('dashboard','Kembali',"class='btn btn-success btn-flat btn-sm'");?-->
                    </td></tr>
            </table>
            </div>
            <!-- /.box-body -->
              	</div><!-- /.box -->
            </div>
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-body">
                            <div id="tabel"></div>
					</div>    
				</div>
			</div>
        </div>
    </section>
</div>
<script type="text/javascript">
    $(document ).ready(function() {
        loadRombel();
        loadSiswa();
        loadTagihan();
    });
</script>

<script type="text/javascript">
   
    function loadRombel(){
        var rombel  = $("#rombel").val();
        var kelas= $("#kelas").val();

        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/showrombel',
            data:'rombel='+rombel+'&kelas='+kelas,
            success:function(html){
                $("#showRombel").html(html);
                loadSiswa();
            }
        })
    }

    function loadSiswa(){
        var siswa  = $("#siswa").val();
        var rombel= $("#rombel").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/showsiswa',
            data:'siswa='+siswa+'&rombel='+rombel,
            success:function(html){
                $("#showSiswa").html(html);
                loadTagihan();
            }
        })
    }
    
    function loadTagihan(){
        var siswa   =$("#siswa").val();
        var rombel =$("#rombel").val();
        var kelas   =$("#kelas").val();
        var bayar  =$("#bayar").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/ShowTagihan', 
            data:'rombel='+rombel+'&kelas='+kelas+'&siswa='+siswa+'&bayar='+bayar+'&id_pendaftaran=<?php echo $this->uri->segment(3) ?>',
            success:function(html){
                $("#tabel").html(html);
                //loadRombel();
            }
        })
    }
</script>