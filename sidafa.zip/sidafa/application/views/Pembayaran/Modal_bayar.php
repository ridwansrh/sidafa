<!-- Modal -->
<div class="modal fade" id="bayar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <?php
            echo form_open('Pembayaran/AddTagihan');
            ?>
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Bayar Tagihan</h4>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <?php
                    $siswa          = $_GET['siswa'];
                    $kelas          = $_GET['kelas'];
                    //$id_kurikulum = $_GET['id_kurikulum'];
                    $rombel         = $_GET['rombel']; 
                    
                    $sql = "SELECT  tb.jenis_biaya,tb.harga,thb.jumlah_bayar,thb.status, thb.id_psb_harus_bayar, thb.id_tahun_pelajaran
                FROM tbl_psb_harus_bayar as thb, tbl_psb_biaya as tb, tbl_psb_siswa as ts
                WHERE thb.id_pendaftaran=ts.id_pendaftaran and thb.id_biaya_psb=tb.id_biaya_psb and thb.id_pendaftaran=$siswa and thb.id_tahun_pelajaran=".  get_tahun_pelajaran_aktif('id_tahun_pelajaran');
                $tagihan = $this->db->query($sql)->result();
                $no=1;
                    foreach ($tagihan as $row) { ?>
                <tr><td width="30%"><?php echo $row->id_psb_harus_bayar ?></div></td></tr>
                <?php } ?>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Tutup</button>
                <button type="submit" name="submit" class="btn btn-warning btn-flat">Bayar</button>
            </div>
            </form>
        </div>
    </div>
</div>