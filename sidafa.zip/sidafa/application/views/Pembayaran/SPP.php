<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Pembayaran SPP
        <small>Management Data</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-4">
              <div class="box box-warning">
                <div class="box-header">
                    <h3 class="box-title">Filter Data</h3>
                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
            <div class="box-body">
            <?php
            echo form_open('Pembayaran/AddBayarSPP'); 
            ?>
            <table class="table table-bordered">
                <tr><td width="30%">Kelas</td><td><?php echo cmb_dinamis('kelas', 'tbl_kelas', 'nama_kelas', 'id_kelas', null, "id='kelas' class='select2' onChange='loadRombel()'") ?></td></tr>
                <tr><td width="30%">Rombel</td><td><div id="showRombel"></div></td></tr>
                <tr><td width="30%">Nama Siswa</td><td><div id="showSiswa"></div></td></tr>
                <tr><td width="30%">Jenis Biaya</td><td><div id="showBiaya"></div></td></tr>
                <tr><td width="30%">Tahun Pelajaran</td><td><?php echo cmb_dinamis('tapel', 'tbl_tahun_pelajaran', 'tahun_pelajaran', 'id_tahun_pelajaran', get_tahun_pelajaran_aktif('id_tahun_pelajaran'), null, "id='tapel'") ?></div></td></tr>
                <tr><td width="30%">Jumlah Bayar</td><td><input type="text" name="jumlah_bayar" value="0"></div></td></tr>
                <tr><td width="30%">Keterangan</td><td><input type="text" name="keterangan"></div></td></tr>
                <tr><td colspan="2">
                <!--button type="button" class="btn btn-danger btn-sm btn-flat" data-toggle="modal" data-target="#myModal">
                    <i class="fa fa-pencil-square-o" aria-hidden="true"></i> Tambah Data
                </button-->
                <button type="submit" name="submit" align="right" class="btn btn-success btn-flat">Bayar</button>
                    <!--?php echo anchor('Pembayaran/AddTagihan/'.$this->uri->segment(3), '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> Tambah Data', "title='Tambah Data' class='btn btn-flat btn-danger btn-sm'"); ?>
                    <!?php echo anchor('dashboard','Kembali',"class='btn btn-success btn-flat btn-sm'");?-->
                    </td></tr>
            </table>
            </form>
            </div>
            <!-- /.box-body -->
                </div><!-- /.box -->
            </div>
            <div class="col-md-8">
                <div class="box box-success">
                    <div class="box-body">
                            <div id="tabel"></div>
                    </div>    
                </div>
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
    $(document ).ready(function() {
        loadRombel();
        loadSiswa();
        loadBiaya();
        loadTagihan();
    });
</script>

<script type="text/javascript">
   
    function loadRombel(){
        var rombel  = $("#rombel").val();
        var kelas= $("#kelas").val();

        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/show_rombel',
            data:'rombel='+rombel+'&kelas='+kelas,
            success:function(html){
                $("#showRombel").html(html);
                loadSiswa();
                loadBiaya();
            }
        })
    }

    function loadSiswa(){
        var siswa  = $("#siswa").val();
        var rombel= $("#rombel").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/show_siswa',
            data:'siswa='+siswa+'&rombel='+rombel,
            success:function(html){
                $("#showSiswa").html(html);
                loadTagihan();
            }
        })
    }

    function loadBiaya(){
        var biaya  = $("#biaya").val();
        var kelas= $("#kelas").val();

        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/load_biaya_spp',
            data:'biaya='+biaya+'&kelas='+kelas,
            success:function(html){
                $("#showBiaya").html(html);
                //loadSiswa();
                loadTagihan();
            }
        })
    }
    
    function loadTagihan(){
        var siswa   =$("#siswa").val();
        var rombel =$("#rombel").val();
        var kelas   =$("#kelas").val();
        var biaya  =$("#biaya").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/ShowTagihanSPP', 
            data:'rombel='+rombel+'&kelas='+kelas+'&siswa='+siswa+'&biaya='+biaya+'&id_siswa=<?php echo $this->uri->segment(3) ?>',
            success:function(html){
                $("#tabel").html(html);
                //loadRombel();
            }
        })
    }
</script>


<script type="text/javascript">
    function load_Rombel(){
        var rombel  = $("#rombel").val();
        var kelas= $("#kelas").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/rombelload',
            data:'rombel='+rombel+'&kelas='+kelas,
            success:function(html){
                $("#tampilRombel").html(html);
                $("#modal-body").modal('tampilRombel');
                load_Siswa();
            }
        })
    }

    function load_Siswa(){
        var siswa  = $("#siswa").val();
        var rombel= $("#rombel").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/siswaload',
            data:'siswa='+siswa+'&rombel='+rombel,
            success:function(result){
                $("#tampilSiswa").html(result);
                //loadTagihan();
            }
        })
    }
</script>

<script type="text/javascript">
  jQuery(document).ready(function(){
  
  jQuery(document).on("click", ".deletePembayaran", function(){
    var id_pembayaran = $(this).data("id_pembayaran"),
      hitURL = baseURL + "deletePembayaran",
      currentRow = $(this);
    
    var confirmation = confirm("Are you sure to delete this data ?");
    
    if(confirmation)
    {
      jQuery.ajax({
      type : "POST",
      dataType : "json",
      url : hitURL,
      data : { id_pembayaran : id_pembayaran } 
      }).done(function(data){
        console.log(data);
        currentRow.parents('tr').remove();
        if(data.status = true) { alert("Data successfully deleted"); }
        else if(data.status = false) { alert("Data deletion failed"); }
        else { alert("Access denied..!"); }
      });
    }
  });
  
  
  jQuery(document).on("click", ".searchList", function(){
    
  });
  
});
</script>

