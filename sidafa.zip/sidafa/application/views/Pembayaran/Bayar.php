<?php

$id_psb_harus_bayar = '';
$id_pendaftaran     = '';
$id_biaya_psb       ='';
$jumlah_bayar       = '';
$id_tahun_pelajaran = '';
$id_kelas           ='';
$id_rombel          = '';
$status             = '';

if(!empty($psbbiayaInfo))
{
    foreach ($psbbiayaInfo as $pb)
    {
        $id_psb_harus_bayar = $pb->id_psb_harus_bayar;
        $id_pendaftaran     = $pb->id_pendaftaran;
        $id_biaya_psb       = $pb->id_biaya_psb;
        $jumlah_bayar       = $pb->jumlah_bayar;
        $id_tahun_pelajaran = $pb->id_tahun_pelajaran;
        $id_kelas           = $pb->id_kelas;
        $id_rombel          = $pb->id_rombel;
        $status             = $pb->status;
    }
}
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Data Pembayaran
        <small>Management Data</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
              <!-- general form elements -->
                <div class="box box-success">
                    <div class="box-header">
                        <h3 class="box-title">Data Bayar</h3>                        
                    </div><!-- /.box-header -->
                    <!-- form start -->
                        <div class="box-body">
                            <?php

                              if(!empty($psbsiswaInfo))
                              { 
                                  foreach($psbsiswaInfo as $record) 
                                  { 
                            ?>
                            <!--p align="center">Status :<a> <?php echo $record->keaktifan ?></a></p-->
                            <div class="col-xs-12">
                                <div class="table-responsive">
                                <table class="table table-bordered">
                                  <tbody>
                                  <tr>
                                    <th style="width:10px">Nama Lengkap </th> 
                                    <td style="width:120px"><a><strong><?php echo $record->nama ?></strong></a></td>
                                    <th style="width:10px">Tahun Masuk </th>
                                    <td style="width:120px"><a><strong><?php echo $record->tahun_masuk ?></strong></a></td>
                                  </tr>
                                  <tr>
                                    <th style="width:10px">NISN </th> 
                                    <td style="width:120px"><a><strong><?php echo $record->nisn ?></strong></a></td>
                                    <th style="width:10px">Alamat </th>
                                    <td style="width:120px"><a><strong><?php echo $record->desa ?>, RT <?php echo $record->rt ?> RW <?php echo $record->rw ?> <?php echo $record->kecamatan ?> - <?php echo $record->kabupaten ?></strong></a></td>
                                  </tr>
                                </tbody></table>
                                </div>
                            </div>
                        </div><!-- /.box-body -->
                </div>
            </div>
        </div>
    </section>
</div>
<?php
}
}
?>