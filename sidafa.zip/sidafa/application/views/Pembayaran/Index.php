<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-bars"></i> Data Pembayaran
        <small>Management Data</small>
      </h1>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-5">
              <div class="box box-warning">
                <div class="box-header">
                    <h3 class="box-title">Filter Data</h3>
                    <div class="box-tools">
                    </div>
                </div><!-- /.box-header -->
            <div class="box-body">
            <?php
            echo form_open('Pembayaran/AddTagihan'); 
            ?>
            <table class="table table-bordered">
                <tr><td width="30%">Kelas</td><td><?php echo cmb_dinamis('kelas', 'tbl_kelas', 'nama_kelas', 'id_kelas', null, "id='kelas' class='select2' onChange='loadRombel()'") ?></td></tr>
                <tr><td width="30%">Rombel</td><td><div id="showRombel"></div></td></tr>
                <tr><td width="30%">Nama Siswa</td><td><div id="showSiswa"></div></td></tr>
                <tr><td width="30%">Jenis Biaya</td><td><div id="showBiaya"></div></td></tr>
                <tr><td width="30%">Tahun Pelajaran</td><td><?php echo cmb_dinamis('tapel', 'tbl_tahun_pelajaran', 'tahun_pelajaran', 'id_tahun_pelajaran', get_tahun_pelajaran_aktif('id_tahun_pelajaran'), null, "id='tapel'") ?></div></td></tr>
                <tr><td width="30%">Jumlah Bayar</td><td><input type="text" name="jumlah_bayar" value="0"></div></td></tr>
                <tr><td width="30%">Keterangan</td><td><input type="text" name="keterangan"></div></td></tr>
                <tr><td colspan="2">
                <!--button type="button" class="btn btn-danger btn-sm btn-flat" data-toggle="modal" data-target="#myModal">
                    <i class="fa fa-pencil-square-o" aria-hidden="true"></i> Tambah Data
                </button-->
                <button type="submit" name="submit" align="right" class="btn btn-success btn-flat">Bayar</button>
                    <!--?php echo anchor('Pembayaran/AddTagihan/'.$this->uri->segment(3), '<i class="fa fa-pencil-square-o" aria-hidden="true"></i> Tambah Data', "title='Tambah Data' class='btn btn-flat btn-danger btn-sm'"); ?>
                    <!?php echo anchor('dashboard','Kembali',"class='btn btn-success btn-flat btn-sm'");?-->
                    </td></tr>
            </table>
            </form>
            </div>
            <!-- /.box-body -->
                </div><!-- /.box -->
            </div>
            <div class="col-md-12">
                <div class="box box-success">
                    <div class="box-body">
                            <div id="tabel"></div>
                    </div>    
                </div>
            </div>
        </div>
    </section>
</div>
<script type="text/javascript">
    $(document ).ready(function() {
        loadRombel();
        loadSiswa();
        loadBiaya();
        loadTagihan();
    });
</script>

<script type="text/javascript">
   
    function loadRombel(){
        var rombel  = $("#rombel").val();
        var kelas= $("#kelas").val();

        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/show_rombel',
            data:'rombel='+rombel+'&kelas='+kelas,
            success:function(html){
                $("#showRombel").html(html);
                loadSiswa();
                loadBiaya();
            }
        })
    }

    function loadSiswa(){
        var siswa  = $("#siswa").val();
        var rombel= $("#rombel").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/show_siswa',
            data:'siswa='+siswa+'&rombel='+rombel,
            success:function(html){
                $("#showSiswa").html(html);
                loadTagihan();
            }
        })
    }

    function loadBiaya(){
        var biaya  = $("#biaya").val();
        var kelas= $("#kelas").val();

        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/load_biaya',
            data:'biaya='+biaya+'&kelas='+kelas,
            success:function(html){
                $("#showBiaya").html(html);
                //loadSiswa();
                loadTagihan();
            }
        })
    }
    
    function loadTagihan(){
        var siswa   =$("#siswa").val();
        var rombel =$("#rombel").val();
        var kelas   =$("#kelas").val();
        var biaya  =$("#biaya").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/ShowTagihan', 
            data:'rombel='+rombel+'&kelas='+kelas+'&siswa='+siswa+'&biaya='+biaya+'&id_siswa=<?php echo $this->uri->segment(3) ?>',
            success:function(html){
                $("#tabel").html(html);
                //loadRombel();
            }
        })
    }
</script>


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <?php
            echo form_open('Pembayaran/AddTagihan');
            ?>
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Tambah Tagihan</h4>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                <tr><td width="30%">Kelas</td><td><?php echo cmb_dinamis('kelas', 'tbl_kelas', 'nama_kelas', 'id_kelas', null, "id='kelas' onChange='load_Rombel()'") ?></td></tr>
                <tr><td width="30%">Rombel</td><td><?php echo cmb_dinamis('rombel', 'tbl_rombel', 'nama_rombel', 'id_rombel', null, "id='rombel' onChange='load_Siswa()'") ?></td></tr>
                <tr><td width="30%">Nama Siswa</td><td><?php echo cmb_dinamis('siswa', 'tbl_siswa', 'nama', 'id_siswa', null, "id='siswa'") ?></td></tr>
                <tr><td width="30%">Jenis Biaya</td><td><?php echo cmb_dinamis('biaya', 'tbl_biaya', 'jenis_biaya', 'id_biaya', null, "id='biaya' onChange='load_Biaya()'") ?></div></td></tr>
                <tr><td width="30%">Tahun Pelajaran</td><td><?php echo cmb_dinamis('tapel', 'tbl_tahun_pelajaran', 'tahun_pelajaran', 'id_tahun_pelajaran', get_tahun_pelajaran_aktif('id_tahun_pelajaran'), null, "id='tapel'") ?></div></td></tr>
                <tr><td width="30%">Jumlah Bayar</td><td><input type="text" name="jumlah_bayar" value="0"></div></td></tr>  
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat" data-dismiss="modal">Tutup</button>
                <button type="submit" name="submit" class="btn btn-primary btn-flat">Tambah Data</button>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Ubah -->
<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="edit-data" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                <h4 class="modal-title">Proses Pembayaran</h4>
            </div>
            <form class="form-horizontal" action="<?php echo base_url('Pembayaran/Bayar')?>" method="post" enctype="multipart/form-data" role="form">
             <div class="modal-body">
                     <div class="form-group">
                         <label class="col-lg-3 col-sm-3 control-label">Nama Siswa</label>
                         <div class="col-lg-9">
                          <input type="hidden" readonly id="id_pembayaran" name="id_pembayaran">
                             <input type="text" class="form-control" id="id_siswa" name="id_siswa" placeholder="Nama Siswa">
                         </div>
                     </div>
                     <div class="form-group">
                         <label class="col-lg-3 col-sm-3 control-label">Jenis Biaya</label>
                         <div class="col-lg-9">
                          <input class="form-control" id="id_biaya" name="id_biaya" placeholder=""></input>
                         </div>
                     </div>
                     <div class="form-group">
                         <label class="col-lg-3 col-sm-3 control-label">Nominal</label>
                         <div class="col-lg-9">
                             <input type="text" class="form-control" id="harga" name="harga" placeholder="">
                         </div>
                     </div>
                     <div class="form-group">
                         <label class="col-lg-3 col-sm-3 control-label">Jumlah Bayar</label>
                         <div class="col-lg-9">
                             <input type="text" class="form-control" id="jumlah_bayar" name="jumlah_bayar" placeholder="Masukan Angka">
                         </div>
                     </div>
                 </div>
                 <div class="modal-footer">
                     <button class="btn btn-info btn-flat" type="submit"> Simpan&nbsp;</button>
                     <button type="button" class="btn btn-warning btn-flat" data-dismiss="modal"> Batal</button>
                 </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- END Modal Ubah -->
<!--script type="text/javascript">
    $(document ).ready(function() {
        $('#').on('show.bs.modal', function (event) {
        load_Rombel();
        load_Siswa();
    });
    });
</script>

<script>
    $(document).ready(function() {
        // Untuk sunting
        $('#edit-data').on('show.bs.modal', function (event) {
            var div = $(event.relatedTarget) // Tombol dimana modal di tampilkan
            var modal          = $(this)

            // Isi nilai pada field
            modal.find('#id_pembayaran').attr("value",div.data('id_pembayaran'));
            modal.find('#id_siswa').attr("value",div.data('id_siswa'));
            modal.find('#id_biaya').html(div.data('id_biaya'));
            modal.find('#jenis_biaya').html(div.data('jenis_biaya'));
            modal.find('#harga').attr("value",div.data('harga'));
            modal.find('#jumlah_bayar').attr("value",div.data('jumlah_bayar'));
        });
    });
</script-->

<script type="text/javascript">
    function load_Rombel(){
        var rombel  = $("#rombel").val();
        var kelas= $("#kelas").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/rombelload',
            data:'rombel='+rombel+'&kelas='+kelas,
            success:function(html){
                $("#tampilRombel").html(html);
                $("#modal-body").modal('tampilRombel');
                load_Siswa();
            }
        })
    }

    function load_Siswa(){
        var siswa  = $("#siswa").val();
        var rombel= $("#rombel").val();
        $.ajax({
            type:'GET',
            url :'<?php echo base_url() ?>Pembayaran/siswaload',
            data:'siswa='+siswa+'&rombel='+rombel,
            success:function(result){
                $("#tampilSiswa").html(result);
                //loadTagihan();
            }
        })
    }
</script>

<script type="text/javascript">
  jQuery(document).ready(function(){
  
  jQuery(document).on("click", ".deletePembayaran", function(){
    var id_pembayaran = $(this).data("id_pembayaran"),
      hitURL = baseURL + "deletePembayaran",
      currentRow = $(this);
    
    var confirmation = confirm("Are you sure to delete this data ?");
    
    if(confirmation)
    {
      jQuery.ajax({
      type : "POST",
      dataType : "json",
      url : hitURL,
      data : { id_pembayaran : id_pembayaran } 
      }).done(function(data){
        console.log(data);
        currentRow.parents('tr').remove();
        if(data.status = true) { alert("Data successfully deleted"); }
        else if(data.status = false) { alert("Data deletion failed"); }
        else { alert("Access denied..!"); }
      });
    }
  });
  
  
  jQuery(document).on("click", ".searchList", function(){
    
  });
  
});
</script>

