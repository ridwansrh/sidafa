<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <link rel="icon" href="<?php echo base_url(); ?>assets/dist/img/icon.ico">
    <title>SIMDAFA</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <link href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet" type="text/css" />
    <!-- DataTables -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Theme style -->
    <link href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="<?php echo base_url(); ?>assets/dist/css/skins/_all-skins.min.css" rel="stylesheet" type="text/css" />
    <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <style>
    .example-modal .modal {
      position: relative;
      top: auto;
      bottom: auto;
      right: auto;
      left: auto;
      display: block;
      z-index: 1;
    }

    .example-modal .modal {
      background: transparent !important;
    }
    
  </style>
    <style>
    	.error{
    		color:red;
    		font-weight: normal;
    	}
    </style>
    <!-- jQuery 2.1.4 -->
    <script src="<?php echo base_url(); ?>assets/js/jQuery-2.1.4.min.js"></script>
    <script type="text/javascript">
        var baseURL = "<?php echo base_url(); ?>";
    </script>
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <!-- <body class="sidebar-mini skin-black-light"> -->
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
      
      <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo base_url(); ?>" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>DAFA</b></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>SIMDAFA</b>(MTs)</span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="<?php echo base_url(); ?>assets/dist/img/avatar.png" class="user-image" alt="User Image"/>
                  <span class="hidden-xs"><?php echo $name; ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="<?php echo base_url(); ?>assets/dist/img/avatar.png" class="img-circle" alt="User Image" />
                    <p>
                      <?php echo $name; ?>
                      <small><?php echo $role_text; ?></small>
                    </p>
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="<?php echo base_url(); ?>loadChangePass" class="btn btn-default btn-flat"><i class="fa fa-key"></i> Ganti Pasword</a>
                    </div>
                    <div class="pull-right">
                      <a href="<?php echo base_url(); ?>logout" class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url();?>assets/dist/img/avatar.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>MTs Darul Falah Sirahan</p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                  <i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header">MAIN MENU</li>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>dashboard">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span></i>
              </a>
            </li>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>pembayaran">
                <i class="fa fa-paper-plane"></i> <span>Pembayaran</span></i>
              </a>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-th"></i> <span>Data Madrasah</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>profileListing"><i class="fa fa-circle-o"></i>Profile</a></li>
                <li><a href="index.php?view=identitas"><i class="fa fa-circle-o"></i>Sejarah</a></li>
                <li><a href="index.php?view=identitas"><i class="fa fa-circle-o"></i>Struktur</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-user"></i> <span>Data Pengguna</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="index.php?view=siswa"><i class="fa fa-circle-o"></i>Data Siswa</a></li>
                <li><a href="<?php echo base_url(); ?>list-hobi"><i class="fa fa-circle-o"></i>Hobi</a></li>
                <li><a href="<?php echo base_url(); ?>list-citacita"><i class="fa fa-circle-o"></i>Cita-Cita</a></li>
                <li><a href="index.php?view=siswa"><i class="fa fa-circle-o"></i>Jenis Tinggal</a></li>
                <li><a href="<?php echo base_url(); ?>list-pondok"><i class="fa fa-circle-o"></i>Daftar Pondok</a></li>
                <li><a href="index.php?view=siswa"><i class="fa fa-circle-o"></i>Jarak Rumah</a></li>
                <li><a href="<?php echo base_url(); ?>list-transportasi"><i class="fa fa-circle-o"></i>Transportasi</a></li>
                <li><a href="<?php echo base_url(); ?>list-pekerjaan"><i class="fa fa-circle-o"></i>Pekerjaan</a></li>
                <li><a href="<?php echo base_url(); ?>list-penghasilan"><i class="fa fa-circle-o"></i>Penghasilan Rata-Rata</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Pendidikan Terakhir</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Jenis PTK</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Jabatan</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Golongan</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Jalur Sertifikasi</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Status Kepegawean</a></li>
                <li><a href="index.php?view=guru"><i class="fa fa-circle-o"></i>Data PTK</a></li>
                <li><a href="index.php?view=guru"><i class="fa fa-circle-o"></i>Data Kepegawean</a></li>
                <li><a href="index.php?view=guru"><i class="fa fa-circle-o"></i>Penghargaan</a></li>
                <li><a href="index.php?view=guru"><i class="fa fa-circle-o"></i>Pelatihan</a></li>
                <li><a href="index.php?view=guru"><i class="fa fa-circle-o"></i>Role</a></li>
                <li><a href="index.php?view=guru"><i class="fa fa-circle-o"></i>Reset Pasword</a></li>
                <li><a href="<?php echo base_url(); ?>userListing"><i class="fa fa-circle-o"></i>User Managemen</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-th-list"></i> <span>Data Sarpras</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="#"><i class="fa fa-circle-o"></i>Gedung</a></li>
                <li><a href="index.php?view=guru"><i class="fa fa-circle-o"></i>Ruang</a></li>
                <li><a href="<?php echo base_url(); ?>KlsList"><i class="fa fa-circle-o"></i>Kelas</a></li>
                <li><a href="index.php?view=guru"><i class="fa fa-circle-o"></i>Data Inventaris</a></li>
              </ul>
            </li>

            <li class="treeview">
              <a href="#"><i class="fa fa-users"></i> <span>Data Akademik</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>TPList"><i class="fa fa-circle-o"></i>Tahun Pelajaran</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Kurikulum</a></li>
                <li><a href="<?php echo base_url(); ?>list-jurusan"><i class="fa fa-circle-o"></i>Jurusan</a></li>
                <li><a href="index.php?view=kelompokmapel"><i class="fa fa-circle-o"></i>Kelompok Mapel</a></li>
                <li><a href="index.php?view=matapelajaran"><i class="fa fa-circle-o"></i>Mata Pelajaran</a></li>
                <li><a href="index.php?view=jadwalpelajaran"><i class="fa fa-circle-o"></i>Jadwal Pelajaran</a></li>
                <li><a href="index.php?view=bahantugas"><i class="fa fa-circle-o"></i>Data Bahan dan Tugas</a></li>
                <li><a href="index.php?view=bahantugas"><i class="fa fa-circle-o"></i>Forum Diskusi</a></li>
                <li><a href="index.php?view=bahantugas"><i class="fa fa-circle-o"></i>Quis/Ujian Online</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-send"></i> <span>SMS Gateway</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="index.php?view=sms"><i class="fa fa-circle-o"></i> Send SMS</a></li>
                <li><a href="index.php?view=broadcast"><i class="fa fa-circle-o"></i> Broadcast SMS</a></li>
                <li><a href="index.php?view=autoreply"><i class="fa fa-circle-o"></i> Autoreply</a></li>
                <li><a href="index.php?view=smstoweb"><i class="fa fa-circle-o"></i> Inbox SMS2WEB</a></li>
              </ul>
            </li></li>
            <li class="treeview">
              <a href="#"><i class="fa fa-th-large"></i> <span>Data Absensi</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="index.php?view=absenhariansiswa"><i class="fa fa-circle-o"></i> Absensi Siswa</a></li>
                <li><a href="index.php?view=absenhariansiswa"><i class="fa fa-circle-o"></i> Rekap Absensi Siswa</a></li>
                <li><a href="index.php?view=absenharianguru"><i class="fa fa-circle-o"></i> Absensi Guru</a></li>
                <li><a href="index.php?view=rekapabsenharianguru"><i class="fa fa-circle-o"></i> Rekap Absensi Guru</a></li>
                <li><a href="index.php?view=rekapabsenharianguru"><i class="fa fa-circle-o"></i> Journal KBM</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-tags"></i> <span>Pembayaran</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>JenisBiaya"><i class="fa fa-circle-o"></i> Jenis Biaya</a></li>
                <li><a href="index.php?view=pembayaransiswa"><i class="fa fa-circle-o"></i> Pembayaran Siswa</a></li>
                <li><a href="index.php?view=laporankeuangan"><i class="fa fa-circle-o"></i> Laporan Harian</a></li>
                <li><a href="index.php?view=laporankeuangan"><i class="fa fa-circle-o"></i> Laporan Bulanan</a></li>
                <li><a href="index.php?view=rekapkeuangan"><i class="fa fa-circle-o"></i> Rekap</a></li>
              </ul>
            </li>
             <li class="treeview">
              <a href="#"><i class="fa fa-th-large"></i> <span>Hafalan dan KDU</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="index.php?view=jenishafalan"><i class="fa fa-circle-o"></i> Jenis Hafalan</a></li>
                <li><a href="index.php?view=setoranhafalan"><i class="fa fa-circle-o"></i> Setoran</a></li>
                <li><a href="index.php?view=laporanhafalan"><i class="fa fa-circle-o"></i> Laporan</a></li>
                <li><a href="index.php?view=prestasi"><i class="fa fa-circle-o"></i> Catatan Prestasi</a></li>
                <li><a href="index.php?view=terlambat"><i class="fa fa-circle-o"></i> Catatan Terlambat</a></li>
                <li><a href="index.php?view=izinkeluar"><i class="fa fa-circle-o"></i> Izin Meningalkan Madrasah</a></li>
                <li><a href="index.php?view=pelanggaran"><i class="fa fa-circle-o"></i> Catatan Pelanggaran</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-plane"></i> <span>PERPUSTAKAAN</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="index.php?view=anggotaperpus"><i class="fa fa-circle-o"></i> Data Anggota</a></li>
                <li class="treeview">
                <a href="#"><i class="fa fa-th-large"></i> <span>MASTER BUKU</span><i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                <li><a href="index.php?view=databuku"><i class="fa fa-circle-o"></i> Data Buku</a></li>
                <li><a href="index.php?view=jenisbuku"><i class="fa fa-circle-o"></i> Jenis buku</a></li>
                <li><a href="index.php?view=rakbuku"><i class="fa fa-circle-o"></i> Data Rak buku</a></li>
                <li><a href="index.php?view=kategoribuku"><i class="fa fa-circle-o"></i> Klasifikasi</a></li>                
                <li><a href="index.php?view=pengarang"><i class="fa fa-circle-o"></i> Data Pengarang</a></li>
                <li><a href="index.php?view=penerbit"><i class="fa fa-circle-o"></i> Data Penerbit</a></li>
                <li><a href="index.php?view=provinsi"><i class="fa fa-circle-o"></i> Data Provinsi</a></li>
                <li><a href="index.php?view=sumberbuku"><i class="fa fa-circle-o"></i> Sumber Buku</a></li>
                <li><a href="index.php?view=tahunterbit"><i class="fa fa-circle-o"></i> Data Tahun</a></li>
                </ul>
                <a href="#"><i class="fa fa-th-large"></i> <span>TRANSAKSI</span><i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                <li><a href="index.php?view=transaksi"><i class="fa fa-circle-o"></i> Data Peminjaman</a></li>
                </ul>
                <a href="#"><i class="fa fa-th-large"></i> <span>LAPORAN</span><i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                <li><a href="index.php?view=rekapbuku"><i class="fa fa-circle-o"></i> Rekap Buku</a></li>
                <li><a href="index.php?view=rekappengembalian"><i class="fa fa-circle-o"></i> Rekap Pengembalian</a></li>
                </ul>                
                <li><a href="index.php?view=denda"><i class="fa fa-circle-o"></i> Denda</a></li>
                <li><a href="index.php?view=petugas"><i class="fa fa-circle-o"></i> Petugas</a></li>
              </ul>
            </li>
            <li class="treeview">
              <li><a href="#"><i class="fa fa-book"></i> <span>Administrasi </span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="index.php?view=suratkeluar"><i class="fa fa-circle-o"></i> Surat Keluar</a></li>
                <li><a href="index.php?view=suratkeluar"><i class="fa fa-circle-o"></i> Surat Masuk</a></li>
                <li><a href="index.php?view=sk"><i class="fa fa-circle-o"></i> Surat Keputusan</a></li>
                <li><a href="index.php?view=sk"><i class="fa fa-circle-o"></i> Keterangan Mengaji</a></li>
                <li><a href="index.php?view=sk"><i class="fa fa-circle-o"></i> Kartu Hafalan</a></li>
                <li><a href="index.php?view=sk"><i class="fa fa-circle-o"></i> Blangko Absen Kecil</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-list"></i> <span>Penerimaan Siswa Baru</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>list-siswa-psb"><i class="fa fa-circle-o"></i>Data Siswa Baru</a></li>
                <li><a href="<?php echo base_url(); ?>add-new-siswa-psb"><i class="fa fa-circle-o"></i>Input Data</a></li>
                <li class="treeview">
                <a href="#"><i class="fa fa-th-large"></i> <span>Administrasi</span><i class="fa fa-angle-left pull-right"></i></a>
                <ul class="treeview-menu">
                <li><a href="<?php echo base_url(); ?>list-biaya-psb"><i class="fa fa-circle-o"></i>Jenis Biaya</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Pembayaran</a></li>
                <li><a href="#"><i class="fa fa-circle-o"></i>Laporan Harian</a></li>
                </ul>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-calendar"></i> <span>Raport Digital</span><i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="index.php?view=importsemuanilai"><i class="fa fa-circle-o"></i>Nilai Harian</a></li>
                <li><a href="index.php?view=inputnilaisikap"><i class="fa fa-circle-o"></i>Input Nilai Sikap</a></li>
                <li><a href="index.php?view=nilairaport"><i class="fa fa-circle-o"></i>Nilai Semester</a></li>
                <li><a href="index.php?view=tanggalraport"><i class="fa fa-circle-o"></i>Penanggalan Raport </a></li>
                <li><a href="index.php?view=impunnilaiharian"><i class="fa fa-circle-o"></i>Cetak Raport</a></li>
                <li><a href="index.php?view=daftarpenerimaanraport"><i class="fa fa-circle-o"></i>Daftar Penerimaan Raport</a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#" >
                <i class="fa fa-ticket"></i>
                <span>DATA PENGGUNA</span>
              </a>
            </li>
            <?php
            if($role == ROLE_ADMIN || $role == ROLE_MANAGER)
            {
            ?>
            <li class="treeview">
              <a href="#" >
                <i class="fa fa-thumb-tack"></i>
                <span>Task Status</span>
              </a>
            </li>
            <li class="treeview">
              <a href="#" >
                <i class="fa fa-upload"></i>
                <span>Task Uploads</span>
              </a>
            </li>
            <?php
            }
            if($role == ROLE_ADMIN)
            {
            ?>
            <li class="treeview">
              <a href="<?php echo base_url(); ?>userListing">
                <i class="fa fa-users"></i>
                <span>Users</span>
              </a>
            </li>
            <li class="treeview">
              <a href="#" >
                <i class="fa fa-files-o"></i>
                <span>LAPORAN</span>
              </a>
            </li>
            <?php
            }
            ?>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>