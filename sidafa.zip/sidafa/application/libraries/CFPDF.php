<?php
/**
 * 
 */
require('fpdf.php');
class CFPDF extends fpdf
{
	
	function __construct()
	{
		require_once APPPATH.'libraries/fpdf.php';
	}

    
    
}