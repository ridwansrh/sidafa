<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : PsbBiaya (PsbBiayaController)
 * Prodile Class to control all PsbBiaya related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class PsbBiaya extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('psbbiaya_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the PsbBiaya
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : PSB Jenis Biaya';
        
        $this->loadViews("PsbBiaya/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the PsbBiaya list
     */
    function PsbBiayaList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('psbbiaya_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->psbbiaya_model->PsbBiayaListCount($searchText);

			$returns = $this->paginationCompress ( "list-biaya-psb/", $count, 10 );
            
            $data['PsbBiayaRecords'] = $this->psbbiaya_model->PsbBiayaList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : PSB Jenis Biaya';
            
            $this->loadViews("PsbBiaya/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('psbbiaya_model');
            $data['status'] = $this->psbbiaya_model->getKeaktifan();
            $data['kelas'] = $this->psbbiaya_model->getKelas();
            $data['tapel'] = $this->psbbiaya_model->getTapel();
            $data['roles'] = $this->psbbiaya_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("PsbBiaya/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new PsbBiaya
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('jenis_biaya','Jenis Biaya','trim|required|max_length[20]|xss_clean');
            $this->form_validation->set_rules('harga','Nominal','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('tapel','Tahun Pelajaran','trim|required|numeric');
            $this->form_validation->set_rules('kelas','Kelas','trim|required|numeric');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $jenis_biaya        = $this->input->post('jenis_biaya');
                $harga              = $this->input->post('harga');
                $id_tahun_pelajaran = $this->input->post('tapel');
                $harga              = $this->input->post('harga');
                $id_kelas              = $this->input->post('kelas');
                $id_aktif           = $this->input->post('status');
                
                $psbbiayaInfo = array('jenis_biaya'         =>$jenis_biaya, 
                                      'harga'               =>$harga, 
                                      'id_tahun_pelajaran'  =>$id_tahun_pelajaran,
                                      'id_kelas'            =>$id_kelas, 
                                      'id_aktif'            =>$id_aktif);
                
                $this->load->model('psbbiaya_model');
                $result = $this->psbbiaya_model->AddNew($psbbiayaInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-biaya-psb');
            }
        }
    }

    /**
     * This function is used load PsbBiaya edit information
     * @param number $id_biaya_psb : Optional : This is PsbBiaya id
     */
    function Edit($id_biaya_psb = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {     
            $data['psbbiayaInfo'] = $this->psbbiaya_model->GetPsbBiayaInfo($id_biaya_psb);
            $data['tapel'] = $this->psbbiaya_model->getTapel();
            $data['kelas'] = $this->psbbiaya_model->getKelas();
            $data['status'] = $this->psbbiaya_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("PsbBiaya/Edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the PsbBiaya information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_biaya_psb = $this->input->post('id_biaya_psb');
            
            $this->form_validation->set_rules('jenis_biaya','Jenis Biaya','trim|required|max_length[20]|xss_clean');
            $this->form_validation->set_rules('harga','Nominal','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('tapel','Tahun Pelajaran','trim|required|numeric');
            $this->form_validation->set_rules('kelas','Kelas','trim|required|numeric');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_biaya_psb);
            }
            else
            {
                $jenis_biaya        = $this->input->post('jenis_biaya');
                $harga              = $this->input->post('harga');
                $id_tahun_pelajaran = $this->input->post('tapel');
                $harga              = $this->input->post('harga');
                $id_kelas           = $this->input->post('kelas');
                $id_aktif           = $this->input->post('status');
                
                $psbbiayaInfo = array('jenis_biaya'         =>$jenis_biaya, 
                                      'harga'               =>$harga, 
                                      'id_tahun_pelajaran'  =>$id_tahun_pelajaran,
                                      'id_kelas'            =>$id_kelas, 
                                      'id_aktif'            =>$id_aktif);

                $result = $this->psbbiaya_model->EditPsbBiaya($psbbiayaInfo, $id_biaya_psb);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-biaya-psb');
            }
        }
    }


    /**
     * This function is used to delete the PsbBiaya using id_biaya_psb
     * @return boolean $result : TRUE / FALSE
     */
    function deletePsbBiaya()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_biaya_psb = $this->input->post('id_biaya_psb');
            $psbbiayaInfo = array('isDeleted'=>1);
            
            $result = $this->psbbiaya_model->deletePsbBiaya($id_biaya_psb, $psbbiayaInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}