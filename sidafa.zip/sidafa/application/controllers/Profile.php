<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Profile (ProfileController)
 * Prodile Class to control all profile related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Profile extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('profile_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the profile
     */
    public function index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Profile';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the profile list
     */
    function profileListing()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('profile_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->profile_model->profileListingCount($searchText);

			$returns = $this->paginationCompress ( "profileListing/", $count, 5 );
            
            $data['profileRecords'] = $this->profile_model->profileListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : profile Listing';
            
            $this->loadViews("profile/profile", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function addNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('profile_model');
            $data['roles'] = $this->profile_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Profile';

            $this->loadViews("profile/addNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new profile
     */
    function addNewProfile()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('nsm','NSM','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('npsn','NPSN','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('namamadrasah','Nama Madrasah','trim|required|max_length[30]');
            $this->form_validation->set_rules('alamat','Alamat','trim|required|max_length[50]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNew();
            }
            else
            {
                $nsm = $this->input->post('nsm');
                $npsn = $this->input->post('npsn');
                $namamadrasah = $this->input->post('namamadrasah');
                $alamat = $this->input->post('alamat');
                
                $profileInfo = array('nsm'=>$nsm, 'npsn'=>$npsn, 'namamadrasah'=>$namamadrasah, 'alamat'=> $alamat);
                
                $this->load->model('profile_model');
                $result = $this->profile_model->addNewProfile($profileInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Profile created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Profile creation failed');
                }
                
                redirect('profileListing');
            }
        }
    }

    /**
     * This function is used load profile edit information
     * @param number $userId : Optional : This is user id
     */
    function edit($profileID = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            //$data['roles'] = $this->user_model->getUserRoles();
            $data['profileInfo'] = $this->profile_model->getprofileInfo($profileID);
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Profile';
            
            $this->loadViews("Profile/edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the profile information
     */
    function editProfile()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$profileID = $this->input->post('profileID');
            
            $this->form_validation->set_rules('nsm','NSM','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('npsn','NPSN','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('namamadrasah','Nama Madrasah','trim|required|max_length[30]');
            $this->form_validation->set_rules('alamat','Alamat','trim|required|max_length[50]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($profileID);
            }
            else
            {
                $nsm = $this->input->post('nsm');
                $npsn = $this->input->post('npsn');
                $namamadrasah = $this->input->post('namamadrasah');
                $alamat = $this->input->post('alamat');
                
                $profileInfo = array( 'nsm'=>$nsm, 'npsn'=> $npsn, 'namamadrasah'=> $namamadrasah, 'alamat'=> $alamat );

                $result = $this->profile_model->editProfile($profileInfo, $profileID);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Profile updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Profile updation failed');
                }
                
                redirect('profileListing');
            }
        }
    }


    /**
     * This function is used to delete the profile using profileID
     * @return boolean $result : TRUE / FALSE
     */
    function deleteProfile()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $profileID = $this->input->post('profileID');
            $profileInfo = array('isDeleted'=>1);
            
            $result = $this->profile_model->deleteProfile($profileID, $profileInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}