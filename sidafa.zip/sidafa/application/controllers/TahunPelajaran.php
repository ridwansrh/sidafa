<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Profile (ProfileController)
 * Prodile Class to control all profile related operations.
 * @author : abdulmu
 * @version : 1.1
 * @since : 29 Maret 2020
 */
class TahunPelajaran extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('tahunpelajaran_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the Tahun Pelajaran
     */
    public function index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Tahun Pelajaran';
        
        $this->loadViews("dashboard", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the Tahun Pelajaran list
     */
    function TPList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('tahunpelajaran_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->tahunpelajaran_model->TPListCount($searchText);

			$returns = $this->paginationCompress ( "TPList/", $count, 10 );
            
            $data['tpRecords'] = $this->tahunpelajaran_model->TPList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : Tahun Pelajaran';
            
            $this->loadViews("TahunPelajaran/index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function addData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('tahunpelajaran_model');
            $data['status'] = $this->tahunpelajaran_model->getKeaktifan();
            $data['roles'] = $this->tahunpelajaran_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add Data';

            $this->loadViews("tahunpelajaran/addNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new data
     */
    function addNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('tahun_pelajaran','Tahun Pelajaran','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('ket_tahun_pelajaran','Keterangan Tahun Pelajaran','trim|required|max_length[50]xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addData();
            }
            else
            {
                $tahun_pelajaran = $this->input->post('tahun_pelajaran');
                $ket_tahun_pelajaran = $this->input->post('ket_tahun_pelajaran');
                
                $tpInfo = array('tahun_pelajaran'=>$tahun_pelajaran, 'ket_tahun_pelajaran'=>$ket_tahun_pelajaran );
                
                $this->load->model('tahunpelajaran_model');
                $result = $this->tahunpelajaran_model->addData($tpInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('TPList');
            }
        }
    }

    /**
     * This function is used load Tahun Pelajaran edit information
     * @param number $id_tahun_pelajaran : Optional : This is Tahun Pelajaran ID
     */
    function edit($id_tahun_pelajaran = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            //$data['roles'] = $this->user_model->getUserRoles();
            $data['tpInfo'] = $this->tahunpelajaran_model->gettpInfo($id_tahun_pelajaran);
            $data['status'] = $this->tahunpelajaran_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("TahunPelajaran/edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the profile information
     */
    function editData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_tahun_pelajaran = $this->input->post('id_tahun_pelajaran');
            
            $this->form_validation->set_rules('tahun_pelajaran','Tahun Pelajaran','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('ket_tahun_pelajaran','Keterangan Tahun Pelajaran','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|max_length[30]');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_tahun_pelajaran);
            }
            else
            {
                $tahun_pelajaran = $this->input->post('tahun_pelajaran');
                $ket_tahun_pelajaran = $this->input->post('ket_tahun_pelajaran');
                $id_aktif = $this->input->post('status');
                
                $tpInfo = array('tahun_pelajaran'=>$tahun_pelajaran, 'ket_tahun_pelajaran'=>$ket_tahun_pelajaran, 'id_aktif'=>$id_aktif);
                
                $result = $this->tahunpelajaran_model->editData($tpInfo, $id_tahun_pelajaran);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('TPList');
            }
        }
    }


    /**
     * This function is used to delete the Tahun Pelajaran using ID
     * @return boolean $result : TRUE / FALSE
     */
    function deleteTP()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_tahun_pelajaran = $this->input->post('id_tahun_pelajaran');
            $tpInfo = array('isDeleted'=>1);
            
            $result = $this->tahunpelajaran_model->deleteTP($id_tahun_pelajaran, $tpInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}