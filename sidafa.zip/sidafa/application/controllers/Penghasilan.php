<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Penghasilan (PenghasilanController)
 * Prodile Class to control all Penghasilan related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class Penghasilan extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('penghasilan_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the Penghasilan
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Penghasilan';
        
        $this->loadViews("Penghasilan/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the Penghasilan list
     */
    function PenghasilanList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('penghasilan_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->penghasilan_model->PenghasilanListCount($searchText);

			$returns = $this->paginationCompress ( "list-penghasilan/", $count, 10 );
            
            $data['penghasilanRecords'] = $this->penghasilan_model->PenghasilanList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : Penghasilan';
            
            $this->loadViews("Penghasilan/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('penghasilan_model');
            $data['status'] = $this->penghasilan_model->getKeaktifan();
            $data['roles'] = $this->penghasilan_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("Penghasilan/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new Penghasilan
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('penghasilan','Penghasilan','trim|required|max_length[30]|xss_clean');
            $this->form_validation->set_rules('ket_penghasilan','Keterangan','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $penghasilan = $this->input->post('penghasilan');
                $ket_penghasilan = $this->input->post('ket_penghasilan');
                $id_aktif = $this->input->post('status');
                
                $penghasilanInfo = array('penghasilan'=>$penghasilan, 'ket_penghasilan'=>$ket_penghasilan, 'id_aktif'=>$id_aktif);
                
                $this->load->model('penghasilan_model');
                $result = $this->penghasilan_model->AddNew($penghasilanInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-penghasilan');
            }
        }
    }

    /**
     * This function is used load Penghasilan edit information
     * @param number $id_penghasilan : Optional : This is Penghasilan id
     */
    function Edit($id_penghasilan = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            $data['penghasilanInfo'] = $this->penghasilan_model->GetPenghasilanInfo($id_penghasilan);
            $data['status'] = $this->penghasilan_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("Penghasilan/Edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the Penghasilan information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_penghasilan = $this->input->post('id_penghasilan');
            
            $this->form_validation->set_rules('penghasilan','Penghasilan','trim|required|max_length[30]|xss_clean');
            $this->form_validation->set_rules('ket_penghasilan','Keterangan','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_penghasilan);
            }
            else
            {
                $penghasilan = $this->input->post('penghasilan');
                $ket_penghasilan = $this->input->post('ket_penghasilan');
                $id_aktif = $this->input->post('status');
                
                $penghasilanInfo = array( 'penghasilan'=>$penghasilan, 'ket_penghasilan'=> $ket_penghasilan, 'id_aktif'=> $id_aktif);

                $result = $this->penghasilan_model->EditPenghasilan($penghasilanInfo, $id_penghasilan);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-penghasilan');
            }
        }
    }


    /**
     * This function is used to delete the Penghasilan using id_penghasilan
     * @return boolean $result : TRUE / FALSE
     */
    function deletePenghasilan()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_penghasilan = $this->input->post('id_penghasilan');
            $penghasilanInfo = array('isDeleted'=>1);
            
            $result = $this->penghasilan_model->deletePenghasilan($id_penghasilan, $penghasilanInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}