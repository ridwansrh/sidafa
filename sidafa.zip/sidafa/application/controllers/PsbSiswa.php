<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : PsbSiswa (PsbSiswaController)
 * Prodile Class to control all PsbSiswa related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class PsbSiswa extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('psbsiswa_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the PsbSiswa
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : PsbSiswa';
        
        $this->loadViews("PsbSiswa/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the PsbSiswa list
     */
    function PsbSiswaList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('psbsiswa_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->psbsiswa_model->PsbSiswaListCount($searchText);

			$returns = $this->paginationCompress ( "list-siswa-psb/", $count, 10 );
            
            $data['psbsiswaRecords'] = $this->psbsiswa_model->PsbSiswaList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : PsbSiswa';
            
            $this->loadViews("PsbSiswa/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('psbsiswa_model');
            $data['status'] = $this->psbsiswa_model->getKeaktifan();
            $data['roles'] = $this->psbsiswa_model->getUserRoles();
            $data['gender'] = $this->psbsiswa_model->getGender();
            //$data['agama'] = $this->psbsiswa_model->getAgama();
            $data['jalur_masuk'] = $this->psbsiswa_model->getJalurMasuk();
            $data['jurusan'] = $this->psbsiswa_model->getJurusan();
            $data['pondok'] = $this->psbsiswa_model->getPondok();
            $data['jenis_tinggal'] = $this->psbsiswa_model->getJenisTinggal();
            $data['jarak_tinggal'] = $this->psbsiswa_model->getJarakTinggal();
            $data['transportasi'] = $this->psbsiswa_model->getTransportasi();
            $data['hobi'] = $this->psbsiswa_model->getHobi();
            $data['citacita'] = $this->psbsiswa_model->getCitaCita();
            $data['sekolah_asal'] = $this->psbsiswa_model->getSekolahAsal();
            $data['pendidikan_ayah'] = $this->psbsiswa_model->getPendidikanTerakhir();
            $data['pekerjaan_ayah'] = $this->psbsiswa_model->getPekerjaan();
            $data['penghasilan_ayah'] = $this->psbsiswa_model->getPenghasilan();
            $data['pendidikan_ibu'] = $this->psbsiswa_model->getPendidikanTerakhir();
            $data['pekerjaan_ibu'] = $this->psbsiswa_model->getPekerjaan();
            $data['penghasilan_ibu'] = $this->psbsiswa_model->getPenghasilan();
            $data['pendidikan_wali'] = $this->psbsiswa_model->getPendidikanTerakhir();
            $data['pekerjaan_wali'] = $this->psbsiswa_model->getPekerjaan();
            $data['penghasilan_wali'] = $this->psbsiswa_model->getPenghasilan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("PsbSiswa/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new PsbSiswa
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('nisn','NISN','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('nik','NIK','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('nama','Nama','trim|required|max_length[100]xss_clean');
            $this->form_validation->set_rules('password','Password','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('tmp_lahir','Tempat Lahir','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('tgl_lahir','tgl_lahir','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('gender','gender','trim|required|numeric');
            $this->form_validation->set_rules('tahun_masuk','tahun_masuk','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('agama','agama','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('anak_ke','anak_ke','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('jml_sdr','jml_sdr','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('jalur_masuk','jalur_masuk','trim|required|numeric');
            $this->form_validation->set_rules('jurusan','jurusan','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('pondok','pondok','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('jenis_tinggal','jenis_tinggal','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('desa','desa','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('dukuh','dukuh','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('rt','rt','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('rw','rw','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('kecamatan','kecamatan','trim|required|max_length[30]xss_clean');
            $this->form_validation->set_rules('kabupaten','kabupaten','trim|required|max_length[30]xss_clean');
            $this->form_validation->set_rules('provinsi','provinsi','trim|required|max_length[30]xss_clean');
            $this->form_validation->set_rules('kode_pos','kode_pos','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('jarak_tinggal','jarak_tinggal','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('transportasi','transportasi','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('hobi','hobi','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('citacita','citacita','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('hp_siswa','hp_siswa','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('foto','foto','trim|max_length[225]xss_clean');
            $this->form_validation->set_rules('no_kip','no_kip','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_kis','no_kis','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_kartu_lain','no_kartu_lain','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('sekolah_asal','sekolah_asal','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('nama_sekolah_asal','nama_sekolah_asal','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('alamat_sekolah_asal','alamat_sekolah_asal','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('no_peserta_ujian','no_peserta_ujian','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_ijazah','no_ijazah','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_shun','no_shun','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('nilai_un','nilai_un','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_shuambn','no_shuambn','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('nilai_uambn','nilai_uambn','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('p_smt_empat_gasal','p_smt_empat_gasal','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_empat_genap','p_smt_empat_genap','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_lima_gasal','p_smt_lima_gasal','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_lima_genap','p_smt_lima_genap','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_enam_gasal','p_smt_enam_gasal','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_enam_genap','p_smt_enam_genap','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('prestasi_satu','prestasi_satu','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_dua','prestasi_dua','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_tiga','prestasi_tiga','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_empat','prestasi_empat','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_lima','prestasi_lima','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_enam','prestasi_enam','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('nama_ayah_kandung','nama_ayah_kandung','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nama_ayah_tiri','nama_ayah_tiri','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nik_ayah','nik_ayah','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('thn_lahir_ayah','thn_lahir_ayah','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('pendidikan_ayah','pendidikan_ayah','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('pekerjaan_ayah','pekerjaan_ayah','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('penghasilan_ayah','penghasilan_ayah','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('alamat_ayah','alamat_ayah','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('hp_ayah','hp_ayah','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('nama_ibu_kandung','nama_ibu_kandung','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nama_ibu_tiri','nama_ibu_tiri','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nik_ibu','nik_ibu','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('thn_lahir_ibu','thn_lahir_ibu','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('pendidikan_ibu','pendidikan_ibu','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('pekerjaan_ibu','pekerjaan_ibu','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('penghasilan_ibu','penghasilan_ibu','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('alamat_ibu','alamat_ibu','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('hp_ibu','hp_ibu','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('nama_wali_kandung','nama_wali_kandung','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nik_wali','nik_wali','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('thn_lahir_wali','thn_lahir_wali','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('pendidikan_wali','pendidikan_wali','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('pekerjaan_wali','pekerjaan_wali','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('penghasilan_wali','penghasilan_wali','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('alamat_wali','alamat_wali','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('hp_wali','hp_wali','trim|max_length[20]xss_clean');

            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $nisn = $this->input->post('nisn');
                $nik = $this->input->post('nik');
                $nama = strtoupper($this->input->post('nama'));
                $password = $this->input->post('password');
                $tmp_lahir = $this->input->post('tmp_lahir');
                $tgl_lahir = $this->input->post('tgl_lahir');
                $id_gender = $this->input->post('gender');
                $tahun_masuk = $this->input->post('tahun_masuk');
                $id_agama = $this->input->post('agama');
                $anak_ke = $this->input->post('anak_ke');
                $jml_sdr = $this->input->post('jml_sdr');
                $id_jalur_masuk = $this->input->post('jalur_masuk');
                $id_jurusan = $this->input->post('jurusan');
                $id_pondok = $this->input->post('pondok');
                $id_jenis_tinggal = $this->input->post('jenis_tinggal');
                $desa = strtoupper($this->input->post('desa'));
                $dukuh = strtoupper($this->input->post('dukuh'));
                $rt = $this->input->post('rt');
                $rw = $this->input->post('rw');
                $kecamatan = strtoupper($this->input->post('kecamatan'));
                $kabupaten = strtoupper($this->input->post('kabupaten'));
                $provinsi = strtoupper($this->input->post('provinsi'));
                $kode_pos = $this->input->post('kode_pos');
                $id_jarak = $this->input->post('jarak_tinggal');
                $id_transportasi = $this->input->post('transportasi');
                $id_hobi = $this->input->post('hobi');
                $id_cita_cita = $this->input->post('citacita');
                $hp_siswa = $this->input->post('hp_siswa');
                $foto = $this->input->post('foto');
                $no_kip = $this->input->post('no_kip');
                $no_kis = $this->input->post('no_kis');
                $no_kartu_lain = $this->input->post('no_kartu_lain');
                $id_sekolah_asal = $this->input->post('sekolah_asal');
                $nama_sekolah_asal = strtoupper($this->input->post('nama_sekolah_asal'));
                $alamat_sekolah_asal = $this->input->post('alamat_sekolah_asal');
                $no_peserta_ujian = $this->input->post('no_peserta_ujian');
                $no_ijazah = $this->input->post('no_ijazah');
                $no_shun = $this->input->post('no_shun');
                $nilai_un = $this->input->post('nilai_un');
                $no_shuambn = $this->input->post('no_shuambn');
                $nilai_uambn = $this->input->post('nilai_uambn');
                $p_smt_empat_gasal = $this->input->post('p_smt_empat_gasal');
                $p_smt_empat_genap = $this->input->post('p_smt_empat_genap');
                $p_smt_lima_gasal = $this->input->post('p_smt_lima_gasal');
                $p_smt_lima_genap = $this->input->post('p_smt_lima_genap');
                $p_smt_enam_gasal = $this->input->post('p_smt_enam_gasal');
                $p_smt_enam_genap = $this->input->post('p_smt_enam_genap');
                $prestasi_satu = $this->input->post('prestasi_satu');
                $prestasi_dua = $this->input->post('prestasi_dua');
                $prestasi_tiga = $this->input->post('prestasi_tiga');
                $prestasi_empat = $this->input->post('prestasi_empat');
                $prestasi_lima = $this->input->post('prestasi_lima');
                $prestasi_enam = $this->input->post('prestasi_enam');
                $nama_ayah_kandung = strtoupper($this->input->post('nama_ayah_kandung'));
                $nama_ayah_tiri = strtoupper($this->input->post('nama_ayah_tiri'));
                $nik_ayah = $this->input->post('nik_ayah');
                $thn_lahir_ayah = $this->input->post('thn_lahir_ayah');
                $id_pendidikan_ayah = $this->input->post('pendidikan_ayah');
                $id_pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
                $id_penghasilan_ayah = $this->input->post('penghasilan_ayah');
                $alamat_ayah = $this->input->post('alamat_ayah');
                $hp_ayah = $this->input->post('hp_ayah');
                $nama_ibu_kandung = strtoupper($this->input->post('nama_ibu_kandung'));
                $nama_ibu_tiri = strtoupper($this->input->post('nama_ibu_tiri'));
                $nik_ibu = $this->input->post('nik_ibu');
                $thn_lahir_ibu = $this->input->post('thn_lahir_ibu');
                $id_pendidikan_ibu = $this->input->post('pendidikan_ibu');
                $id_pekerjaan_ibu = $this->input->post('pekerjaan_ibu');
                $id_penghasilan_ibu = $this->input->post('penghasilan_ibu');
                $alamat_ibu = strtoupper($this->input->post('alamat_ibu'));
                $hp_ibu = $this->input->post('hp_ibu');
                $nama_wali = strtoupper($this->input->post('nama_wali'));
                $nik_wali = $this->input->post('nik_wali');
                $thn_lahir_wali = $this->input->post('thn_lahir_wali');
                $id_pendidikan_wali = $this->input->post('pendidikan_wali');
                $id_pekerjaan_wali = $this->input->post('pekerjaan_wali');
                $id_penghasilan_wali = $this->input->post('penghasilan_wali');
                $alamat_wali = strtoupper($this->input->post('alamat_wali'));
                $hp_wali = $this->input->post('hp_wali');
                //$id_aktif = $this->input->post();

                
                $psbsiswaInfo = array(
                    'nisn'=>$nisn, 
                    'nik'=>$nik, 
                    'nama'=>$nama, 
                    'password'=>getHashedPassword($password), 
                    'tmp_lahir'=>$tmp_lahir, 
                    'tgl_lahir'=>$tgl_lahir, 
                    'id_gender'=>$id_gender,
                    'tahun_masuk'=>$tahun_masuk, 
                    'id_agama'=>$id_agama,
                    'anak_ke'=>$anak_ke,
                    'jml_sdr'=>$jml_sdr,
                    'id_jalur_masuk'=>$id_jalur_masuk,
                    'id_jurusan'=>$id_jurusan,
                    'id_pondok'=>$id_pondok,
                    'id_jenis_tinggal'=>$id_jenis_tinggal,
                    'desa'=>$desa,
                    'dukuh'=>$dukuh,
                    'rt'=>$rt,
                    'rw'=>$rw,
                    'kecamatan'=>$kecamatan,
                    'kabupaten'=>$kabupaten,
                    'provinsi'=>$provinsi,
                    'kode_pos'=>$kode_pos,
                    'id_jarak'=>$id_jarak,
                    'id_transportasi'=>$id_transportasi,
                    'id_hobi'=>$id_hobi,
                    'id_cita_cita'=>$id_cita_cita,
                    'hp_siswa'=>$hp_siswa,
                    'foto'=>$foto,
                    'no_kip'=>$no_kip,
                    'no_kis'=>$no_kis,
                    'no_kartu_lain'=>$no_kartu_lain,
                    'id_sekolah_asal'=>$id_sekolah_asal,
                    'nama_sekolah_asal'=>$nama_sekolah_asal,
                    'alamat_sekolah_asal'=>$alamat_sekolah_asal,
                    'no_peserta_ujian'=>$no_peserta_ujian,
                    'no_ijazah'=>$no_ijazah,
                    'no_shun'=>$no_shun,
                    'nilai_un'=>$nilai_un,
                    'no_shuambn'=>$no_shuambn,
                    'nilai_uambn'=>$nilai_uambn,
                    'p_smt_empat_gasal'=>$p_smt_empat_gasal,
                    'p_smt_empat_genap'=>$p_smt_empat_genap,
                    'p_smt_lima_gasal'=>$p_smt_lima_gasal,
                    'p_smt_lima_genap'=>$p_smt_lima_genap,
                    'p_smt_enam_gasal'=>$p_smt_enam_gasal,
                    'p_smt_enam_genap'=>$p_smt_enam_genap,
                    'prestasi_satu'=>$prestasi_satu,
                    'prestasi_dua'=>$prestasi_dua,
                    'prestasi_tiga'=>$prestasi_tiga,
                    'prestasi_empat'=>$prestasi_empat,
                    'prestasi_lima'=>$prestasi_lima,
                    'prestasi_enam'=>$prestasi_enam,
                    'nama_ayah_kandung'=>$nama_ayah_kandung,
                    'nama_ayah_tiri'=>$nama_ayah_tiri,
                    'nik_ayah'=>$nik_ayah,
                    'thn_lahir_ayah'=>$thn_lahir_ayah,
                    'id_pendidikan_ayah'=>$id_pendidikan_ayah,
                    'id_pekerjaan_ayah'=>$id_pekerjaan_ayah,
                    'id_penghasilan_ayah'=>$id_penghasilan_ayah,
                    'alamat_ayah'=>$alamat_ayah,
                    'hp_ayah'=>$hp_ayah,
                    'nama_ibu_kandung'=>$nama_ibu_kandung,
                    'nama_ibu_tiri'=>$nama_ibu_tiri,
                    'nik_ibu'=>$nik_ibu,
                    'thn_lahir_ibu'=>$thn_lahir_ibu,
                    'id_pendidikan_ibu'=>$id_pendidikan_ibu,
                    'id_pekerjaan_ibu'=>$id_pekerjaan_ibu,
                    'id_penghasilan_ibu'=>$id_penghasilan_ibu,
                    'alamat_ibu'=>$alamat_ibu,
                    'hp_ibu'=>$hp_ibu,
                    'nama_wali'=>$nama_wali,
                    'nik_wali'=>$nik_wali,
                    'thn_lahir_wali'=>$thn_lahir_wali,
                    'id_pendidikan_wali'=>$id_pendidikan_wali,
                    'id_pekerjaan_wali'=>$id_pekerjaan_wali,
                    'id_penghasilan_wali'=>$id_penghasilan_wali,
                    'alamat_wali'=>$alamat_wali,
                    'hp_wali'=>$hp_wali,
                    'CreatedBy'=>$this->vendorId,
                    'CreatedDate'=>date('Y-m-d H:i:s'));
                
                $this->load->model('psbsiswa_model');
                $result = $this->psbsiswa_model->AddNew($psbsiswaInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-siswa-psb');
            }
        }
    }

    /**
     * This function is used load PsbSiswa edit information
     * @param number $id_pendaftaran : Optional : This is PsbSiswa id
     */
    function Edit($id_pendaftaran = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            $data['psbsiswaInfo'] = $this->psbsiswa_model->GetPsbSiswaInfo($id_pendaftaran);
            $data['status'] = $this->psbsiswa_model->getKeaktifan();
            $data['roles'] = $this->psbsiswa_model->getUserRoles();
            $data['gender'] = $this->psbsiswa_model->getGender();
            $data['agama'] = $this->psbsiswa_model->getAgama();
            $data['jalur_masuk'] = $this->psbsiswa_model->getJalurMasuk();
            $data['jurusan'] = $this->psbsiswa_model->getJurusan();
            $data['pondok'] = $this->psbsiswa_model->getPondok();
            $data['jenis_tinggal'] = $this->psbsiswa_model->getJenisTinggal();
            $data['jarak_tinggal'] = $this->psbsiswa_model->getJarakTinggal();
            $data['transportasi'] = $this->psbsiswa_model->getTransportasi();
            $data['hobi'] = $this->psbsiswa_model->getHobi();
            $data['citacita'] = $this->psbsiswa_model->getCitaCita();
            $data['sekolah_asal'] = $this->psbsiswa_model->getSekolahAsal();
            $data['pendidikan_ayah'] = $this->psbsiswa_model->getPendidikanTerakhir();
            $data['pekerjaan_ayah'] = $this->psbsiswa_model->getPekerjaan();
            $data['penghasilan_ayah'] = $this->psbsiswa_model->getPenghasilan();
            $data['pendidikan_ibu'] = $this->psbsiswa_model->getPendidikanTerakhir();
            $data['pekerjaan_ibu'] = $this->psbsiswa_model->getPekerjaan();
            $data['penghasilan_ibu'] = $this->psbsiswa_model->getPenghasilan();
            $data['pendidikan_wali'] = $this->psbsiswa_model->getPendidikanTerakhir();
            $data['pekerjaan_wali'] = $this->psbsiswa_model->getPekerjaan();
            $data['penghasilan_wali'] = $this->psbsiswa_model->getPenghasilan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("PsbSiswa/edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the PsbSiswa information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_pendaftaran = $this->input->post('id_pendaftaran');
            
            $this->form_validation->set_rules('nisn','NISN','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('nik','NIK','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('nama','Nama','trim|required|max_length[100]xss_clean');
            $this->form_validation->set_rules('password','Password','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('tmp_lahir','Tempat Lahir','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('tgl_lahir','tgl_lahir','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('gender','gender','trim|required|numeric');
            $this->form_validation->set_rules('tahun_masuk','tahun_masuk','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('agama','agama','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('anak_ke','anak_ke','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('jml_sdr','jml_sdr','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('jalur_masuk','jalur_masuk','trim|required|numeric');
            $this->form_validation->set_rules('jurusan','jurusan','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('pondok','pondok','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('jenis_tinggal','jenis_tinggal','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('desa','desa','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('dukuh','dukuh','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('rt','rt','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('rw','rw','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('kecamatan','kecamatan','trim|required|max_length[30]xss_clean');
            $this->form_validation->set_rules('kabupaten','kabupaten','trim|required|max_length[30]xss_clean');
            $this->form_validation->set_rules('provinsi','provinsi','trim|required|max_length[30]xss_clean');
            $this->form_validation->set_rules('kode_pos','kode_pos','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('jarak_tinggal','jarak_tinggal','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('transportasi','transportasi','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('hobi','hobi','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('citacita','citacita','trim|required|max_length[10]xss_clean');
            $this->form_validation->set_rules('hp_siswa','hp_siswa','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('foto','foto','trim|max_length[225]xss_clean');
            $this->form_validation->set_rules('no_kip','no_kip','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_kis','no_kis','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_kartu_lain','no_kartu_lain','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('sekolah_asal','sekolah_asal','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('nama_sekolah_asal','nama_sekolah_asal','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('alamat_sekolah_asal','alamat_sekolah_asal','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('no_peserta_ujian','no_peserta_ujian','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_ijazah','no_ijazah','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_shun','no_shun','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('nilai_un','nilai_un','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('no_shuambn','no_shuambn','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('nilai_uambn','nilai_uambn','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('p_smt_empat_gasal','p_smt_empat_gasal','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_empat_genap','p_smt_empat_genap','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_lima_gasal','p_smt_lima_gasal','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_lima_genap','p_smt_lima_genap','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_enam_gasal','p_smt_enam_gasal','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('p_smt_enam_genap','p_smt_enam_genap','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('prestasi_satu','prestasi_satu','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_dua','prestasi_dua','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_tiga','prestasi_tiga','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_empat','prestasi_empat','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_lima','prestasi_lima','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('prestasi_enam','prestasi_enam','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('nama_ayah_kandung','nama_ayah_kandung','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nama_ayah_tiri','nama_ayah_tiri','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nik_ayah','nik_ayah','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('thn_lahir_ayah','thn_lahir_ayah','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('pendidikan_ayah','pendidikan_ayah','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('pekerjaan_ayah','pekerjaan_ayah','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('penghasilan_ayah','penghasilan_ayah','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('alamat_ayah','alamat_ayah','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('hp_ayah','hp_ayah','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('nama_ibu_kandung','nama_ibu_kandung','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nama_ibu_tiri','nama_ibu_tiri','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nik_ibu','nik_ibu','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('thn_lahir_ibu','thn_lahir_ibu','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('pendidikan_ibu','pendidikan_ibu','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('pekerjaan_ibu','pekerjaan_ibu','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('penghasilan_ibu','penghasilan_ibu','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('alamat_ibu','alamat_ibu','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('hp_ibu','hp_ibu','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('nama_wali_kandung','nama_wali_kandung','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('nik_wali','nik_wali','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('thn_lahir_wali','thn_lahir_wali','trim|max_length[50]xss_clean');
            $this->form_validation->set_rules('pendidikan_wali','pendidikan_wali','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('pekerjaan_wali','pekerjaan_wali','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('penghasilan_wali','penghasilan_wali','trim|max_length[10]xss_clean');
            $this->form_validation->set_rules('alamat_wali','alamat_wali','trim|max_length[100]xss_clean');
            $this->form_validation->set_rules('hp_wali','hp_wali','trim|max_length[20]xss_clean');
            $this->form_validation->set_rules('status', 'status', 'trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_pendaftaran);
            }
            else
            {
                $nisn = $this->input->post('nisn');
                $nik = $this->input->post('nik');
                $nama = strtoupper($this->input->post('nama'));
                $password = $this->input->post('password');
                $tmp_lahir = $this->input->post('tmp_lahir');
                $tgl_lahir = $this->input->post('tgl_lahir');
                $id_gender = $this->input->post('gender');
                $tahun_masuk = $this->input->post('tahun_masuk');
                $id_agama = $this->input->post('agama');
                $anak_ke = $this->input->post('anak_ke');
                $jml_sdr = $this->input->post('jml_sdr');
                $id_jalur_masuk = $this->input->post('jalur_masuk');
                $id_jurusan = $this->input->post('jurusan');
                $id_pondok = $this->input->post('pondok');
                $id_jenis_tinggal = $this->input->post('jenis_tinggal');
                $desa = strtoupper($this->input->post('desa'));
                $dukuh = strtoupper($this->input->post('dukuh'));
                $rt = $this->input->post('rt');
                $rw = $this->input->post('rw');
                $kecamatan = strtoupper($this->input->post('kecamatan'));
                $kabupaten = strtoupper($this->input->post('kabupaten'));
                $provinsi = strtoupper($this->input->post('provinsi'));
                $kode_pos = $this->input->post('kode_pos');
                $id_jarak = $this->input->post('jarak_tinggal');
                $id_transportasi = $this->input->post('transportasi');
                $id_hobi = $this->input->post('hobi');
                $id_cita_cita = $this->input->post('citacita');
                $hp_siswa = $this->input->post('hp_siswa');
                $foto = $this->input->post('foto');
                $no_kip = $this->input->post('no_kip');
                $no_kis = $this->input->post('no_kis');
                $no_kartu_lain = $this->input->post('no_kartu_lain');
                $id_sekolah_asal = $this->input->post('sekolah_asal');
                $nama_sekolah_asal = strtoupper($this->input->post('nama_sekolah_asal'));
                $alamat_sekolah_asal = $this->input->post('alamat_sekolah_asal');
                $no_peserta_ujian = $this->input->post('no_peserta_ujian');
                $no_ijazah = $this->input->post('no_ijazah');
                $no_shun = $this->input->post('no_shun');
                $nilai_un = $this->input->post('nilai_un');
                $no_shuambn = $this->input->post('no_shuambn');
                $nilai_uambn = $this->input->post('nilai_uambn');
                $p_smt_empat_gasal = $this->input->post('p_smt_empat_gasal');
                $p_smt_empat_genap = $this->input->post('p_smt_empat_genap');
                $p_smt_lima_gasal = $this->input->post('p_smt_lima_gasal');
                $p_smt_lima_genap = $this->input->post('p_smt_lima_genap');
                $p_smt_enam_gasal = $this->input->post('p_smt_enam_gasal');
                $p_smt_enam_genap = $this->input->post('p_smt_enam_genap');
                $prestasi_satu = $this->input->post('prestasi_satu');
                $prestasi_dua = $this->input->post('prestasi_dua');
                $prestasi_tiga = $this->input->post('prestasi_tiga');
                $prestasi_empat = $this->input->post('prestasi_empat');
                $prestasi_lima = $this->input->post('prestasi_lima');
                $prestasi_enam = $this->input->post('prestasi_enam');
                $nama_ayah_kandung = strtoupper($this->input->post('nama_ayah_kandung'));
                $nama_ayah_tiri = strtoupper($this->input->post('nama_ayah_tiri'));
                $nik_ayah = $this->input->post('nik_ayah');
                $thn_lahir_ayah = $this->input->post('thn_lahir_ayah');
                $id_pendidikan_ayah = $this->input->post('pendidikan_ayah');
                $id_pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
                $id_penghasilan_ayah = $this->input->post('penghasilan_ayah');
                $alamat_ayah = $this->input->post('alamat_ayah');
                $hp_ayah = $this->input->post('hp_ayah');
                $nama_ibu_kandung = strtoupper($this->input->post('nama_ibu_kandung'));
                $nama_ibu_tiri = strtoupper($this->input->post('nama_ibu_tiri'));
                $nik_ibu = $this->input->post('nik_ibu');
                $thn_lahir_ibu = $this->input->post('thn_lahir_ibu');
                $id_pendidikan_ibu = $this->input->post('pendidikan_ibu');
                $id_pekerjaan_ibu = $this->input->post('pekerjaan_ibu');
                $id_penghasilan_ibu = $this->input->post('penghasilan_ibu');
                $alamat_ibu = strtoupper($this->input->post('alamat_ibu'));
                $hp_ibu = $this->input->post('hp_ibu');
                $nama_wali = strtoupper($this->input->post('nama_wali'));
                $nik_wali = $this->input->post('nik_wali');
                $thn_lahir_wali = $this->input->post('thn_lahir_wali');
                $id_pendidikan_wali = $this->input->post('pendidikan_wali');
                $id_pekerjaan_wali = $this->input->post('pekerjaan_wali');
                $id_penghasilan_wali = $this->input->post('penghasilan_wali');
                $alamat_wali = strtoupper($this->input->post('alamat_wali'));
                $hp_wali = $this->input->post('hp_wali');
                $id_aktif = $this->input->post('status');
                
                $psbsiswaInfo = array(
                    'nisn'=>$nisn, 
                    'nik'=>$nik, 
                    'nama'=>$nama, 
                    'password'=>getHashedPassword($password), 
                    'tmp_lahir'=>$tmp_lahir, 
                    'tgl_lahir'=>$tgl_lahir, 
                    'id_gender'=>$id_gender,
                    'tahun_masuk'=>$tahun_masuk, 
                    'id_agama'=>$id_agama,
                    'anak_ke'=>$anak_ke,
                    'jml_sdr'=>$jml_sdr,
                    'id_jalur_masuk'=>$id_jalur_masuk,
                    'id_jurusan'=>$id_jurusan,
                    'id_pondok'=>$id_pondok,
                    'id_jenis_tinggal'=>$id_jenis_tinggal,
                    'desa'=>$desa,
                    'dukuh'=>$dukuh,
                    'rt'=>$rt,
                    'rw'=>$rw,
                    'kecamatan'=>$kecamatan,
                    'kabupaten'=>$kabupaten,
                    'provinsi'=>$provinsi,
                    'kode_pos'=>$kode_pos,
                    'id_jarak'=>$id_jarak,
                    'id_transportasi'=>$id_transportasi,
                    'id_hobi'=>$id_hobi,
                    'id_cita_cita'=>$id_cita_cita,
                    'hp_siswa'=>$hp_siswa,
                    'foto'=>$foto,
                    'no_kip'=>$no_kip,
                    'no_kis'=>$no_kis,
                    'no_kartu_lain'=>$no_kartu_lain,
                    'id_sekolah_asal'=>$id_sekolah_asal,
                    'nama_sekolah_asal'=>$nama_sekolah_asal,
                    'alamat_sekolah_asal'=>$alamat_sekolah_asal,
                    'no_peserta_ujian'=>$no_peserta_ujian,
                    'no_ijazah'=>$no_ijazah,
                    'no_shun'=>$no_shun,
                    'nilai_un'=>$nilai_un,
                    'no_shuambn'=>$no_shuambn,
                    'nilai_uambn'=>$nilai_uambn,
                    'p_smt_empat_gasal'=>$p_smt_empat_gasal,
                    'p_smt_empat_genap'=>$p_smt_empat_genap,
                    'p_smt_lima_gasal'=>$p_smt_lima_gasal,
                    'p_smt_lima_genap'=>$p_smt_lima_genap,
                    'p_smt_enam_gasal'=>$p_smt_enam_gasal,
                    'p_smt_enam_genap'=>$p_smt_enam_genap,
                    'prestasi_satu'=>$prestasi_satu,
                    'prestasi_dua'=>$prestasi_dua,
                    'prestasi_tiga'=>$prestasi_tiga,
                    'prestasi_empat'=>$prestasi_empat,
                    'prestasi_lima'=>$prestasi_lima,
                    'prestasi_enam'=>$prestasi_enam,
                    'nama_ayah_kandung'=>$nama_ayah_kandung,
                    'nama_ayah_tiri'=>$nama_ayah_tiri,
                    'nik_ayah'=>$nik_ayah,
                    'thn_lahir_ayah'=>$thn_lahir_ayah,
                    'id_pendidikan_ayah'=>$id_pendidikan_ayah,
                    'id_pekerjaan_ayah'=>$id_pekerjaan_ayah,
                    'id_penghasilan_ayah'=>$id_penghasilan_ayah,
                    'alamat_ayah'=>$alamat_ayah,
                    'hp_ayah'=>$hp_ayah,
                    'nama_ibu_kandung'=>$nama_ibu_kandung,
                    'nama_ibu_tiri'=>$nama_ibu_tiri,
                    'nik_ibu'=>$nik_ibu,
                    'thn_lahir_ibu'=>$thn_lahir_ibu,
                    'id_pendidikan_ibu'=>$id_pendidikan_ibu,
                    'id_pekerjaan_ibu'=>$id_pekerjaan_ibu,
                    'id_penghasilan_ibu'=>$id_penghasilan_ibu,
                    'alamat_ibu'=>$alamat_ibu,
                    'hp_ibu'=>$hp_ibu,
                    'nama_wali'=>$nama_wali,
                    'nik_wali'=>$nik_wali,
                    'thn_lahir_wali'=>$thn_lahir_wali,
                    'id_pendidikan_wali'=>$id_pendidikan_wali,
                    'id_pekerjaan_wali'=>$id_pekerjaan_wali,
                    'id_penghasilan_wali'=>$id_penghasilan_wali,
                    'alamat_wali'=>$alamat_wali,
                    'hp_wali'=>$hp_wali,
                    'CreatedBy'=>$this->vendorId,
                    'CreatedDate'=>date('Y-m-d H:i:s'),
                    'UpdatedBy'=>$this->vendorId,
                    'UpdatedDate'=>date('Y-m-d H:i:s'),
                    'id_aktif'=>$id_aktif);

                $result = $this->psbsiswa_model->EditPsbSiswa($psbsiswaInfo, $id_pendaftaran);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-siswa-psb');
            }
        }
    }

    /**
     * This function is used load PsbSiswa detail information
     * @param number $id_pendaftaran : Optional : This is PsbSiswa id
     */
    function Detail($id_pendaftaran = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('psbsiswa_model');
            
            $data['psbsiswaInfoDetail'] = $this->psbsiswa_model->GetPsbSiswaInfoDetail($id_pendaftaran);
            //$data['status'] = $this->psbsiswa_model->getKeaktifan();
            //$data['roles'] = $this->psbsiswa_model->getUserRoles();
            //$data['gender'] = $this->psbsiswa_model->getGender();
            //$data['agama'] = $this->psbsiswa_model->getAgama();
            //$data['jalur_masuk'] = $this->psbsiswa_model->getJalurMasuk();
            //$data['jurusan'] = $this->psbsiswa_model->getJurusan();
            //$data['pondok'] = $this->psbsiswa_model->getPondok();
            //$data['jenis_tinggal'] = $this->psbsiswa_model->getJenisTinggal();
            //$data['jarak_tinggal'] = $this->psbsiswa_model->getJarakTinggal();
            //$data['transportasi'] = $this->psbsiswa_model->getTransportasi();
            //$data['hobi'] = $this->psbsiswa_model->getHobi();
            //$data['citacita'] = $this->psbsiswa_model->getCitaCita();
            //$data['sekolah_asal'] = $this->psbsiswa_model->getSekolahAsal();
            //$data['pendidikan_ayah'] = $this->psbsiswa_model->getPendidikanTerakhir();
            //$data['pekerjaan_ayah'] = $this->psbsiswa_model->getPekerjaan();
            //$data['penghasilan_ayah'] = $this->psbsiswa_model->getPenghasilan();
            //$data['pendidikan_ibu'] = $this->psbsiswa_model->getPendidikanTerakhir();
            //$data['pekerjaan_ibu'] = $this->psbsiswa_model->getPekerjaan();
            //$data['penghasilan_ibu'] = $this->psbsiswa_model->getPenghasilan();
            //$data['pendidikan_wali'] = $this->psbsiswa_model->getPendidikanTerakhir();
            //$data['pekerjaan_wali'] = $this->psbsiswa_model->getPekerjaan();
            //$data['penghasilan_wali'] = $this->psbsiswa_model->getPenghasilan();
            
            //$data['psbsiswaRecords'] = $this->psbsiswa_model->GetPsbSiswaInfoDetail($id_pendaftaran);
            //$result = $this->psbsiswa_model->DetailPsbSiswa($psbsiswaInfoDetail, $id_pendaftaran);
            $this->global['pageTitle'] = 'SIMDAFA : Detail Data';
            
            $this->loadViews("PsbSiswa/detail", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to Print the PsbSiswa using id_pendaftaran
     * @return boolean $result : TRUE / FALSE
     */
    function Cetak($id_pendaftaran = NULL)
    {
        $this->load->model('psbsiswa_model');
            
        $this->load->library('CFPDF');
        //$this->load->library('fpdf');
        $pdf = new FPDF();
        
        /*
        * P  = Paper Orientation
        * mm = Size Unit
        * F4 = Paper Size
        */
        $pdf = new FPDF('P','mm','A4');
        $pdf->AddPage();
        /*
         Set Font ('Font Name', 'Style', 'Size')
        */
        $pdf->Image('application/libraries/kop_mts.jpg',8,2,190,45);
        $pdf->SetFont('Courier','B',14);
        $pdf->Cell(190,40,'',0,0,'C');
        $pdf->Ln();

        $pdf->SetFont('Arial','B',12);
        // mencetak string 
        $pdf->Cell(190,7,'FORMULIR PENDAFTARAN PESERTA DIDIK BARU',0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'TAHUN PELAJARAN 2020/2021',0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'I. BIODATA SISWA',0,1,'L');
        

        // Koneksi database
        $psbsiswaInfoDetail = $this->psbsiswa_model->GetPsbSiswaInfoDetail($id_pendaftaran);
        $id_pendaftaran         = '';
        $nisn                   = '';
        $nik                    = '';
        $nama                   = '';
        $gender                 = '';
        $tmp_lahir              = '';
        $tgl_lahir              = '';
        $nama_jurusan           = '';
        $anak_ke                = '';
        $jml_sdr                = '';
        $desa                   = '';
        $dukuh                  = '';
        $rt                     = '';
        $rw                     = '';
        $kecamatan              = '';
        $kabupaten              = '';
        $hp_siswa               = '';
        $jenis_tinggal          = '';
        $nama_pondok            = '';
        $nama_ayah_kandung      = '';
        $pendidikan_terakhir    = '';
        $pekerjaan              = '';
        $penghasilan            = '';
        $alamat_ayah            = '';
        $hp_ayah                = '';
        $nama_ibu_kandung       = '';
        $ket_pendidikan    = '';
        $pekerjaan              = '';
        $penghasilan            = '';
        $alamat_ibu             = '';
        $hp_ibu                 = '';
        $nama_wali              = '';
        $alamat_wali            = '';
        $hp_wali                = '';
        $nama_sekolah_asal      = '';
        $alamat_sekolah_asal    = '';
        $p_smt_empat_gasal      = '';
        $p_smt_empat_genap      = '';
        $p_smt_lima_gasal       = '';
        $p_smt_lima_genap       = '';
        $p_smt_enam_gasal       = '';
        $p_smt_enam_genap       = '';
        $prestasi_satu          = '';
        $prestasi_dua           = '';
        $prestasi_tiga          = '';
        $prestasi_empat         = '';
        $prestasi_lima          = '';
        $prestasi_enam          = '';
        $prestasi_enam          = '';

        if(!empty($psbsiswaInfoDetail)){

        //$this->db->get('tbl_psb_siswa')->result();
        foreach ($psbsiswaInfoDetail as $psb){
            $id_pendaftaran         = $psb->id_pendaftaran;
            $nisn                   = $psb->nisn;
            $nik                    = $psb->nik;
            $nama                   = $psb->nama;
            $gender                 = $psb->gender;
            $tmp_lahir              = $psb->tmp_lahir;
            $tgl_lahir              = $psb->tgl_lahir;
            $nama_jurusan           = $psb->nama_jurusan;
            $anak_ke                = $psb->anak_ke;
            $jml_sdr                = $psb->jml_sdr;
            $desa                   = $psb->desa;
            $dukuh                  = $psb->dukuh;
            $rt                     = $psb->rt;
            $rw                     = $psb->rw;
            $kecamatan              = $psb->kecamatan;
            $kabupaten              = $psb->kabupaten;
            $hp_siswa               = $psb->hp_siswa;
            $jenis_tinggal          = $psb->jenis_tinggal;
            $nama_pondok            = $psb->nama_pondok;
            $nama_ayah_kandung      = $psb->nama_ayah_kandung;
            $pendidikan_terakhir    = $psb->pendidikan_terakhir;
            $pekerjaan              = $psb->pekerjaan;
            $penghasilan            = $psb->penghasilan;
            $alamat_ayah            = $psb->alamat_ayah;
            $hp_ayah                = $psb->hp_ayah;
            $nama_ibu_kandung       = $psb->nama_ibu_kandung;
            $ket_pendidikan         = $psb->ket_pendidikan;
            $pekerjaan              = $psb->pekerjaan;
            $penghasilan            = $psb->penghasilan;
            $alamat_ibu             = $psb->alamat_ibu;
            $hp_ibu                 = $psb->hp_ibu;
            $nama_wali              = $psb->nama_wali;
            $alamat_wali            = $psb->alamat_wali;
            $hp_wali                = $psb->hp_wali;
            $nama_sekolah_asal      = $psb->nama_sekolah_asal;
            $alamat_sekolah_asal    = $psb->alamat_sekolah_asal;
            $p_smt_empat_gasal      = $psb->p_smt_empat_gasal;
            $p_smt_empat_genap      = $psb->p_smt_empat_genap;
            $p_smt_lima_gasal       = $psb->p_smt_lima_gasal;
            $p_smt_lima_genap       = $psb->p_smt_lima_genap;
            $p_smt_enam_gasal       = $psb->p_smt_enam_gasal;
            $p_smt_enam_genap       = $psb->p_smt_enam_genap;
            $prestasi_satu          = $psb->prestasi_satu;
            $prestasi_dua           = $psb->prestasi_dua;
            $prestasi_tiga          = $psb->prestasi_tiga;
            $prestasi_empat         = $psb->prestasi_empat;
            $prestasi_lima          = $psb->prestasi_lima;
            $prestasi_enam          = $psb->prestasi_enam;
            $CreatedDate            = $psb->CreatedDate;

            }
        }
        // Memberikan space kebawah agar tidak terlalu rapat
        
        $pdf->SetFont('Arial','B',11);
        $pdf->Cell(60,7,'No Pendaftaran',1,0);
        $pdf->Cell(130,7,'2021-'.$id_pendaftaran,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Nama Lengkap',1,0);
        $pdf->Cell(130,7,$nama,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'NISN',1,0);
        $pdf->Cell(130,7,$nisn,1,1);
        $pdf->Cell(60,7,'NIK',1,0);
        $pdf->Cell(130,7,$nik,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Jenis Kelamin',1,0);
        $pdf->Cell(130,7,$gender,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Tempat Tanggal Lahir',1,0);
        $pdf->Cell(130,7,$tmp_lahir.', '.$tgl_lahir,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Jurusan',1,0);
        $pdf->Cell(130,7,$nama_jurusan,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Anak Ke',1,0);
        $pdf->Cell(130,7,$anak_ke.'/'.$jml_sdr,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Alamat',1,0);
        $pdf->Cell(130,7,$desa.' '.$dukuh.', '.'RT.'.$rt.'/'.$rw.' '.$kecamatan.' '.$kabupaten,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'No HP Siswa',1,0);
        $pdf->Cell(130,7,$hp_siswa,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Jenis Tinggal',1,0);
        $pdf->Cell(130,7,$jenis_tinggal,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Pondok',1,0);
        $pdf->Cell(130,7,$nama_pondok,1,0);
        $pdf->SetFont('Arial','',10);
        $pdf->Ln();
        $pdf->Ln();
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'II. DATA KELUARGA',0,1,'L');
        $pdf->SetFont('Arial','B',11);
        $pdf->Cell(60,7,'Nama Ayah',1,0);
        $pdf->Cell(130,7,$nama_ayah_kandung,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Nama Ibu',1,0);
        $pdf->Cell(130,7,$nama_ibu_kandung,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Pekerjaan Orang Tua',1,0);
        $pdf->Cell(130,7,$pekerjaan,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Penghasilan Orang Tua',1,0);
        $pdf->Cell(130,7,$penghasilan,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Alamat Orang Tua',1,0);
        $pdf->Cell(130,7,$alamat_ayah,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'No Hp Orang Tua',1,0);
        $pdf->Cell(130,7,$hp_ayah,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Nama Wali',1,0);
        $pdf->Cell(130,7,$nama_wali,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Alamat Wali',1,0);
        $pdf->Cell(130,7,$alamat_wali,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'No HP Wali',1,0);
        $pdf->Cell(130,7,$hp_wali,1,0);
        $pdf->SetFont('Arial','',10);
        $pdf->Ln();
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'III. DATA SEKOLAH ASAL',0,1,'L');
        $pdf->SetFont('Arial','B',11);
        $pdf->Cell(60,7,'Sekolah Asal',1,0);
        $pdf->Cell(130,7,$nama_sekolah_asal,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Alamat Sekolah Asal',1,0);
        $pdf->Cell(130,7,$alamat_sekolah_asal,1,1);
        $pdf->Cell(60,7,'Rangking Smt VII',1,0);
        $pdf->Cell(130,7,$p_smt_empat_gasal,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Rangking Smt VIII',1,0);
        $pdf->Cell(130,7,$p_smt_empat_genap,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Rangking Smt IX',1,0);
        $pdf->Cell(130,7,$p_smt_lima_gasal,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Rangking Smt X',1,0);
        $pdf->Cell(130,7,$p_smt_lima_genap,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Rangking Smt XI',1,0);
        $pdf->Cell(130,7,$p_smt_enam_gasal,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Rangking Smt XII',1,0);
        $pdf->Cell(130,7,$p_smt_enam_genap,1,0);
        $pdf->Ln();
        $pdf->SetFont('Arial','',10);
        $pdf->Ln();
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'IV. PRESTASI LAINNYA',0,1,'L');
        $pdf->SetFont('Arial','B',11);
        $pdf->Cell(60,7,'Prestasi Lain',1,0);
        $pdf->Cell(130,7,$prestasi_satu,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Prestasi Lain',1,0);
        $pdf->Cell(130,7,$prestasi_dua,1,1);
        $pdf->Cell(60,7,'Prestasi Lain',1,0);
        $pdf->Cell(130,7,$prestasi_tiga,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Prestasi Lain',1,0);
        $pdf->Cell(130,7,$prestasi_enam,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Prestasi Lain',1,0);
        $pdf->Cell(130,7,$prestasi_lima,1,0);
        $pdf->Ln();
        $pdf->Cell(60,7,'Prestasi Lain',1,0);
        $pdf->Cell(130,7,$prestasi_enam,1,0);
        $pdf->Ln();
        $pdf->SetFont('Arial','',10);
        $pdf->Ln();
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'V. PERNYATAAN',0,1,'L');
        $pdf->SetFont('Arial','B',11);
        $pdf->Cell(190,7,'Saya yang bertanda tangan di bawah ini menyatakan bahwa data yang saya isikan adalah',0,1,'L'); 
        $pdf->Cell(190,7,'sesuai dengan kondisi sebenarnya.',0,1,'L');
        $pdf->Ln();
        $pdf->Cell(130,7,'',0,0);
        $pdf->Cell(60,7,'Sirahan,'.date("d/m/Y"),0,0,'L');
        $pdf->Ln();
        $pdf->Cell(60,7,'Petugas Pendaftaran',0,0);
        $pdf->Cell(70,7,'Orang Tua/Wali',0,0);
        $pdf->Cell(70,7,'Pendaftar',0,0);
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Cell(60,7,'(.................................)',0,0);
        $pdf->Cell(70,7,'(.................................)',0,0);
        $pdf->Cell(60,7,$nama,0,0);
        $pdf->Ln();
        $pdf->AddPage();
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,7,'SURAT PERNYATAAN',0,1,'C');
        $pdf->SetFont('Arial','',11);
        $pdf->Ln();
        $pdf->Cell(190,7,'Yang bertanda tangan dibawah ini :',0,1,'L');
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(60,7,'Nama (orang tua) ',0,0);
        $pdf->Cell(60,7,': '.$nama_ayah_kandung,0,0);
        $pdf->Ln();
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(60,7,'Alamat ',0,0);
        $pdf->Cell(60,7,': '.$alamat_ayah,0,0);
        $pdf->Ln();
        $pdf->Cell(190,7,'menyatakan dengan sesungguhnya :',0,1,'L');
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(60,7,'Nama ',0,0);
        $pdf->Cell(60,7,': '.$nama,0,0);
        $pdf->Ln();
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(60,7,'Alamat ',0,0);
        $pdf->Cell(60,7,': '.$desa.' '.$dukuh.', '.'RT.'.$rt.'/'.$rw.' '.$kecamatan.' '.$kabupaten,0,0);
        $pdf->Ln();
        $pdf->Cell(190,7,'menyatakan dengan sesungguhnya :',0,1,'L');
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(190,7,'1. Berniat menuntut ilmu di Perguruan Islam Darul Falah Sirahan hanya semata-mata karena Allah SWT.',0,1,'L');
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(190,7,'2. Bersedia untuk mentaati segala peraturan yang berlaku di Madrasah Darul Falah Sirahan',0,1,'L');
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(190,7,'3. Bersedia membayar segala bentuk kontribusi/iuran yang telah ditentukan oleh pihak madrasah',0,1,'L');
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(190,7,'4. Menerima segala bentuk keputusan hasil tes seleksi masuk dari Panitia Penerimaan Siswa Baru.',0,1,'L');
        $pdf->Cell(10,7,'',0,0);
        $pdf->Cell(190,7,'5. Bersedia menjalin hubungan kerjasama dengan pihak madrasah.',0,1,'L');
        $pdf->Ln();
        $pdf->Cell(190,7,'Demikian pernyataan kami, untuk dapat dipergunakan seperlunya.',0,1,'L');
        $pdf->Ln();
        $pdf->Cell(120,7,'',0,0);
        $pdf->Cell(50,7,'Sirahan,'.date("d/m/Y"),0,0,'L');
        $pdf->Ln();
        $pdf->Cell(120,7,'',0,0);
        $pdf->Cell(50,7,'Orang Tua/Wali',0,0,'L');
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Ln();
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(120,7,'',0,0);
        $pdf->Cell(50,7,$nama_ayah_kandung,0,0,'L');
        $pdf->Ln();
        $pdf->Ln();
        $pdf->SetFont('Arial','',9);
        $pdf->Cell(190,7,'---------------------------------------------------------------------------- Potong  Disini ----------------------------------------------------------------------------',0,0);
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Ln();
        $pdf->SetFont('Arial','B',9);
        $pdf->Cell(90,5,'KARTU PESERTA UJIAN SELEKSI SISWA BARU',0,0,'C');
        $pdf->Ln();
        $pdf->Cell(90,7,'TAHUN PELAJARAN 2020/2021',0,0, 'C');
        $pdf->Ln();
        $pdf->SetFont('Arial','',9);
        $pdf->Cell(17,5,'Nomor ',0,0,'L');
        $pdf->Cell(10,5,': 2021-'.$id_pendaftaran,0,0,'L');
        $pdf->Ln();
        $pdf->Cell(17,5,'Nama ',0,0,'L');
        $pdf->Cell(10,5,': '.$nama,0,0,'L');
        $pdf->Ln();
        $pdf->Cell(17,5,'Alamat ',0,0,'L');
        $pdf->Cell(10,5,': '.$desa.' '.$dukuh.', '.'RT.'.$rt.'/'.$rw,0,0,'L');
        $pdf->Ln();
        $pdf->Cell(17,5,'',0,0,'L');
        $pdf->Cell(10,5,'  '.$kecamatan.' '.$kabupaten,0,0,'L');
        $pdf->Ln();
        $pdf->Cell(75,7,'Sirahan,  '.date("d/m/Y"),0,0,'R');
        $pdf->Ln();
        $pdf->Cell(75,7,'Petugas Pendaftaran',0,0,'R');
        $pdf->Ln();
        $pdf->Ln();
        $pdf->Cell(75,9,'.................................',0,0,'R');
        $pdf->Image('application/libraries/kop_tes_psb.jpg',6,190,90,18);
        $pdf->Image('application/libraries/jadwal_tes_psb.JPG',98,190,108,90);
        $pdf->Image('application/libraries/foto3x4.jpg',10,250,20,25);
        $pdf->Line(0, 185, 220, 185);
        $pdf->Line(0, 285, 220, 285);
        
        
        $pdf->Output();
    }

    /**
     * This function is used to delete the PsbSiswa using id_pendaftaran
     * @return boolean $result : TRUE / FALSE
     */
    function deletePsbSiswa()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_pendaftaran = $this->input->post('id_pendaftaran');
            $psbsiswaInfo = array('isDeleted'=>1);
            
            $result = $this->psbsiswa_model->deletePsbSiswa($id_pendaftaran, $psbsiswaInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}