<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Pekerjaan (PekerjaanController)
 * Prodile Class to control all Pekerjaan related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class Pekerjaan extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('pekerjaan_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the Pekerjaan
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Pekerjaan';
        
        $this->loadViews("Pekerjaan/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the Pekerjaan list
     */
    function PekerjaanList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('pekerjaan_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->pekerjaan_model->PekerjaanListCount($searchText);

			$returns = $this->paginationCompress ( "list-pekerjaan/", $count, 10 );
            
            $data['pekerjaanRecords'] = $this->pekerjaan_model->PekerjaanList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : Pekerjaan';
            
            $this->loadViews("Pekerjaan/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('pekerjaan_model');
            $data['status'] = $this->pekerjaan_model->getKeaktifan();
            $data['roles'] = $this->pekerjaan_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("Pekerjaan/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new Pekerjaan
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('pekerjaan','Pekerjaan','trim|required|max_length[20]|xss_clean');
            $this->form_validation->set_rules('ket_pekerjaan','Keterangan','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $pekerjaan = $this->input->post('pekerjaan');
                $ket_pekerjaan = $this->input->post('ket_pekerjaan');
                $id_aktif = $this->input->post('status');
                
                $pekerjaanInfo = array('pekerjaan'=>$pekerjaan, 'ket_pekerjaan'=>$ket_pekerjaan, 'id_aktif'=>$id_aktif);
                
                $this->load->model('pekerjaan_model');
                $result = $this->pekerjaan_model->AddNew($pekerjaanInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-pekerjaan');
            }
        }
    }

    /**
     * This function is used load Pekerjaan edit information
     * @param number $id_pekerjaan : Optional : This is Pekerjaan id
     */
    function Edit($id_pekerjaan = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            $data['pekerjaanInfo'] = $this->pekerjaan_model->GetPekerjaanInfo($id_pekerjaan);
            $data['status'] = $this->pekerjaan_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("Pekerjaan/edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the Pekerjaan information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_pekerjaan = $this->input->post('id_pekerjaan');
            
            $this->form_validation->set_rules('pekerjaan','Pekerjaan','trim|required|max_length[20]|xss_clean');
            $this->form_validation->set_rules('ket_pekerjaan','Keterangan','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_pekerjaan);
            }
            else
            {
                $pekerjaan = $this->input->post('pekerjaan');
                $ket_pekerjaan = $this->input->post('ket_pekerjaan');
                $id_aktif = $this->input->post('status');
                
                $pekerjaanInfo = array( 'pekerjaan'=>$pekerjaan, 'ket_pekerjaan'=> $ket_pekerjaan, 'id_aktif'=> $id_aktif);

                $result = $this->pekerjaan_model->EditPekerjaan($pekerjaanInfo, $id_pekerjaan);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-pekerjaan');
            }
        }
    }


    /**
     * This function is used to delete the Pekerjaan using id_pekerjaan
     * @return boolean $result : TRUE / FALSE
     */
    function deletePekerjaan()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_pekerjaan = $this->input->post('id_pekerjaan');
            $pekerjaanInfo = array('isDeleted'=>1);
            
            $result = $this->pekerjaan_model->deletePekerjaan($id_pekerjaan, $pekerjaanInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}