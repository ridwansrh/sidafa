<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Citacita (CitacitaController)
 * Prodile Class to control all Citacita related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class Citacita extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('citacita_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the Cita Cita
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Cita Cita';
        
        $this->loadViews("Citacita/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the Cita Cita list
     */
    function CitaList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('citacita_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->citacita_model->CitaListCount($searchText);

			$returns = $this->paginationCompress ( "CitaList/", $count, 10 );
            
            $data['citaRecords'] = $this->citacita_model->CitaList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : Cita Cita';
            
            $this->loadViews("Citacita/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('citacita_model');
            $data['status'] = $this->citacita_model->getKeaktifan();
            $data['roles'] = $this->citacita_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("Citacita/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new Cita Cita
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('nama_cita_cita','Cita Cita','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('keterangan','Keterangan','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|max_length[20]xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $nama_cita_cita = $this->input->post('nama_cita_cita');
                $keterangan = $this->input->post('keterangan');
                $id_aktif = $this->input->post('status');
                
                $citaInfo = array('nama_cita_cita'=>$nama_cita_cita, 'keterangan'=>$keterangan, 'id_aktif'=>$id_aktif);
                
                $this->load->model('citacita_model');
                $result = $this->citacita_model->AddNew($citaInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-citacita');
            }
        }
    }

    /**
     * This function is used load Cita Cita edit information
     * @param number $id_cita_cita : Optional : This is Cita Cita id
     */
    function Edit($id_cita_cita = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            $data['citaInfo'] = $this->citacita_model->GetCitaInfo($id_cita_cita);
            $data['status'] = $this->citacita_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("Citacita/Edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the Cita Cita information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_cita_cita = $this->input->post('id_cita_cita');
            
            $this->form_validation->set_rules('nama_cita_cita','Cita Cita','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('keterangan','Keterangan','trim|required|max_length[50]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_cita_cita);
            }
            else
            {
                $nama_cita_cita = $this->input->post('nama_cita_cita');
                $keterangan = $this->input->post('keterangan');
                $id_aktif = $this->input->post('status');
                
                $citaInfo = array( 'nama_cita_cita'=>$nama_cita_cita, 'keterangan'=> $keterangan, 'id_aktif'=> $id_aktif);

                $result = $this->citacita_model->EditCita($citaInfo, $id_cita_cita);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-citacita');
            }
        }
    }


    /**
     * This function is used to delete the Cita Cita using id_cita_cita
     * @return boolean $result : TRUE / FALSE
     */
    function deleteCitacita()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_cita_cita = $this->input->post('id_cita_cita');
            $citaInfo = array('isDeleted'=>1);
            
            $result = $this->citacita_model->deleteCitacita($id_cita_cita, $citaInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}