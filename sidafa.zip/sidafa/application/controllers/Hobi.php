<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Hobi (HobiController)
 * Prodile Class to control all Hobi related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class Hobi extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('hobi_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the hobi
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Hobi';
        
        $this->loadViews("Hobi/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the hobi list
     */
    function HobiList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('hobi_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->hobi_model->HobiListCount($searchText);

			$returns = $this->paginationCompress ( "list-hobi/", $count, 10 );
            
            $data['hobiRecords'] = $this->hobi_model->HobiList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : Hobi';
            
            $this->loadViews("Hobi/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('hobi_model');
            $data['status'] = $this->hobi_model->getKeaktifan();
            $data['roles'] = $this->hobi_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("Hobi/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new hobi
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('nama_hobi','Hobi','trim|required|max_length[20]|xss_clean');
            $this->form_validation->set_rules('ket_hobi','Keterangan','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $nama_hobi = $this->input->post('nama_hobi');
                $ket_hobi = $this->input->post('ket_hobi');
                $id_aktif = $this->input->post('status');
                
                $hobiInfo = array('nama_hobi'=>$nama_hobi, 'ket_hobi'=>$ket_hobi, 'id_aktif'=>$id_aktif);
                
                $this->load->model('hobi_model');
                $result = $this->hobi_model->AddNew($hobiInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-hobi');
            }
        }
    }

    /**
     * This function is used load hobi edit information
     * @param number $id_hobi : Optional : This is hobi id
     */
    function Edit($id_hobi = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            $data['hobiInfo'] = $this->hobi_model->GetHobiInfo($id_hobi);
            $data['status'] = $this->hobi_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("Hobi/edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the hobi information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_hobi = $this->input->post('id_hobi');
            
            $this->form_validation->set_rules('nama_hobi','Hobi','trim|required|max_length[20]|xss_clean');
            $this->form_validation->set_rules('ket_hobi','Keterangan','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_hobi);
            }
            else
            {
                $nama_hobi = $this->input->post('nama_hobi');
                $ket_hobi = $this->input->post('ket_hobi');
                $id_aktif = $this->input->post('status');
                
                $hobiInfo = array( 'nama_hobi'=>$nama_hobi, 'ket_hobi'=> $ket_hobi, 'id_aktif'=> $id_aktif);

                $result = $this->hobi_model->EditHobi($hobiInfo, $id_hobi);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-hobi');
            }
        }
    }


    /**
     * This function is used to delete the hobi using id_hobi
     * @return boolean $result : TRUE / FALSE
     */
    function deleteHobi()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_hobi = $this->input->post('id_hobi');
            $hobiInfo = array('isDeleted'=>1);
            
            $result = $this->hobi_model->deleteHobi($id_hobi, $hobiInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        } 
    }
}