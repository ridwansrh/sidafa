<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Transportasi (TransportasiController)
 * Prodile Class to control all Transportasi related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class Transportasi extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('transportasi_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the Transportasi
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Transportasi';
        
        $this->loadViews("Transportasi/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the Transportasi list
     */
    function TransportasiList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('transportasi_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->transportasi_model->TransportasiListCount($searchText);

			$returns = $this->paginationCompress ( "TransportasiList/", $count, 10 );
            
            $data['transportasiRecords'] = $this->transportasi_model->TransportasiList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : Transportasi';
            
            $this->loadViews("Transportasi/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('transportasi_model');
            $data['status'] = $this->transportasi_model->getKeaktifan();
            $data['roles'] = $this->transportasi_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("Transportasi/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new Transportasi
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('transportasi','Transportasi','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $transportasi = $this->input->post('transportasi');
                $id_aktif = $this->input->post('status');
                
                $transportasiInfo = array('transportasi'=>$transportasi, 'id_aktif'=>$id_aktif);
                
                $this->load->model('transportasi_model');
                $result = $this->transportasi_model->AddNew($transportasiInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-transportasi');
            }
        }
    }

    /**
     * This function is used load Transportasi edit information
     * @param number $id_transportasi : Optional : This is Transportasi id
     */
    function Edit($id_transportasi = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            $data['transportasiInfo'] = $this->transportasi_model->GetTransportasiInfo($id_transportasi);
            $data['status'] = $this->transportasi_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("Transportasi/Edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the Transportasi information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_transportasi = $this->input->post('id_transportasi');
            
            $this->form_validation->set_rules('transportasi','Transportasi','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_transportasi);
            }
            else
            {
                $transportasi = $this->input->post('transportasi');
                $id_aktif = $this->input->post('status');
                
                $transportasiInfo = array( 'transportasi'=>$transportasi, 'id_aktif'=> $id_aktif);

                $result = $this->transportasi_model->EditTransportasi($transportasiInfo, $id_transportasi);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-transportasi');
            }
        }
    }


    /**
     * This function is used to delete the Transportasi using id_transportasi
     * @return boolean $result : TRUE / FALSE
     */
    function deleteTransportasi()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_transportasi = $this->input->post('id_transportasi');
            $transportasiInfo = array('isDeleted'=>1);
            
            $result = $this->transportasi_model->deleteTransportasi($id_transportasi, $transportasiInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}