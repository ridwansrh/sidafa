<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Jurusan (JurusanController)
 * Prodile Class to control all Jurusan related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class Jurusan extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('jurusan_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the Jurusan
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Jurusan';
        
        $this->loadViews("Jurusan/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the jurusan list
     */
    function JrsList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('jurusan_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->jurusan_model->JrsListCount($searchText);

			$returns = $this->paginationCompress ( "JrsList/", $count, 10 );
            
            $data['jurusanRecords'] = $this->jurusan_model->JrsList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : Jurusan';
            
            $this->loadViews("Jurusan/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('jurusan_model');
            $data['status'] = $this->jurusan_model->getKeaktifan();
            $data['roles'] = $this->jurusan_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("Jurusan/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new Jurusan
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('kode_jurusan','Kode Jurusan','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('nama_jurusan','Nama Jurusan','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|max_length[20]xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $kode_jurusan = $this->input->post('kode_jurusan');
                $nama_jurusan = $this->input->post('nama_jurusan');
                $id_aktif = $this->input->post('status');
                
                $jurusanInfo = array('kode_jurusan'=>$kode_jurusan, 'nama_jurusan'=>$nama_jurusan, 'id_aktif'=>$id_aktif);
                
                $this->load->model('jurusan_model');
                $result = $this->jurusan_model->AddNew($jurusanInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-jurusan');
            }
        }
    }

    /**
     * This function is used load Jurusan edit information
     * @param number $id_jurusan : Optional : This is Jurusan id
     */
    function Edit($id_jurusan = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {
            
            $data['jurusanInfo'] = $this->jurusan_model->GetJurusanInfo($id_jurusan);
            $data['status'] = $this->jurusan_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("Jurusan/Edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the Jurusan information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_jurusan = $this->input->post('id_jurusan');
            
            $this->form_validation->set_rules('kode_jurusan','Kode Jurusan','trim|required|max_length[12]|xss_clean');
            $this->form_validation->set_rules('nama_jurusan','Nama Jurusan','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_jurusan);
            }
            else
            {
                $kode_jurusan = $this->input->post('kode_jurusan');
                $nama_jurusan = $this->input->post('nama_jurusan');
                $id_aktif = $this->input->post('status');
                
                $jurusanInfo = array( 'kode_jurusan'=>$kode_jurusan, 'nama_jurusan'=> $nama_jurusan, 'id_aktif'=> $id_aktif);

                $result = $this->jurusan_model->EditJurusan($jurusanInfo, $id_jurusan);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-jurusan');
            }
        }
    }


    /**
     * This function is used to delete the Jurusan using id_jurusan
     * @return boolean $result : TRUE / FALSE
     */
    function deleteJurusan()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_jurusan = $this->input->post('id_jurusan');
            $jurusanInfo = array('isDeleted'=>1);
            
            $result = $this->jurusan_model->deleteJurusan($id_jurusan, $jurusanInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}