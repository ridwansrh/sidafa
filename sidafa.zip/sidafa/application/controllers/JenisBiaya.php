<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : JenisBiaya (JenisBiayaController)
 * Prodile Class to control all JenisBiaya related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class JenisBiaya extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('jenisbiaya_model');
        $this->load->model('user_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the JenisBiaya
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Jenis Biaya';
        
        $this->loadViews("JenisBiaya/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the JenisBiaya list
     */
    function JenisBiayaList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('jenisbiaya_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->jenisbiaya_model->JenisBiayaListCount($searchText);

			$returns = $this->paginationCompress ( "list-jenisbiaya/", $count, 10 );
            
            $data['JenisBiayaRecords'] = $this->jenisbiaya_model->JenisBiayaList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : Jenis Biaya';
            
            $this->loadViews("JenisBiaya/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function AddNew()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('jenisbiaya_model');
            $data['status'] = $this->jenisbiaya_model->getKeaktifan();
            $data['tapel'] = $this->jenisbiaya_model->getTapel();
            $data['kelas'] = $this->jenisbiaya_model->getKelas();
            $data['roles'] = $this->jenisbiaya_model->getUserRoles();
            
            $this->global['pageTitle'] = 'SIMDAFA : Add New Data';

            $this->loadViews("JenisBiaya/AddNew", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to add new JenisBiaya
     */
    function AddData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('kelas','Kelas','trim|required|numeric');
            $this->form_validation->set_rules('jenis_biaya','Jenis Biaya','trim|required|max_length[50]|xss_clean');
            $this->form_validation->set_rules('harga','Nominal','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('tapel','Tahun Pelajaran','trim|required|numeric');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->AddNew();
            }
            else
            {
                $id_kelas = $this->input->post('kelas');
                $jenis_biaya = $this->input->post('jenis_biaya');
                $harga = $this->input->post('harga');
                $id_tahun_pelajaran = $this->input->post('tapel');
                $id_aktif = $this->input->post('status');
                
                $jenisbiayaInfo = array('id_kelas'=>$id_kelas,'jenis_biaya'=>$jenis_biaya, 'harga'=>$harga, 'id_tahun_pelajaran'=>$id_tahun_pelajaran, 'id_aktif'=>$id_aktif);
                
                $this->load->model('jenisbiaya_model');
                $result = $this->jenisbiaya_model->AddNew($jenisbiayaInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New Data created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data creation failed');
                }
                
                redirect('list-jenisbiaya');
            }
        }
    }

    /**
     * This function is used load JenisBiaya edit information
     * @param number $id_biaya : Optional : This is JenisBiaya id
     */
    function Edit($id_biaya = NULL)
    {
        if($this->isLoggedIn() == TRUE )
        {
            $this->loadThis();
        }
        else
        {     
            $data['jenisbiayaInfo'] = $this->jenisbiaya_model->GetjenisbiayaInfo($id_biaya);
            $data['tapel'] = $this->jenisbiaya_model->getTapel();
            $data['kelas'] = $this->jenisbiaya_model->getKelas();
            $data['status'] = $this->jenisbiaya_model->getKeaktifan();
            
            $this->global['pageTitle'] = 'SIMDAFA : Edit Data';
            
            $this->loadViews("JenisBiaya/Edit", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the JenisBiaya information
     */
    function EditData()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$this->load->library('form_validation');

        	$id_biaya = $this->input->post('id_biaya');
            
            $this->form_validation->set_rules('kelas','Kelas','trim|required|numeric');
            $this->form_validation->set_rules('jenis_biaya','Jenis Biaya','trim|required|max_length[50]|xss_clean');
            $this->form_validation->set_rules('harga','Nominal','trim|required|max_length[20]xss_clean');
            $this->form_validation->set_rules('tapel','Tahun Pelajaran','trim|required|numeric');
            $this->form_validation->set_rules('status','Aktif/Non Aktif','trim|required|numeric');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->edit($id_biaya);
            }
            else
            {
                $id_kelas = $this->input->post('kelas');
                $jenis_biaya = $this->input->post('jenis_biaya');
                $harga = $this->input->post('harga');
                $id_tahun_pelajaran = $this->input->post('tapel');
                $id_aktif = $this->input->post('status');
                
                $jenisbiayaInfo = array( 'id_kelas'=>$id_kelas,'jenis_biaya'=>$jenis_biaya, 'harga'=> $harga, 'id_tahun_pelajaran'=>$id_tahun_pelajaran, 'id_aktif'=> $id_aktif);

                $result = $this->jenisbiaya_model->EditJenisBiaya($jenisbiayaInfo, $id_biaya);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'Data updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'Data updation failed');
                }
                
                redirect('list-jenisbiaya');
            }
        }
    }


    /**
     * This function is used to delete the JenisBiaya using id_biaya
     * @return boolean $result : TRUE / FALSE
     */
    function deleteJenisBiaya()
    {
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_biaya = $this->input->post('id_biaya');
            $jenisbiayaInfo = array('isDeleted'=>1);
            
            $result = $this->jenisbiaya_model->deleteJenisBiaya($id_biaya, $jenisbiayaInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}