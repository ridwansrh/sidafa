<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Pembayaran (PembayaranController)
 * Prodile Class to control all Pembayaran related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class Pembayaran extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('psbsiswa_model');
        $this->load->model('jenisbiaya_model');
        //$this->load->model('Pembayaran_model');
        $this->load->model('user_model');
        $this->load->library('cart');
        $this->load->model(array('pembayaran_model'));
        $this->isLoggedIn();   
    }

    private $_table = "tbl_pembayaran";
    
    /**
     * This function used to load the first screen of the Pembayaran
     */
    public function Index()
    {
        $this->load->library('pagination');
        $this->global['pageTitle'] = 'SIMDAFA : Pembayaran';
        
        $this->loadViews("Pembayaran/Index", $this->global, NULL , NULL);
    }

    /**
     * This function used to load Pembayaran SPP
     */
    function Spp(){
        $this->load->library('pagination');
        $this->global['pageTitle'] = 'SIMDAFA : Pembayaran SPP';
        
        $this->loadViews("Pembayaran/SPP", $this->global, NULL , NULL);
    }

    /**
     * This function used to load Pembayaran BUKU
     */
    function Buku(){
        $this->load->library('pagination');
        $this->global['pageTitle'] = 'SIMDAFA : Pembayaran BUKU';
        
        $this->loadViews("Pembayaran/BUKU", $this->global, NULL , NULL);
    }

    function ShowTagihan(){
        $siswa          = $_GET['siswa'];
        $kelas          = $_GET['kelas'];
        $biaya          = $_GET['biaya'];
        $rombel         = $_GET['rombel'];

        echo "<table class='table table-striped table-bordered table-hover table-full-width dataTable'>
                <thead>
                    <tr>
                      <th class='text-center' width='5'>NO</th>
                      <th class='text-center'>JENIS BIAYA</th>
                      <th class='text-center'>NOMINAL</th>
                      <th class='text-center'>DIBAYAR</th>
                      <th class='text-center'>KURANG</th>
                      <th class='text-center'>KETERANGAN</th>
                      <th class='text-center' width='60'>ACTION</th>
                    </tr>
                </thead>";
        $sql = "SELECT  tb.jenis_biaya, tb.harga, thb.jumlah_bayar,thb.status, thb.id_pembayaran, thb.id_tahun_pelajaran, thb.id_siswa, thb.id_biaya, thb.keterangan
                FROM tbl_pembayaran as thb, tbl_biaya as tb, tbl_siswa as ts
                WHERE thb.id_siswa=ts.id_siswa and thb.id_biaya=tb.id_biaya and thb.id_siswa=$siswa and thb.isDeleted=0 and thb.id_tahun_pelajaran=".  get_tahun_pelajaran_aktif('id_tahun_pelajaran');
        $tagihan = $this->db->query($sql)->result();

        $no=1;

        foreach ($tagihan as $row){
            $sisa  = $row->harga-$row->jumlah_bayar;
            echo"<tr>
                    <td class='text-center'>$no</td>
                    <td class='text-center'>$row->jenis_biaya</td>
                    <td class='text-center'>".'Rp. ' .number_format($row->harga)."</td>
                    <td class='text-center'>".'Rp. ' .number_format($row->jumlah_bayar)."</td>
                    <td class='text-center'>".'Rp. ' .number_format($sisa)."</td>
                    <td class='text-center'>$row->keterangan</td>
                    <td class='text-center'>
                    <!--button class='btn btn-flat btn-sm btn-success item_update' data=".$row->id_pembayaran." data-toggle='modal' data-target='#edit-data'> BAYAR <i class='fa fa-paper-plane item_update'></i-->

                    ".anchor('pembayaran/cetak/'.$row->id_pembayaran,'<i class="btn btn-flat btn-sm btn-success fa fa-print"></i>')."

                    ".anchor('pembayaran/deletePembayaran/'.$row->id_pembayaran,'<i class="btn btn-flat btn-sm btn-danger fa fa-trash deletePembayaran"></i>')."
                    </td>
                   
                </tr>";
            $no++;
        }

        echo"</table>";
    }

    /**
     * This function used to load Tagihan SPP
     */
    function ShowTagihanSPP(){
        $siswa          = $_GET['siswa'];
        $kelas          = $_GET['kelas'];
        $biaya          = $_GET['biaya'];
        $rombel         = $_GET['rombel'];
        $data           = $this->pembayaran_model->get_sum();

        echo "<?php echo form_open('pembayaran/cetak_jadwal');?>
        <table class='table table-striped table-bordered table-hover table-full-width dataTable'>
                <thead>
                    <tr>
                      <th class='text-center' width='5'>NO</th>
                      <th class='text-center'>JENIS BIAYA</th>
                      <th class='text-center'>NOMINAL</th>
                      <th class='text-center'>DIBAYAR</th>
                      <th class='text-center'>TGL BAYAR</th>
                      <th class='text-center' width='60'>ACTION</th>
                    </tr>
                </thead>";
        $sql = "SELECT  tb.jenis_biaya, tb.harga, thb.jumlah_bayar,thb.status, thb.id_pembayaran, thb.id_tahun_pelajaran, thb.id_siswa, thb.id_biaya, thb.keterangan, thb.UpdatedDate
                FROM tbl_pembayaran as thb, tbl_biaya as tb, tbl_siswa as ts
                WHERE thb.id_siswa=ts.id_siswa and thb.id_biaya=tb.id_biaya and thb.id_siswa=$siswa and thb.isDeleted=0 and tb.id_jenis_biaya=2 and thb.id_tahun_pelajaran=".  get_tahun_pelajaran_aktif('id_tahun_pelajaran');
        $tagihan = $this->db->query($sql)->result();

        $no=1;

        foreach ($tagihan as $row){
            $sisa  = $row->harga-$row->jumlah_bayar;
            echo"<tr>
                    <td class='text-center'>$no</td>
                    <td class='text-center'>$row->jenis_biaya</td>
                    <td class='text-center'>".'Rp. ' .number_format($row->harga)."</td>
                    <td class='text-center'>".'Rp. ' .number_format($row->jumlah_bayar)."</td>
                    <td class='text-center'>$row->UpdatedDate</td>
                    <td class='text-center'>
                    <button class='btn btn-flat btn-sm btn-danger deletePembayaran' data-id_pembayaran=".$row->id_pembayaran." href='#'> <i class='fa fa-trash'></i></button>
                    ".anchor('pembayaran/cetak/'.$row->id_pembayaran,'<i class="btn btn-flat btn-sm btn-success fa fa-print"></i>')."
                    </td>
                   
                </tr>";
            $no++;
        }

         echo"<tr></tr><tr>
                    <td></td>
                    <td class='text-center'><strong>TOTAL BAYAR</strong></td>
                    <td class='text-center'>".number_format($data)."</td>
                    <td class='text-center'></td>
                    <td class='text-center'><strong>SISA</strong></td>
                    <td class='text-center'>SISA</td>
            </tr>";

        echo"</form></table>";
    }

    function cetak_jadwal(){

    }

    /**
     * This function used to load Tagihan Buku
     */
    function ShowTagihanBUKU(){

        $siswa          = $_GET['siswa'];
        $kelas          = $_GET['kelas'];
        $biaya          = $_GET['biaya'];
        $rombel         = $_GET['rombel'];
        $data           = $this->pembayaran_model->get_sum();
        echo "<table class='table table-striped table-bordered table-hover table-full-width dataTable'>
                <thead>
                    <tr>
                      <th class='text-center' width='5'>NO</th>
                      <th class='text-center'>JENIS BIAYA</th>
                      <th class='text-center'>NOMINAL</th>
                      <th class='text-center'>DIBAYAR</th>
                      <th class='text-center'>TGL BAYAR</th>
                      <th class='text-center' width='60'>ACTION</th>
                    </tr>
                </thead>";
        $sql = "SELECT  tb.jenis_biaya, tb.harga, thb.jumlah_bayar,thb.status, thb.id_pembayaran, thb.id_tahun_pelajaran, thb.id_siswa, thb.id_biaya, thb.keterangan, thb.UpdatedDate
                FROM tbl_pembayaran as thb, tbl_biaya as tb, tbl_siswa as ts
                WHERE thb.id_siswa=ts.id_siswa and thb.id_biaya=tb.id_biaya and thb.id_siswa=$siswa and thb.isDeleted=0 and tb.id_jenis_biaya=3 and thb.id_tahun_pelajaran=".  get_tahun_pelajaran_aktif('id_tahun_pelajaran');
        $tagihan = $this->db->query($sql)->result();

       
        $no=1;
        //$total = sum($tagihan);
        foreach ($tagihan as $item){
        
        $sisa  = $item->harga-$item->jumlah_bayar;
        $kekurangan  = $item->harga-$data;

            echo"<tr>
                    <td class='text-center'>$no</td>
                    <td class='text-center'>$item->jenis_biaya</td>
                    <td class='text-center'>".'Rp. ' .number_format($item->harga)."</td>
                    <td class='text-center'>".'Rp. ' .number_format($item->jumlah_bayar)."</td>
                    <td class='text-center'>$item->UpdatedDate</td>
                    <td class='text-center'>
                    <!--button class='btn btn-flat btn-sm btn-success item_update' data-id_pembayaran=".$item->id_pembayaran," data-toggle='modal' data-target='#edit-data'> BAYAR <i class='fa fa-paper-plane item_update'></i-->

                    ".anchor('pembayaran/cetak/'.$item->id_pembayaran,'<i class="btn btn-flat btn-sm btn-success fa fa-print"></i>')."

                    ".anchor('pembayaran/delete/'.$item->id_pembayaran,'<i class="btn btn-flat btn-sm btn-danger fa fa-trash deletePembayaran"></i>')."
                    </td>
                </tr>";
            $no++;
        }


        //$jml = "SELECT * FROM 'tbl_biaya' where id_biaya=$biaya";
        //$tot = "SELECT sum(jumlah_bayar) as total FROM 'tbl_pembayaran' 
        //where id_siswa=$siswa AND id_kelas=$kelas AND id_rombel=$rombel ";
        //$total = $jml-$tot;

        echo"<tr></tr><tr>
                    <td></td>
                    <td class='text-center'><strong>TOTAL BAYAR</strong></td>
                    <td class='text-center'>".'Rp. ' .number_format($item->harga)."</td>
                    <td class='text-center'>".'Rp. ' .number_format($data)."</td>
                    <td class='text-center'><strong>SISA</strong></td>
                    <td class='text-center'>".'Rp. ' .number_format($kekurangan)."</td>
            </tr>";
        /*echo "<tr>
        <td colspan='2'> </td>
        <td class='right'><strong>Total</strong></td>
        <td class='right'>$<?php echo $this->cart->format_number($this->cart->total()); ?></td>
            </tr>";*/
        echo"</table>";
    }

    /**
     * This function used to Add Tagihan manually
     */
    function AddTagihan(){
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        $id_kelas           = $this->input->post('kelas');
        $id_rombel          = $this->input->post('rombel');
        $id_siswa           = $this->input->post('siswa');
        $id_biaya           = $this->input->post('biaya');
        $id_tahun_pelajaran = $this->input->post('tapel');
        $jumlah_bayar       = $this->input->post('jumlah_bayar');
        $keterangan        = $this->input->post('keterangan');
        
        date_default_timezone_set('Asia/Jakarta');                                           
        $data = array(
            'id_kelas'=>$id_kelas, 
            'id_rombel'=>$id_rombel,
            'id_siswa'=>$id_siswa,  
            'id_biaya'=>$id_biaya, 
            'id_tahun_pelajaran'=>$id_tahun_pelajaran, 
            'jumlah_bayar'=>$jumlah_bayar, 
            'keterangan'=>$keterangan,
            'CreatedBy'=>$this->vendorId, 
            'CreatedDate'=>date('Y-m-d H:i:s'),
            'UpdatedBy'=>$this->vendorId, 
            'UpdatedDate'=>date('Y-m-d H:i:s')
            );
        $this->db->insert('tbl_pembayaran',$data);
        //$result = $this->db->insert('tbl_pembayaran',$data);

            //if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            //else { echo(json_encode(array('status'=>FALSE))); }
        redirect('Pembayaran');
        }        
        //$this->load->model('pembayaran_model');
        //$result = $this->pembayaran_model->AddNew($baiyaInfo);
                
        //if($result > 0)
        //{
        //    $this->session->set_flashdata('success', 'New Data created successfully');
        //}
        //else
        //{
        //    $this->session->set_flashdata('error', 'Data creation failed');
        //}
    }

    /**
     * This function used to Add Pembayaran SPP manually
     */
    function AddBayarSPP(){
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        $id_kelas           = $this->input->post('kelas');
        $id_rombel          = $this->input->post('rombel');
        $id_siswa           = $this->input->post('siswa');
        $id_biaya           = $this->input->post('biaya');
        $id_tahun_pelajaran = $this->input->post('tapel');
        $jumlah_bayar       = $this->input->post('jumlah_bayar');
        $keterangan        = $this->input->post('keterangan');
        
        date_default_timezone_set('Asia/Jakarta');                                           
        $data = array(
            'id_kelas'=>$id_kelas, 
            'id_rombel'=>$id_rombel,
            'id_siswa'=>$id_siswa,  
            'id_biaya'=>$id_biaya, 
            'id_tahun_pelajaran'=>$id_tahun_pelajaran, 
            'jumlah_bayar'=>$jumlah_bayar, 
            'keterangan'=>$keterangan,
            'CreatedBy'=>$this->vendorId, 
            'CreatedDate'=>date('Y-m-d H:i:s'),
            'UpdatedBy'=>$this->vendorId, 
            'UpdatedDate'=>date('Y-m-d H:i:s')
            );
        $this->db->insert('tbl_pembayaran',$data);

        $this->session->set_flashdata('success', 'Berhasil disimpan');
        //return $this->db->insert($this->_table, $this);
        //$result = $this->db->insert('tbl_pembayaran',$data);

            //if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            //else { echo(json_encode(array('status'=>FALSE))); }
        //redirect('Pembayaran/spp');
        }        
        //$this->load->model('pembayaran_model');
        //$result = $this->pembayaran_model->AddNew($baiyaInfo);
                
        //if($result > 0)
        //{
        //    $this->session->set_flashdata('success', 'New Data created successfully');
        //}
        //else
        //{
        //    $this->session->set_flashdata('error', 'Data creation failed');
        //}
    }

    /**
     * This function used to Add Pembayaran BUKU manually
     */
    function AddBayarBUKU(){
        if($this->isLoggedIn() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
        $id_kelas           = $this->input->post('kelas');
        $id_rombel          = $this->input->post('rombel');
        $id_siswa           = $this->input->post('siswa');
        $id_biaya           = $this->input->post('biaya');
        $id_tahun_pelajaran = $this->input->post('tapel');
        $jumlah_bayar       = $this->input->post('jumlah_bayar');
        $keterangan        = $this->input->post('keterangan');
        
        date_default_timezone_set('Asia/Jakarta');                                           
        $data = array(
            'id_kelas'=>$id_kelas, 
            'id_rombel'=>$id_rombel,
            'id_siswa'=>$id_siswa,  
            'id_biaya'=>$id_biaya, 
            'id_tahun_pelajaran'=>$id_tahun_pelajaran, 
            'jumlah_bayar'=>$jumlah_bayar, 
            'keterangan'=>$keterangan,
            'CreatedBy'=>$this->vendorId, 
            'CreatedDate'=>date('Y-m-d H:i:s'),
            'UpdatedBy'=>$this->vendorId, 
            'UpdatedDate'=>date('Y-m-d H:i:s')
            );
        //$this->db->insert('tbl_pembayaran',$data);
        $result = $this->pembayaran_model->AddPembayaran($data);
        //return $this->db->affected_rows();
        if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
        else { echo(json_encode(array('status'=>FALSE))); } 
        redirect('Pembayaran/buku');
        }        
        //$this->load->model('pembayaran_model');
        //$result = $this->pembayaran_model->AddNew($baiyaInfo);
                
        //if($result > 0)
        //{
        //    $this->session->set_flashdata('success', 'New Data created successfully');
        //}
        //else
        //{
        //    $this->session->set_flashdata('error', 'Data creation failed');
        //}
    }

    function delete(){
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        $id_pembayaran = $this->uri->segment(3);
        if(!empty($id_pembayaran)){
            // proses delete data
            $this->db->where('id_pembayaran',$id_pembayaran);
            $this->db->delete('tbl_pembayaran');
        }
        redirect('pembayaran/buku');
    }
    }

    /**
     * This function is used to delete the hobi using id_pembayaran
     * @return boolean $result : TRUE / FALSE
     */
    function deletePembayaran()
    {
        //$id_pembayaran = $this->uri->segment(3);
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $id_pembayaran = $this->input->post('id_pembayaran');
            $PembayaranInfo = array('isDeleted'=>1);
            
            $result = $this->pembayaran_model->deletePembayaran($id_pembayaran, $PembayaranInfo);
                
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

    /**
     * This function used to Show Rombel by Kelas to add transaksi
     */
    function show_rombel(){
        echo "<select id='rombel' name='rombel' class='form-control select2' role='combobox' onchange='loadSiswa()'>";
        $where  = array ('id_kelas'=>$_GET['kelas']);
        $rombel = $this->db->get_where('tbl_rombel',$where);
        foreach ($rombel->result() as $row){
            echo "<option value='$row->id_rombel'>$row->nama_rombel</option>";
        }
        echo "</select>";
    }

    /**
     * This function used to Show Siswa by Rombel to add transaksi
     */
    function show_siswa(){
        echo "<select id='siswa' name='siswa' class='form-control select2' role='combobox' onchange='loadTagihan()'>";
        $where  = array ('id_rombel'=>$_GET['rombel']);
        $siswa = $this->db->get_where('tbl_siswa',$where); 
        foreach ($siswa->result() as $row){
            echo "<option value='$row->id_siswa'>$row->nama</option>";
        }
        echo "</select>";
    }

    /**
     * This function used to Show Jenis biaya by Rombel to add transaksi
     */
    function load_biaya(){
        echo "<select id='biaya' name='biaya' class='form-control select2' role='combobox'>";
        $where  = array ('id_kelas'=>$_GET['kelas']);
        $biaya = $this->db->get_where('tbl_biaya',$where);
        foreach ($biaya->result() as $row){
            echo "<option value='$row->id_biaya'>$row->jenis_biaya - ".'Rp. '.number_format($row->harga)."</option>";
        }
        echo "</select>";
    }

    /**
     * This function used to Show Jenis biaya (SPP) by id_jenis_biaya to add transaksi
     */
    function load_biaya_spp(){
        echo "<select id='biaya' name='biaya' class='form-control select2' role='combobox'>";
        $where  = array ('id_kelas'=>$_GET['kelas']);
        $this->db->where('id_jenis_biaya', 2);
        $biaya = $this->db->get_where('tbl_biaya',$where);
        foreach ($biaya->result() as $row){
            echo "<option value='$row->id_biaya'>$row->jenis_biaya - ".'Rp. '.number_format($row->harga)."</option>";
        }
        echo "</select>";
    }

    /**
     * This function used to Show Jenis biaya (BUKU) by id_jenis_biaya to add transaksi
     */
    function load_biaya_buku(){
        echo "<select id='biaya' name='biaya' class='form-control select2' role='combobox'>";
        $where  = array ('id_kelas'=>$_GET['kelas']);
        $this->db->where('id_jenis_biaya', 3);
        $biaya = $this->db->get_where('tbl_biaya',$where);
        foreach ($biaya->result() as $row){
            echo "<option value='$row->id_biaya'>$row->jenis_biaya - ".'Rp. '.number_format($row->harga)."</option>";
        }
        echo "</select>";
    }

    /**
     * This function is used to Print the History Pembayaran Siswa 
     * @return boolean $result : TRUE / FALSE
     */
    function Print()
    {
        $this->load->library('CFPDF');
        //$this->load->library('fpdf');
        $pdf = new FPDF();
        
        /*
        * P  = Paper Orientation
        * mm = Size Unit
        * F4 = Paper Size
        */
        $pdf = new FPDF('P','mm','A4');
        $pdf->AddPage();
    }

     /**
     * This function is used to Print the Pembayaran Siswa using id_pembayaran
     * @return boolean $result : TRUE / FALSE
     */
    function Cetak($id_pembayaran = NULL)
    {
        $this->load->model('pembayaran_model');
            
        $this->load->library('CFPDF');
        //$this->load->library('fpdf');
        $pdf = new FPDF();
        
        /*
        * P  = Paper Orientation
        * mm = Size Unit
        * F4 = Paper Size
        */
        $pdf = new FPDF('P','mm','A4');
        $pdf->AddPage();
        date_default_timezone_set('Asia/Jakarta');
        /*
         Set Font ('Font Name', 'Style', 'Size')
        */
        //$pdf->Image('application/libraries/logo_line.png',170,17,10,10);
         // mencetak string
        $pdf->SetFont('Arial','',7);
        $pdf->Cell(190,1,'SIDAFA  |  Dicetak pada ',0,1,'R');
        $pdf->Cell(190,5,''.date("d-m-Y H:i:s").' WIB',0,1,'R');
        $pdf->SetFont('Arial','B',12);
        // mencetak string 
        $pdf->Cell(190,5,'KWITANSI PEMBAYARAN',0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,5,'MTs DARUL FALAH SIRAHAN',0,1,'C');
        $pdf->SetFont('Arial','B',12);
        $pdf->Ln();
        

        // Koneksi database
        $GetPembayaranInfo     = $this->pembayaran_model->GetPembayaranInfo($id_pembayaran);
        $id_pembayaran         = '';
        $nama_kelas            = '';
        $nama_rombel           = '';
        $nama                  = '';
        $harga                 = '';
        $jenis_biaya           = '';
        $jumlah_bayar          = '';
        $keterangan            = '';
        $CreatedDate           = '';
        $name                  = '';
        $tahun_pelajaran       = '';

        $no=1;
        if(!empty($GetPembayaranInfo)){
        

        //$this->db->get('tbl_psb_siswa')->result();
        foreach ($GetPembayaranInfo as $byr){
            $id_pembayaran          = $byr->id_pembayaran;
            $nama_kelas             = $byr->nama_kelas;
            $nama_rombel            = $byr->nama_rombel;
            $nama                   = $byr->nama;
            $harga                  = $byr->harga;
            $jenis_biaya            = $byr->jenis_biaya;
            $jumlah_bayar           = $byr->jumlah_bayar;
            $keterangan             = $byr->keterangan;
            $CreatedDate            = $byr->CreatedDate;
            $name                   = $byr->name;
            $tahun_pelajaran        = $byr->tahun_pelajaran;
            $sisa                   = $harga-$jumlah_bayar;
            }
        }
        // Memberikan space kebawah agar tidak terlalu rapat
        
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(30,5,'NAMA SISWA',0,0,'L');
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(100,5,': '.$nama,0,0);
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(30,5,'Tahun Pelajaran',0,0,'L');
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(15,5,': '.$tahun_pelajaran,0,0);
        $pdf->Ln();
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(30,6,'KELAS',0,0);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(40,6,': '.$nama_kelas.'-'.$nama_rombel,0,0);
        $pdf->SetFont('Arial','B',9);
        $pdf->Ln();
        $pdf->Cell(8,7,'NO',1,0,'C');
        $pdf->Cell(60,7,'JENIS BIAYA',1,0,'C');
        $pdf->Cell(30,7,'TOTAL BEBAN',1,0,'C');
        $pdf->Cell(30,7,'TOTAL BAYAR',1,0,'C');
        $pdf->Cell(30,7,'SISA BEBAN',1,0,'C');
        $pdf->Cell(32,7,'TANGGAL BAYAR',1,0,'C');
        $pdf->SetFont('Arial','',9);
        $pdf->Ln();
        $pdf->Cell(8,7,$no,1,0,'C');
        $pdf->Cell(60,7,$jenis_biaya,1,0,'C');
        $pdf->Cell(30,7,'Rp. '.number_format($harga),1,0,'C');
        $pdf->Cell(30,7,'Rp. '.number_format($jumlah_bayar),1,0,'C');
        $pdf->Cell(30,7,'Rp. '.number_format($sisa),1,0,'C');
        $pdf->SetFont('Arial','',8);
        $pdf->Cell(32,7,$CreatedDate,1,0,'C');
        $pdf->Ln();
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(60,10,'',0,0);
        $pdf->Cell(70,10,'',0,0);
        $pdf->Cell(30,10,'PETUGAS',0,0);
        $pdf->Ln();
        $pdf->Cell(130,7,'',0,0);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(30,10,$name,0,0);
        $pdf->Ln();
        $no++;
        $noo=1;
        $pdf->SetFont('Arial','',9);
        $pdf->Cell(190,7,'------------------------------------------------------------------------------ Potong  Disini ------------------------------------------------------------------------------',0,0);
        $pdf->Ln();
        $pdf->SetFont('Arial','B',12);
        $pdf->Cell(190,5,'SLIP PEMBAYARAN',0,1,'C');
        $pdf->SetFont('Arial','',7);
        $pdf->Cell(190,4,'SIDAFA  |  Dicetak pada : '.date("d-m-Y H:i:s").' WIB',0,1,'C');
        $pdf->Ln();
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(30,5,'NAMA SISWA',0,0,'L');
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(80,5,': '.$nama,0,0);
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(30,5,'Tahun Pelajaran',0,0,'L');
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(15,5,': '.$tahun_pelajaran,0,0);
        $pdf->Ln();
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(30,6,'KELAS',0,0);
        $pdf->SetFont('Arial','B',10);
        $pdf->Cell(80,6,': '.$nama_kelas.'-'.$nama_rombel,0,0);
        $pdf->SetFont('Arial','',10);
        $pdf->Cell(30,6,'PETUGAS',0,0);
        $pdf->SetFont('Arial','B',9);
        $pdf->Cell(30,6,': '.$name,0,0);
        $pdf->SetFont('Arial','B',9);
        $pdf->Ln();
        $pdf->Cell(8,7,'NO',1,0,'C');
        $pdf->Cell(60,7,'JENIS BIAYA',1,0,'C');
        $pdf->Cell(30,7,'TOTAL BEBAN',1,0,'C');
        $pdf->Cell(30,7,'TOTAL BAYAR',1,0,'C');
        $pdf->Cell(30,7,'SISA BEBAN',1,0,'C');
        $pdf->Cell(32,7,'TANGGAL BAYAR',1,0,'C');
        $pdf->SetFont('Arial','',9);
        $pdf->Ln();
        $pdf->Cell(8,7,$noo,1,0,'C');
        $pdf->Cell(60,7,$jenis_biaya,1,0,'C');
        $pdf->Cell(30,7,'Rp. '.number_format($harga),1,0,'C');
        $pdf->Cell(30,7,'Rp. '.number_format($jumlah_bayar),1,0,'C');
        $pdf->Cell(30,7,'Rp. '.number_format($sisa),1,0,'C');
        $pdf->SetFont('Arial','',8);
        $pdf->Cell(32,7,$CreatedDate,1,0,'C');
        $no++;
        $pdf->Output();
    }

}