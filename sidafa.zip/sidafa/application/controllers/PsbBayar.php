<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : PsbBayar (PsbBayarController)
 * Prodile Class to control all PsbBayar related operations.
 * @author : abduelmu
 * @version : 1.1
 * @since : 30 Maret 2020
 */
class PsbBayar extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('psbsiswa_model');
        $this->load->model('psbbiaya_model');
        $this->load->model('psbbayar_model');
        $this->load->model('user_model');
        $this->load->library('cart');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the PsbBayar
     */
    public function Index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : Pembayaran PSB';
        
        $this->loadViews("PsbBayar/Index", $this->global, NULL , NULL);
    }

    /**
     * This function is used to load the hobi list
     */
    function PsbBayarList()
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->model('psbbayar_model');
        
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->psbbayar_model->PsbBayarListCount($searchText);

			$returns = $this->paginationCompress ( "list-bayar-psb/", $count, 10 );
            
            $data['PsbBayarRecords'] = $this->psbbayar_model->PsbBayarList($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'SIMDAFA : PsbBayar';
            
            $this->loadViews("PsbBayar/Index", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the List Biaya PSB
     */
    function ViewBayar($id_pendaftaran = NULL, $id_kelas = NULL)
    {
        if($this->isLoggedIn() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $data['status'] = $this->psbsiswa_model->getKeaktifan();
            $data['roles'] = $this->psbsiswa_model->getUserRoles();
            $data['psbsiswaInfo'] = $this->psbbayar_model->GetPsbSiswaInfo($id_pendaftaran);
            $this->load->model('psbbiaya_model');
            
            $this->load->library('pagination');
            
            $count = $this->psbbayar_model->PsbBiayaListBayarCount();

			$returns = $this->paginationCompress ( "view-bayar/", $count, 10 );
            
            $data['PsbBayarRecords'] = $this->psbbayar_model->PsbBiayaListBayar($returns["page"], $returns["segment"]);
            
            
            $this->global['pageTitle'] = 'SIMDAFA : Pembayaran Siswa Baru';

            $this->loadViews("PsbBayar/ViewPayment", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to AddBeban Bayar Siswa  PSB
     */
    function AddBeban(){

    }


    /**
     * This function is used to load Data PSB Bayar
     */
    function dataPSBBayar($id_pendaftaran = NULL){

    	$siswa = $_GET['psbsiswaInfo'];
    	echo "<table class='table table-responsive table-bordered'>
	                            	<thead>
				                    <tr>
				                      <th class='text-center' width='5'>NO</th>
				                      <th class='text-center'>JENIS BIAYA</th>
				                      <th class='text-center'>JUMLAH</th>
				                      <th class='text-center'>STATUS</th>
				                      <th></th>
				                    </tr>
				                    </thead>";
		$sql = "SELECT pb.jenis_biaya, pb.harga
				FROM tbl_psb_harus_bayar as phb, tbl_psb_siswa as ps, tbl_psb_biaya as pb
				WHERE phb.id_pendaftaran=ps.id_pendaftaran and phb.id_biaya_psb=pb.id_biaya_psb and phb.id_pendaftaran=$siswa";

		$harusbayar = $this->db->query($sql)->result();
		$no=1;
		foreach ($harusbayar as $row) {
			echo "<tr><td>$no</td><td>$row->jenis_biaya</td><td>".'Rp.' .number_format($row->harga)."</td><td class='text-center'>BELUM BAYAR</td><td width='5'><a class='btn btn-flat btn-sm btn-danger'><i class='fa fa-trash'></i></a></td></tr>";
			$no++;
		}

		echo "</table>";
    }

    

}