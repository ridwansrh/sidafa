<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : PTK (PTK Controller)
 * PTK Class to control all PTK related operations.
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Ptk extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('ptk_model');
        $this->isLoggedIn();   
    }
    
    /**
     * This function ptk to load the first screen of the PTK
     */
    public function index()
    {
        $this->global['pageTitle'] = 'SIMDAFA : PTK';
        
        $this->loadViews("PTK", $this->global, NULL , NULL);
    }
    
    /**
     * This function is ptk to load the user list
     */
	function ptkSListing()
	    {
	        if($this->isAdmin() == TRUE)
	        {
	            $this->loadThis();
	        }
	        else
	        {
	            $this->load->model('ptk_model');
	        
	            $searchText = $this->input->post('searchText');
	            $data['searchText'] = $searchText;
	            
	            $this->load->library('pagination');
	            
	            $count = $this->ptk_model->ptkListingCount($searchText);

				$returns = $this->paginationCompress ( "ptkListing/", $count, 1 );
	            
	            $data['ptkRecords'] = $this->ptk_model->ptkListing($searchText, $returns["page"], $returns["segment"]);
	            
	            $this->global['pageTitle'] = 'SIMDAFA : ptk Listing';
	            
	            $this->loadViews("ptk", $this->global, $data, NULL);
	        }
	    }

	function addPTK()
	    {
	        if($this->isAdmin() == TRUE)
	        {
	            $this->loadThis();
	        }
	        else
	        {
	            $this->load->model('ptk_model');
	        
	            $searchText = $this->input->post('searchText');
	            $data['searchText'] = $searchText;
	            
	            $this->load->library('pagination');
	            
	            $count = $this->ptk_model->ptkListingCount($searchText);

	            $returns = $this->paginationCompress ( "ptkListing/", $count, 5 );
	            
	            $data['ptkRecords'] = $this->ptk_model->ptkListing($searchText, $returns["page"], $returns["segment"]);
	            
	            $this->global['pageTitle'] = 'CodeInsect : ptk Listing';
	            
	            $this->loadViews("ptks", $this->global, $data, NULL);
	        }
	    }
}