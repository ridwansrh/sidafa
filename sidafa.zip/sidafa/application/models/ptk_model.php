<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Ptk_model extends CI_Model
{
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function ptkListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.ptk_ID, BaseTbl.jenis_ptk, BaseTbl.keterangan');
        $this->db->from('tbl_jenis_ptk as BaseTbl');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.jenis_ptk  LIKE '%".$searchText."%'
                            OR  BaseTbl.keterangan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        //$this->db->where('BaseTbl.isDeleted', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the PTK listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function ptkListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.ptk_ID, BaseTbl.jenis_ptk, BaseTbl.keterangan');
        $this->db->from('tbl_jenis_ptk as BaseTbl');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.jenis_ptk  LIKE '%".$searchText."%'
                            OR  BaseTbl.keterangan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        //$this->db->where('BaseTbl.isDeleted', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
}