<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Citacita_model extends CI_Model
{
	/**
     * This function is used to get the Cita Cita listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function CitaListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_cita_cita, BaseTbl.nama_cita_cita, BaseTbl.keterangan, Aktif.keaktifan');
        $this->db->from('tbl_cita_cita as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.nama_cita_cita  LIKE '%".$searchText."%'
                            OR  BaseTbl.keterangan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif =', 1);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the Cita Cita listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function CitaList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_cita_cita, BaseTbl.nama_cita_cita, BaseTbl.keterangan, Aktif.keaktifan');
        $this->db->from('tbl_cita_cita as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.nama_cita_cita  LIKE '%".$searchText."%'
                            OR  BaseTbl.keterangan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new Cita Cita to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($citaInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_cita_cita', $citaInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get Cita Cita information by id
     * @param number $id_cita_cita : This is Cita Cita id
     * @return array $result : This is Cita Cita information
     */
    function GetCitaInfo($id_cita_cita)
    {
        $this->db->select('id_cita_cita, nama_cita_cita, keterangan, id_aktif');
        $this->db->from('tbl_cita_cita');
        $this->db->where('isDeleted', 0);
		$this->db->where('id_aktif !=', 0);
        $this->db->where('id_cita_cita', $id_cita_cita);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the Cita Cita information
     * @param array $citaInfo : This is Cita Citas updated information
     * @param number $id_cita_cita : This is Cita Cita id
     */
    function EditCita($citaInfo, $id_cita_cita)
    {
        $this->db->where('id_cita_cita', $id_cita_cita);
        $this->db->update('tbl_cita_cita', $citaInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the Cita Cita information
     * @param number $id_cita_cita : This is Cita Cita id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteCita($id_cita_cita, $citaInfo)
    {
        $this->db->where('id_cita_cita', $id_cita_cita);
        $this->db->update('tbl_cita_cita', $citaInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the Cita Cita status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the Cita Cita roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}