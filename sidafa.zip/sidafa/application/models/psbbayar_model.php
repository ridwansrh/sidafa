<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class PsbBayar_model extends CI_Model
{
	/**
     * This function is used to get the PsbBayar listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function PsbBayarListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_pendaftaran, BaseTbl.nisn, BaseTbl.nama, BaseTbl.tmp_lahir, BaseTbl.tgl_lahir, GD.kd_gender, BaseTbl.desa, BaseTbl.dukuh, BaseTbl.rt, BaseTbl.rw, JR.nama_jurusan, BaseTbl.nama_sekolah_asal');
        $this->db->from('tbl_psb_siswa as BaseTbl');
        $this->db->join('tbl_gender as GD', 'GD.id_gender = BaseTbl.id_gender','left');
        $this->db->join('tbl_jurusan as JR', 'JR.id_jurusan = BaseTbl.id_jurusan', 'left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the PsbSiswa listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function PsbBayarList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_pendaftaran, BaseTbl.nisn, BaseTbl.nama, BaseTbl.tmp_lahir, BaseTbl.tgl_lahir, GD.kd_gender, BaseTbl.desa, BaseTbl.dukuh, BaseTbl.rt, BaseTbl.rw, JR.nama_jurusan, BaseTbl.nama_sekolah_asal');
        $this->db->from('tbl_psb_siswa as BaseTbl');
        $this->db->join('tbl_gender as GD', 'GD.id_gender = BaseTbl.id_gender','left');
        $this->db->join('tbl_jurusan as JR', 'JR.id_jurusan = BaseTbl.id_jurusan', 'left');
        
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to get the PsbBayar listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function PsbBiayaListBayarCount()
    {
        $this->db->select('BaseTbl.id_biaya_psb, BaseTbl.jenis_biaya, BaseTbl.harga, BaseTbl.id_tahun_pelajaran, BaseTbl.id_kelas');
        $this->db->from('tbl_psb_biaya as BaseTbl');
        $this->db->join('tbl_psb_siswa as Siswa', 'Siswa.tahun_masuk = BaseTbl.id_kelas','left');
        //$this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_tahun_pelajaran as Tapel', 'Tapel.id_tahun_pelajaran = BaseTbl.id_tahun_pelajaran','left');
        //$this->db->join('tbl_kelas as Kelas', 'Kelas.id_kelas = BaseTbl.id_kelas','left');
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 2);
        $this->db->where('BaseTbl.id_kelas = Siswa.tahun_masuk');
        $query = $this->db->get();
        
        return count($query->result());
    }

    /**
     * This function is used to get the PSB Biaya listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function PsbBiayaListBayar($page, $segment)
    {
        $this->db->select('BaseTbl.id_biaya_psb, BaseTbl.jenis_biaya, BaseTbl.harga, BaseTbl.id_kelas');
        $this->db->from('tbl_psb_biaya as BaseTbl');
        $this->db->join('tbl_psb_siswa as Siswa', 'Siswa.tahun_masuk = BaseTbl.id_kelas','left');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_tahun_pelajaran as Tapel', 'Tapel.id_tahun_pelajaran = BaseTbl.id_tahun_pelajaran','left');
        //$this->db->join('tbl_kelas as Kelas', 'Kelas.id_kelas = BaseTbl.id_kelas','left');
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 2);
        $this->db->where('BaseTbl.id_kelas = Siswa.tahun_masuk');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
                 
        $result = $query->result();        
        return $result;
    }

    /**
     * This function used to get PsbSiswa information by id
     * @param number $id_pendaftaran : This is PsbSiswa id
     * @return array $result : This is PsbSiswa information
     */
    function GetPsbSiswaInfo($id_pendaftaran)
    {
        $this->db->select(
            'BaseTbl.id_pendaftaran, 
             BaseTbl.nisn, 
             BaseTbl.nik, 
             BaseTbl.nama, 
             BaseTbl.password, 
             BaseTbl.tmp_lahir, 
             BaseTbl.tgl_lahir,
             BaseTbl.id_gender,
             BaseTbl.tahun_masuk,
             BaseTbl.id_agama,
             BaseTbl.anak_ke,
             BaseTbl.jml_sdr,
             BaseTbl.id_jalur_masuk,
             BaseTbl.id_jurusan,
             BaseTbl.id_pondok,
             BaseTbl.id_jenis_tinggal,
             BaseTbl.desa,
             BaseTbl.dukuh,
             BaseTbl.rt,
             BaseTbl.rw,
             BaseTbl.kecamatan,
             BaseTbl.kabupaten,
             BaseTbl.provinsi,
             BaseTbl.kode_pos,
             BaseTbl.id_jarak,
             BaseTbl.id_transportasi,
             BaseTbl.id_hobi,
             BaseTbl.id_cita_cita,
             BaseTbl.hp_siswa,
             BaseTbl.foto,
             BaseTbl.no_kip,
             BaseTbl.no_kis,
             BaseTbl.no_kartu_lain,
             BaseTbl.id_sekolah_asal,
             BaseTbl.nama_sekolah_asal,
             BaseTbl.alamat_sekolah_asal,
             BaseTbl.no_peserta_ujian,
             BaseTbl.no_ijazah,
             BaseTbl.no_shun,
             BaseTbl.nilai_un,
             BaseTbl.no_shuambn,
             BaseTbl.nilai_uambn,
             BaseTbl.p_smt_empat_gasal,
             BaseTbl.p_smt_empat_genap,
             BaseTbl.p_smt_lima_gasal,
             BaseTbl.p_smt_lima_genap,
             BaseTbl.p_smt_enam_gasal,
             BaseTbl.p_smt_enam_genap,
             BaseTbl.prestasi_satu,
             BaseTbl.prestasi_dua,
             BaseTbl.prestasi_tiga,
             BaseTbl.prestasi_empat,
             BaseTbl.prestasi_lima,
             BaseTbl.prestasi_enam,
             BaseTbl.nama_ayah_kandung,
             BaseTbl.nama_ayah_tiri,
             BaseTbl.nik_ayah,
             BaseTbl.thn_lahir_ayah,
             BaseTbl.id_pendidikan_ayah,
             BaseTbl.id_pekerjaan_ayah,
             BaseTbl.id_penghasilan_ayah,
             BaseTbl.alamat_ayah,
             BaseTbl.hp_ayah,
             BaseTbl.nama_ibu_kandung,
             BaseTbl.nama_ibu_tiri,
             BaseTbl.nik_ibu,
             BaseTbl.thn_lahir_ibu,
             BaseTbl.id_pendidikan_ibu,
             BaseTbl.id_pekerjaan_ibu,
             BaseTbl.id_penghasilan_ibu,
             BaseTbl.alamat_ibu,
             BaseTbl.hp_ibu,
             BaseTbl.nama_wali,
             BaseTbl.nik_wali,
             BaseTbl.thn_lahir_wali,
             BaseTbl.id_pendidikan_wali,
             BaseTbl.id_pekerjaan_wali,
             BaseTbl.id_penghasilan_wali,
             BaseTbl.alamat_wali,
             BaseTbl.hp_wali,
             BaseTbl.isDeleted,
             BaseTbl.CreatedBy,
             BaseTbl.CreatedDate,
             BaseTbl.UpdatedBy,
             BaseTbl.UpdatedDate,
             BaseTbl.ip_akses,
             BaseTbl.sistem_operasi,
             BaseTbl.id_aktif');
        $this->db->from('tbl_psb_siswa as BaseTbl');
        //$this->db->where('isDeleted =', 0);
        //$this->db->where('id_aktif =', 1);
        $this->db->where('id_pendaftaran', $id_pendaftaran);
        $query = $this->db->get();
        
        return $query->result();
    }   

    /**
     * This function is used to add new PSB Biaya to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($psbbayarInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_psb_biaya', $psbbiayaInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get PSB Biaya information by id
     * @param number $id_biaya_psb : This is PSB Biaya id
     * @return array $result : This is PSB Biaya information
     */
    function GetPsbBiayaInfo($id_biaya_psb)
    {
        $this->db->select('id_biaya_psb, jenis_biaya, harga, id_tahun_pelajaran, id_aktif');
        $this->db->from('tbl_psb_biaya');
        $this->db->where('isDeleted', 0);
		$this->db->where('id_aktif !=', 0);
        $this->db->where('id_biaya_psb', $id_biaya_psb);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the PSB Biaya information
     * @param array $psbbiayaInfo : This is PSB Biayas updated information
     * @param number $id_biaya_psb : This is PSB Biaya id
     */
    function EditPsbBiaya($psbbiayaInfo, $id_biaya_psb)
    {
        $this->db->where('id_biaya_psb', $id_biaya_psb);
        $this->db->update('tbl_psb_biaya', $psbbiayaInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the PSB Biaya information
     * @param number $id_biaya_psb : This is PSB Biaya id
     * @return boolean $result : TRUE / FALSE
     */
    function deletePsbBiaya($id_biaya_psb, $psbbiayaInfo)
    {
        $this->db->where('id_biaya_psb', $id_biaya_psb);
        $this->db->update('tbl_psb_biaya', $psbbiayaInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the PSB Biaya roles information
     * @return array $result : This is result of the query
     */
    function getTapel()
    {
        $this->db->select('id_tahun_pelajaran, tahun_pelajaran');
        $this->db->from('tbl_tahun_pelajaran');
        $this->db->where('id_tahun_pelajaran !=' , 0);
        //$this->db->where('id_aktif !=' , 2);
        $this->db->where('isDeleted !=' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PSB Biaya roles information
     * @return array $result : This is result of the query
     */
    function getKelas()
    {
        $this->db->select('id_tahun_pelajaran, tahun_pelajaran');
        $this->db->from('tbl_tahun_pelajaran');
        $this->db->where('id_tahun_pelajaran !=' , 0);
        //$this->db->where('id_aktif !=' , 2);
        $this->db->where('isDeleted !=' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PSB Biaya status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the PSB Biaya roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}