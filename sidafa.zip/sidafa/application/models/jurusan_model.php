<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Jurusan_model extends CI_Model
{
	/**
     * This function is used to get the Jurusan listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function JrsListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_jurusan, BaseTbl.kode_jurusan, BaseTbl.nama_jurusan, Aktif.keaktifan');
        $this->db->from('tbl_jurusan as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.kode_jurusan  LIKE '%".$searchText."%'
                            OR  BaseTbl.nama_jurusan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif =', 1);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the Jurusan listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function JrsList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_jurusan, BaseTbl.kode_jurusan, BaseTbl.nama_jurusan, Aktif.keaktifan');
        $this->db->from('tbl_jurusan as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.kode_jurusan  LIKE '%".$searchText."%'
                            OR  BaseTbl.nama_jurusan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new Jurusan to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($jurusanInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_jurusan', $jurusanInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get Jurusan information by id
     * @param number $id_jurusan : This is Jurusan id
     * @return array $result : This is Jurusan information
     */
    function GetJurusanInfo($id_jurusan)
    {
        $this->db->select('id_jurusan, kode_jurusan, nama_jurusan, id_aktif');
        $this->db->from('tbl_jurusan');
        $this->db->where('isDeleted', 0);
		$this->db->where('id_aktif !=', 0);
        $this->db->where('id_jurusan', $id_jurusan);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the Jurusan information
     * @param array $jurusanInfo : This is Jurusans updated information
     * @param number $id_jurusan : This is Jurusan id
     */
    function EditJurusan($jurusanInfo, $id_jurusan)
    {
        $this->db->where('id_jurusan', $id_jurusan);
        $this->db->update('tbl_jurusan', $jurusanInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the Jurusan information
     * @param number $id_jurusan : This is Jurusan id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteJurusan($id_jurusan, $jurusanInfo)
    {
        $this->db->where('id_jurusan', $id_jurusan);
        $this->db->update('tbl_jurusan', $jurusanInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the Jurusan status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the Jurusan roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}