<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Pembayaran_model extends CI_Model
{
	/**
     * This function is used to get the Pembayaran listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */

	/**
     * This function is used to add new Pembayaran to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($data)
    {
    	//$id_kelas          = $this->input->post('kelas');
        //$id_rombel          = $this->input->post('rombel');
        //$id_pendaftaran     = $this->input->post('siswa');
        //$id_biaya_psb       = $this->input->post('biaya');
        //$jumlah_bayar 		= $this->input->post('jumlah_bayar');
        //$id_tahun_pelajaran = $this->input->post('tapel');
                                                     
        
        $this->db->insert('tbl_psb_harus_bayar',$data);

        if($this->db->affected_rows() > 0){
        return true;
        }

        //$this->db->trans_start();
        
        //$insert_id = $this->db->insert_id();
        
        //$this->db->trans_complete();
        
        //return $insert_id;
    }

    function get_sum(){
        $sql = "SELECT sum(jumlah_bayar) as jumlah FROM tbl_pembayaran where id_siswa=$_GET[siswa] and id_biaya=$_GET[biaya]";
        $result = $this->db->query($sql);
        return $result->row()->jumlah;
    }
    
    /**
     * This function used to get Pembayaran information by id
     * @param number $id_Pembayaran : This is Pembayaran id
     * @return array $result : This is Pembayaran information
     */
    function GetPembayaranInfo($id_pembayaran)
    {
        $this->db->select('BaseTbl.id_pembayaran, 
                           SW.nama,
                           BY.jenis_biaya,
                           BY.harga, 
                           BaseTbl.jumlah_bayar,
                           KLS.nama_kelas,
                           RMB.nama_rombel,
                           BaseTbl.keterangan,
                           BaseTbl.CreatedDate,
                           USR.name,
                           TAPEL.tahun_pelajaran');
        $this->db->from('tbl_pembayaran as BaseTbl');
        $this->db->join('tbl_siswa as SW', 'SW.id_siswa = BaseTbl.id_siswa','left');
        $this->db->join('tbl_biaya as BY', 'BY.id_biaya = BaseTbl.id_biaya','left');
        $this->db->join('tbl_kelas as KLS', 'KLS.id_kelas = BaseTbl.id_kelas','left');
        $this->db->join('tbl_rombel as RMB', 'RMB.id_rombel = BaseTbl.id_rombel','left');
        $this->db->join('tbl_tahun_pelajaran as TAPEL', 'TAPEL.id_tahun_pelajaran = BaseTbl.id_tahun_pelajaran','left');
        $this->db->join('tbl_users as USR', 'USR.userId = BaseTbl.CreatedBy','left');
        //$this->db->where('isDeleted', 0);
		//$this->db->where('id_aktif !=', 0);
        $this->db->where('id_pembayaran', $id_pembayaran);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to delete the Pembayaran information
     * @param number $id_Pembayaran : This is Pembayaran id
     * @return boolean $result : TRUE / FALSE
     */
    function AddPembayaran($data)
    {
        $this->db->insert('tbl_pembayaran',$data);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to process pembayaran
     * @param number $id  : This is Pembayaran id
     * @param number $data: This is Pembayaran data
     */
    function Bayar($data, $id){
    $this->db->where('id_pembayaran',$id);
    $this->db->update('tbl_psb_harus_bayar', $data);
    return TRUE;
	}

    
    /**
     * This function is used to update the Pembayaran information
     * @param array $PembayaranInfo : This is Pembayarans updated information
     * @param number $id_Pembayaran : This is Pembayaran id
     */
    function EditPembayaran($PembayaranInfo, $id_Pembayaran)
    {
        $this->db->where('id_Pembayaran', $id_Pembayaran);
        $this->db->update('tbl_pembayaran', $PembayaranInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the Pembayaran information
     * @param number $id_Pembayaran : This is Pembayaran id
     * @return boolean $result : TRUE / FALSE
     */
    function deletePembayaran($id_pembayaran, $PembayaranInfo)
    {
        $this->db->where('id_pembayaran', $id_pembayaran);
        $this->db->update('tbl_pembayaran', $PembayaranInfo);
        
        return $this->db->affected_rows();
    }
}