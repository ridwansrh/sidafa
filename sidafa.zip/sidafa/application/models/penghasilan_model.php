<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Penghasilan_model extends CI_Model
{
	/**
     * This function is used to get the Penghasilan listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function PenghasilanListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_penghasilan, BaseTbl.penghasilan, BaseTbl.ket_penghasilan, Aktif.keaktifan');
        $this->db->from('tbl_penghasilan as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.penghasilan  LIKE '%".$searchText."%'
                            OR  BaseTbl.ket_penghasilan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the Penghasilan listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function PenghasilanList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_penghasilan, BaseTbl.penghasilan, BaseTbl.ket_penghasilan, Aktif.keaktifan');
        $this->db->from('tbl_penghasilan as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.penghasilan  LIKE '%".$searchText."%'
                            OR  BaseTbl.ket_penghasilan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new Penghasilan to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($penghasilanInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_penghasilan', $penghasilanInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get Penghasilan information by id
     * @param number $id_penghasilan : This is Penghasilan id
     * @return array $result : This is Penghasilan information
     */
    function GetPenghasilanInfo($id_penghasilan)
    {
        $this->db->select('id_penghasilan, penghasilan, ket_penghasilan, id_aktif');
        $this->db->from('tbl_penghasilan');
        $this->db->where('isDeleted', 0);
		$this->db->where('id_aktif !=', 0);
        $this->db->where('id_penghasilan', $id_penghasilan);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the Penghasilan information
     * @param array $penghasilanInfo : This is Penghasilans updated information
     * @param number $id_penghasilan : This is Penghasilan id
     */
    function EditPenghasilan($penghasilanInfo, $id_penghasilan)
    {
        $this->db->where('id_penghasilan', $id_penghasilan);
        $this->db->update('tbl_penghasilan', $penghasilanInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the Penghasilan information
     * @param number $id_penghasilan : This is Penghasilan id
     * @return boolean $result : TRUE / FALSE
     */
    function deletePenghasilan($id_penghasilan, $penghasilanInfo)
    {
        $this->db->where('id_penghasilan', $id_penghasilan);
        $this->db->update('tbl_penghasilan', $penghasilanInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the Penghasilan status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the Penghasilan roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}