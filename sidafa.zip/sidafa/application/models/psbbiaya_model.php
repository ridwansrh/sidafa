<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class PsbBiaya_model extends CI_Model
{
	/**
     * This function is used to get the PsbBiaya listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function PsbBiayaListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_biaya_psb, BaseTbl.jenis_biaya, BaseTbl.harga, Tapel.tahun_pelajaran, Kelas.nama_kelas, Aktif.keaktifan');
        $this->db->from('tbl_psb_biaya as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        $this->db->join('tbl_tahun_pelajaran as Tapel', 'Tapel.id_tahun_pelajaran = BaseTbl.id_tahun_pelajaran','left');
        $this->db->join('tbl_kelas as Kelas', 'Kelas.id_kelas = BaseTbl.id_kelas','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.jenis_biaya  LIKE '%".$searchText."%'
                            OR  BaseTbl.harga  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the PSB Biaya listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function PsbBiayaList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_biaya_psb, BaseTbl.jenis_biaya, BaseTbl.harga, Tapel.tahun_pelajaran, Kelas.nama_kelas, Aktif.keaktifan');
        $this->db->from('tbl_psb_biaya as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        $this->db->join('tbl_tahun_pelajaran as Tapel', 'Tapel.id_tahun_pelajaran = BaseTbl.id_tahun_pelajaran','left');
        $this->db->join('tbl_kelas as Kelas', 'Kelas.id_kelas = BaseTbl.id_kelas','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.jenis_biaya  LIKE '%".$searchText."%'
                            OR  BaseTbl.harga  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new PSB Biaya to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($psbbiayaInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_psb_biaya', $psbbiayaInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get PSB Biaya information by id
     * @param number $id_biaya_psb : This is PSB Biaya id
     * @return array $result : This is PSB Biaya information
     */
    function GetPsbBiayaInfo($id_biaya_psb)
    {
        $this->db->select('id_biaya_psb, jenis_biaya, harga, id_tahun_pelajaran, id_kelas, id_aktif');
        $this->db->from('tbl_psb_biaya');
        $this->db->where('isDeleted', 0);
		$this->db->where('id_aktif !=', 0);
        $this->db->where('id_biaya_psb', $id_biaya_psb);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the PSB Biaya information
     * @param array $psbbiayaInfo : This is PSB Biayas updated information
     * @param number $id_biaya_psb : This is PSB Biaya id
     */
    function EditPsbBiaya($psbbiayaInfo, $id_biaya_psb)
    {
        $this->db->where('id_biaya_psb', $id_biaya_psb);
        $this->db->update('tbl_psb_biaya', $psbbiayaInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the PSB Biaya information
     * @param number $id_biaya_psb : This is PSB Biaya id
     * @return boolean $result : TRUE / FALSE
     */
    function deletePsbBiaya($id_biaya_psb, $psbbiayaInfo)
    {
        $this->db->where('id_biaya_psb', $id_biaya_psb);
        $this->db->update('tbl_psb_biaya', $psbbiayaInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the PSB Biaya roles information
     * @return array $result : This is result of the query
     */
    function getTapel()
    {
        $this->db->select('id_tahun_pelajaran, tahun_pelajaran');
        $this->db->from('tbl_tahun_pelajaran');
        $this->db->where('id_tahun_pelajaran !=' , 0);
        //$this->db->where('id_aktif !=' , 2);
        $this->db->where('isDeleted !=' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PSB Biaya roles information
     * @return array $result : This is result of the query
     */
    function getKelas()
    {
        $this->db->select('id_kelas, nama_kelas');
        $this->db->from('tbl_kelas');
        $this->db->where('id_kelas !=' , 0);
        $this->db->where('id_aktif !=' , 2);
        $this->db->where('isDeleted !=' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PSB Biaya status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the PSB Biaya roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}