<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Hobi_model extends CI_Model
{
	/**
     * This function is used to get the Hobi listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function HobiListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_hobi, BaseTbl.nama_hobi, BaseTbl.ket_hobi, Aktif.keaktifan');
        $this->db->from('tbl_hobi as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.nama_hobi  LIKE '%".$searchText."%'
                            OR  BaseTbl.ket_hobi  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the hobi listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function HobiList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_hobi, BaseTbl.nama_hobi, BaseTbl.ket_hobi, Aktif.keaktifan');
        $this->db->from('tbl_hobi as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.nama_hobi  LIKE '%".$searchText."%'
                            OR  BaseTbl.ket_hobi  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new hobi to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($hobiInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_hobi', $hobiInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get hobi information by id
     * @param number $id_hobi : This is hobi id
     * @return array $result : This is hobi information
     */
    function GetHobiInfo($id_hobi)
    {
        $this->db->select('id_hobi, nama_hobi, ket_hobi, id_aktif');
        $this->db->from('tbl_hobi');
        $this->db->where('isDeleted', 0);
		$this->db->where('id_aktif !=', 0);
        $this->db->where('id_hobi', $id_hobi);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the hobi information
     * @param array $hobiInfo : This is hobis updated information
     * @param number $id_hobi : This is hobi id
     */
    function EditHobi($hobiInfo, $id_hobi)
    {
        $this->db->where('id_hobi', $id_hobi);
        $this->db->update('tbl_hobi', $hobiInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the hobi information
     * @param number $id_hobi : This is hobi id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteHobi($id_hobi, $hobiInfo)
    {
        $this->db->where('id_hobi', $id_hobi);
        $this->db->update('tbl_hobi', $hobiInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the hobi status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the hobi roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}