<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Transportasi_model extends CI_Model
{
	/**
     * This function is used to get the Transportasi listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function TransportasiListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_transportasi, BaseTbl.transportasi, Aktif.keaktifan');
        $this->db->from('tbl_transportasi as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.transportasi  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the Transportasi listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function TransportasiList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_transportasi, BaseTbl.transportasi, Aktif.keaktifan');
        $this->db->from('tbl_transportasi as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.transportasi  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new Transportasi to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($transportasiInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_transportasi', $transportasiInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get Transportasi information by id
     * @param number $id_transportasi : This is Transportasi id
     * @return array $result : This is Transportasi information
     */
    function GetTransportasiInfo($id_transportasi)
    {
        $this->db->select('id_transportasi, transportasi, , id_aktif');
        $this->db->from('tbl_transportasi');
        $this->db->where('isDeleted', 0);
		$this->db->where('id_aktif !=', 0);
        $this->db->where('id_transportasi', $id_transportasi);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the Transportasi information
     * @param array $transportasiInfo : This is Transportasis updated information
     * @param number $id_transportasi : This is Transportasi id
     */
    function EditTransportasi($transportasiInfo, $id_transportasi)
    {
        $this->db->where('id_transportasi', $id_transportasi);
        $this->db->update('tbl_transportasi', $transportasiInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the Transportasi information
     * @param number $id_transportasi : This is Transportasi id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteTransportasi($id_transportasi, $transportasiInfo)
    {
        $this->db->where('id_transportasi', $id_transportasi);
        $this->db->update('tbl_transportasi', $transportasiInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the Transportasi status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the Transportasi roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}