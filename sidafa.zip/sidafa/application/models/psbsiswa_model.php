<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class PsbSiswa_model extends CI_Model
{
	/**
     * This function is used to get the PsbSiswa listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function PsbSiswaListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_pendaftaran, BaseTbl.nisn, BaseTbl.nama, BaseTbl.tmp_lahir, BaseTbl.tgl_lahir, GD.kd_gender, BaseTbl.desa, BaseTbl.dukuh, BaseTbl.rt, BaseTbl.rw, JR.nama_jurusan, BaseTbl.nama_sekolah_asal');
        $this->db->from('tbl_psb_siswa as BaseTbl');
        $this->db->join('tbl_gender as GD', 'GD.id_gender = BaseTbl.id_gender','left');
        $this->db->join('tbl_jurusan as JR', 'JR.id_jurusan = BaseTbl.id_jurusan', 'left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the PsbSiswa listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function PsbSiswaList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_pendaftaran, BaseTbl.nisn, BaseTbl.nama, BaseTbl.tmp_lahir, BaseTbl.tgl_lahir, GD.kd_gender, BaseTbl.desa, BaseTbl.dukuh, BaseTbl.rt, BaseTbl.rw, JR.nama_jurusan, BaseTbl.nama_sekolah_asal');
        $this->db->from('tbl_psb_siswa as BaseTbl');
        $this->db->join('tbl_gender as GD', 'GD.id_gender = BaseTbl.id_gender','left');
        $this->db->join('tbl_jurusan as JR', 'JR.id_jurusan = BaseTbl.id_jurusan', 'left');
        
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new PsbSiswa to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($psbsiswaInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_psb_siswa', $psbsiswaInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get PsbSiswa information by id
     * @param number $id_pendaftaran : This is PsbSiswa id
     * @return array $result : This is PsbSiswa information
     */
    function GetPsbSiswaInfo($id_pendaftaran)
    {
        $this->db->select(
            'BaseTbl.id_pendaftaran, 
             BaseTbl.nisn, 
             BaseTbl.nik, 
             BaseTbl.nama, 
             BaseTbl.password, 
             BaseTbl.tmp_lahir, 
             BaseTbl.tgl_lahir,
             BaseTbl.id_gender,
             BaseTbl.tahun_masuk,
             BaseTbl.id_agama,
             BaseTbl.anak_ke,
             BaseTbl.jml_sdr,
             BaseTbl.id_jalur_masuk,
             BaseTbl.id_jurusan,
             BaseTbl.id_pondok,
             BaseTbl.id_jenis_tinggal,
             BaseTbl.desa,
             BaseTbl.dukuh,
             BaseTbl.rt,
             BaseTbl.rw,
             BaseTbl.kecamatan,
             BaseTbl.kabupaten,
             BaseTbl.provinsi,
             BaseTbl.kode_pos,
             BaseTbl.id_jarak,
             BaseTbl.id_transportasi,
             BaseTbl.id_hobi,
             BaseTbl.id_cita_cita,
             BaseTbl.hp_siswa,
             BaseTbl.foto,
             BaseTbl.no_kip,
             BaseTbl.no_kis,
             BaseTbl.no_kartu_lain,
             BaseTbl.id_sekolah_asal,
             BaseTbl.nama_sekolah_asal,
             BaseTbl.alamat_sekolah_asal,
             BaseTbl.no_peserta_ujian,
             BaseTbl.no_ijazah,
             BaseTbl.no_shun,
             BaseTbl.nilai_un,
             BaseTbl.no_shuambn,
             BaseTbl.nilai_uambn,
             BaseTbl.p_smt_empat_gasal,
             BaseTbl.p_smt_empat_genap,
             BaseTbl.p_smt_lima_gasal,
             BaseTbl.p_smt_lima_genap,
             BaseTbl.p_smt_enam_gasal,
             BaseTbl.p_smt_enam_genap,
             BaseTbl.prestasi_satu,
             BaseTbl.prestasi_dua,
             BaseTbl.prestasi_tiga,
             BaseTbl.prestasi_empat,
             BaseTbl.prestasi_lima,
             BaseTbl.prestasi_enam,
             BaseTbl.nama_ayah_kandung,
             BaseTbl.nama_ayah_tiri,
             BaseTbl.nik_ayah,
             BaseTbl.thn_lahir_ayah,
             BaseTbl.id_pendidikan_ayah,
             BaseTbl.id_pekerjaan_ayah,
             BaseTbl.id_penghasilan_ayah,
             BaseTbl.alamat_ayah,
             BaseTbl.hp_ayah,
             BaseTbl.nama_ibu_kandung,
             BaseTbl.nama_ibu_tiri,
             BaseTbl.nik_ibu,
             BaseTbl.thn_lahir_ibu,
             BaseTbl.id_pendidikan_ibu,
             BaseTbl.id_pekerjaan_ibu,
             BaseTbl.id_penghasilan_ibu,
             BaseTbl.alamat_ibu,
             BaseTbl.hp_ibu,
             BaseTbl.nama_wali,
             BaseTbl.nik_wali,
             BaseTbl.thn_lahir_wali,
             BaseTbl.id_pendidikan_wali,
             BaseTbl.id_pekerjaan_wali,
             BaseTbl.id_penghasilan_wali,
             BaseTbl.alamat_wali,
             BaseTbl.hp_wali,
             BaseTbl.isDeleted,
             BaseTbl.CreatedBy,
             BaseTbl.CreatedDate,
             BaseTbl.UpdatedBy,
             BaseTbl.UpdatedDate,
             BaseTbl.ip_akses,
             BaseTbl.sistem_operasi,
             BaseTbl.id_aktif');
        $this->db->from('tbl_psb_siswa as BaseTbl');
        //$this->db->where('isDeleted =', 0);
		//$this->db->where('id_aktif =', 1);
        $this->db->where('id_pendaftaran', $id_pendaftaran);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function used to get PsbSiswa detail information by id
     * @param number $id_pendaftaran : This is PsbSiswa id
     * @return array $result : This is PsbSiswa information
     */
    function GetPsbSiswaInfoDetail($id_pendaftaran)
    {
        $this->db->select(
            'BaseTbl.id_pendaftaran, 
             BaseTbl.nisn, 
             BaseTbl.nik, 
             BaseTbl.nama, 
             BaseTbl.password, 
             BaseTbl.tmp_lahir, 
             BaseTbl.tgl_lahir,
             GD.gender,
             BaseTbl.tahun_masuk,
             AG.agama,
             BaseTbl.anak_ke,
             BaseTbl.jml_sdr,
             JM.jalur_masuk,
             JR.nama_jurusan,
             PD.nama_pondok,
             JT.jenis_tinggal,
             BaseTbl.desa,
             BaseTbl.dukuh,
             BaseTbl.rt,
             BaseTbl.rw,
             BaseTbl.kecamatan,
             BaseTbl.kabupaten,
             BaseTbl.provinsi,
             BaseTbl.kode_pos,
             JAR.jarak_tinggal,
             TR.transportasi,
             HB.nama_hobi,
             CT.nama_cita_cita,
             BaseTbl.hp_siswa,
             BaseTbl.foto,
             BaseTbl.no_kip,
             BaseTbl.no_kis,
             BaseTbl.no_kartu_lain,
             SA.sekolah_asal,
             BaseTbl.nama_sekolah_asal,
             BaseTbl.alamat_sekolah_asal,
             BaseTbl.no_peserta_ujian,
             BaseTbl.no_ijazah,
             BaseTbl.no_shun,
             BaseTbl.nilai_un,
             BaseTbl.no_shuambn,
             BaseTbl.nilai_uambn,
             BaseTbl.p_smt_empat_gasal,
             BaseTbl.p_smt_empat_genap,
             BaseTbl.p_smt_lima_gasal,
             BaseTbl.p_smt_lima_genap,
             BaseTbl.p_smt_enam_gasal,
             BaseTbl.p_smt_enam_genap,
             BaseTbl.prestasi_satu,
             BaseTbl.prestasi_dua,
             BaseTbl.prestasi_tiga,
             BaseTbl.prestasi_empat,
             BaseTbl.prestasi_lima,
             BaseTbl.prestasi_enam,
             BaseTbl.nama_ayah_kandung,
             BaseTbl.nama_ayah_tiri,
             BaseTbl.nik_ayah,
             BaseTbl.thn_lahir_ayah,
             PDK.pendidikan_terakhir,
             PKR.pekerjaan,
             PHS.penghasilan,
             BaseTbl.alamat_ayah,
             BaseTbl.hp_ayah,
             BaseTbl.nama_ibu_kandung,
             BaseTbl.nama_ibu_tiri,
             BaseTbl.nik_ibu,
             BaseTbl.thn_lahir_ibu,
             PDK.pendidikan_terakhir,
             PKR.pekerjaan,
             PHS.penghasilan,
             BaseTbl.alamat_ibu,
             BaseTbl.hp_ibu,
             BaseTbl.nama_wali,
             BaseTbl.nik_wali,
             BaseTbl.thn_lahir_wali,
             PDK.pendidikan_terakhir,
             PKR.pekerjaan,
             PHS.penghasilan,
             BaseTbl.alamat_wali,
             BaseTbl.hp_wali,
             BaseTbl.isDeleted,
             BaseTbl.CreatedBy,
             BaseTbl.CreatedDate,
             BaseTbl.UpdatedBy,
             BaseTbl.UpdatedDate,
             BaseTbl.ip_akses,
             BaseTbl.sistem_operasi,
             AKT.keaktifan');
        $this->db->from('tbl_psb_siswa as BaseTbl');
        $this->db->join('tbl_gender as GD', 'GD.id_gender = BaseTbl.id_gender','left');
        $this->db->join('tbl_agama as AG', 'AG.id_agama = BaseTbl.id_agama','left');
        $this->db->join('tbl_jalur_masuk as JM', 'JM.id_jalur_masuk = BaseTbl.id_jalur_masuk','left');
        $this->db->join('tbl_jurusan as JR', 'JR.id_jurusan = BaseTbl.id_jurusan', 'left');
        $this->db->join('tbl_pondok as PD', 'PD.id_pondok = BaseTbl.id_pondok','left');
        $this->db->join('tbl_jenis_tinggal as JT', 'JT.id_jenis_tinggal = BaseTbl.id_jenis_tinggal','left');
        $this->db->join('tbl_jarak_tinggal as JAR', 'JAR.id_jarak = BaseTbl.id_jarak','left');
        $this->db->join('tbl_transportasi as TR', 'TR.id_transportasi = BaseTbl.id_transportasi','left');
        $this->db->join('tbl_hobi as HB', 'HB.id_hobi = BaseTbl.id_hobi','left');
        $this->db->join('tbl_cita_cita as CT', 'CT.id_cita_cita = BaseTbl.id_cita_cita','left');
        $this->db->join('tbl_sekolah_asal as SA', 'SA.id_sekolah_asal = BaseTbl.id_sekolah_asal','left');
        $this->db->join('tbl_pendidikan_terakhir as PDK', 'PDK.id_pendidikan_terakhir = BaseTbl.id_pendidikan_ayah','PDK.id_pendidikan_terakhir = BaseTbl.id_pendidikan_ibu', 'left');
        $this->db->join('tbl_pekerjaan as PKR', 'PKR.id_pekerjaan = BaseTbl.id_pekerjaan_ayah','left');
        $this->db->join('tbl_penghasilan as PHS', 'PHS.id_penghasilan = BaseTbl.id_penghasilan_ayah','left');
        $this->db->join('tbl_keaktifan as AKT', 'AKT.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->where('isDeleted =', 0);
        //$this->db->where('id_aktif =', 1);
        $this->db->where('id_pendaftaran', $id_pendaftaran);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the PsbSiswa information
     * @param array $psbsiswaInfo : This is PsbSiswas updated information
     * @param number $id_pendaftaran : This is PsbSiswa id
     */
    function EditPsbSiswa($psbsiswaInfo, $id_pendaftaran)
    {
        $this->db->where('id_pendaftaran', $id_pendaftaran);
        $this->db->update('tbl_psb_siswa', $psbsiswaInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the PsbSiswa information
     * @param number $id_pendaftaran : This is PsbSiswa id
     * @return boolean $result : TRUE / FALSE
     */
    function deletePsbSiswa($id_pendaftaran, $psbsiswaInfo)
    {
        $this->db->where('id_pendaftaran', $id_pendaftaran);
        $this->db->update('tbl_psb_siswa', $psbsiswaInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the PsbSiswa status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa gender information
     * @return array $result : This is result of the query
     */
    function getGender()
    {
        $this->db->select('id_gender, gender');
        $this->db->from('tbl_gender');
        //$this->db->where('id_gender !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa agama information
     * @return array $result : This is result of the query
     */
    function getAgama()
    {
        $this->db->select('id_agama, agama');
        $this->db->from('tbl_agama');
        //$this->db->where('id_agama !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa JalurMasuk information
     * @return array $result : This is result of the query
     */
    function getJalurMasuk()
    {
        $this->db->select('id_jalur_masuk, jalur_masuk');
        $this->db->from('tbl_jalur_masuk');
        $this->db->where('isDeleted =' , 0);
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa Jurusan information
     * @return array $result : This is result of the query
     */
    function getJurusan()
    {
        $this->db->select('id_jurusan, nama_jurusan');
        $this->db->from('tbl_jurusan');
        $this->db->where('isDeleted =' , 0);
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa pondok information
     * @return array $result : This is result of the query
     */
    function getPondok()
    {
        $this->db->select('id_pondok, nama_pondok');
        $this->db->from('tbl_pondok');
        $this->db->where('isDeleted =' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa Jenis Tinggal information
     * @return array $result : This is result of the query
     */
    function getJenisTinggal()
    {
        $this->db->select('id_jenis_tinggal, jenis_tinggal');
        $this->db->from('tbl_jenis_tinggal');
        //$this->db->where('isDeleted !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa Jarak Tinggal information
     * @return array $result : This is result of the query
     */
    function getJarakTinggal()
    {
        $this->db->select('id_jarak, jarak_tinggal');
        $this->db->from('tbl_jarak_tinggal');
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa Transportasi information
     * @return array $result : This is result of the query
     */
    function getTransportasi()
    {
        $this->db->select('id_transportasi, transportasi');
        $this->db->from('tbl_transportasi');
        $this->db->where('isDeleted =' , 0);
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa Hobi information
     * @return array $result : This is result of the query
     */
    function getHobi()
    {
        $this->db->select('id_hobi, nama_hobi');
        $this->db->from('tbl_hobi');
        $this->db->where('isDeleted =' , 0);
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa CitaCita information
     * @return array $result : This is result of the query
     */
    function getCitaCita()
    {
        $this->db->select('id_cita_cita, nama_cita_cita');
        $this->db->from('tbl_cita_cita');
        $this->db->where('isDeleted =' , 0);
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa SekolahAsal information
     * @return array $result : This is result of the query
     */
    function getSekolahAsal()
    {
        $this->db->select('id_sekolah_asal, sekolah_asal');
        $this->db->from('tbl_sekolah_asal');
        //$this->db->where('isDeleted =' , 0);
        //$this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa Pendidikan Terakhir information
     * @return array $result : This is result of the query
     */
    function getPendidikanTerakhir()
    {
        $this->db->select('id_pendidikan_terakhir, pendidikan_terakhir');
        $this->db->from('tbl_pendidikan_terakhir');
        $this->db->where('isDeleted =' , 0);
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa Pekerjaan information
     * @return array $result : This is result of the query
     */
    function getPekerjaan()
    {
        $this->db->select('id_pekerjaan, pekerjaan');
        $this->db->from('tbl_pekerjaan');
        $this->db->where('isDeleted =' , 0);
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to get the PsbSiswa Penghasilan information
     * @return array $result : This is result of the query
     */
    function getPenghasilan()
    {
        $this->db->select('id_penghasilan, penghasilan');
        $this->db->from('tbl_penghasilan');
        $this->db->where('isDeleted =' , 0);
        $this->db->where('id_aktif =' , 1);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the PsbSiswa roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}