<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Pekerjaan_model extends CI_Model
{
	/**
     * This function is used to get the Pekerjaan listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function PekerjaanListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_pekerjaan, BaseTbl.pekerjaan, BaseTbl.ket_pekerjaan, Aktif.keaktifan');
        $this->db->from('tbl_pekerjaan as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.pekerjaan  LIKE '%".$searchText."%'
                            OR  BaseTbl.ket_pekerjaan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the Pekerjaan listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function PekerjaanList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_pekerjaan, BaseTbl.pekerjaan, BaseTbl.ket_pekerjaan, Aktif.keaktifan');
        $this->db->from('tbl_pekerjaan as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.pekerjaan  LIKE '%".$searchText."%'
                            OR  BaseTbl.ket_pekerjaan  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new Pekerjaan to system
     * @return number $insert_id : This is last inserted id
     */
    function AddNew($pekerjaanInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_pekerjaan', $pekerjaanInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get Pekerjaan information by id
     * @param number $id_pekerjaan : This is Pekerjaan id
     * @return array $result : This is Pekerjaan information
     */
    function GetPekerjaanInfo($id_pekerjaan)
    {
        $this->db->select('id_pekerjaan, pekerjaan, ket_pekerjaan, id_aktif');
        $this->db->from('tbl_pekerjaan');
        $this->db->where('isDeleted', 0);
		$this->db->where('id_aktif !=', 0);
        $this->db->where('id_pekerjaan', $id_pekerjaan);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the Pekerjaan information
     * @param array $pekerjaanInfo : This is Pekerjaans updated information
     * @param number $id_pekerjaan : This is Pekerjaan id
     */
    function EditPekerjaan($pekerjaanInfo, $id_pekerjaan)
    {
        $this->db->where('id_pekerjaan', $id_pekerjaan);
        $this->db->update('tbl_pekerjaan', $pekerjaanInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the Pekerjaan information
     * @param number $id_pekerjaan : This is Pekerjaan id
     * @return boolean $result : TRUE / FALSE
     */
    function deletePekerjaan($id_pekerjaan, $pekerjaanInfo)
    {
        $this->db->where('id_pekerjaan', $id_pekerjaan);
        $this->db->update('tbl_pekerjaan', $pekerjaanInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the Pekerjaan status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the Pekerjaan roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}