<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class TahunPelajaran_model extends CI_Model
{
	/**
     * This function is used to get the Tahun Pelajaran listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function TPListCount($searchText = '')
    {
        $this->db->select('BaseTbl.id_tahun_pelajaran, BaseTbl.tahun_pelajaran, BaseTbl.ket_tahun_pelajaran, Aktif.keaktifan');
        $this->db->from('tbl_tahun_pelajaran as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.tahun_pelajaran  LIKE '%".$searchText."%'
                            OR  BaseTbl.ket_tahun_pelajaran  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1); 
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the Tahun Pelajaran listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function TPList($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id_tahun_pelajaran, BaseTbl.tahun_pelajaran, BaseTbl.ket_tahun_pelajaran, Aktif.keaktifan');
        $this->db->from('tbl_tahun_pelajaran as BaseTbl');
        $this->db->join('tbl_keaktifan as Aktif', 'Aktif.id_aktif = BaseTbl.id_aktif','left');
        //$this->db->join('tbl_roles as Role', 'Role.roleId = BaseTbl.roleId','left');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.tahun_pelajaran  LIKE '%".$searchText."%'
                            OR  BaseTbl.ket_tahun_pelajaran  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->where('BaseTbl.id_aktif !=', 0);
        //$this->db->where('BaseTbl.roleId !=', 1);
        //$this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new Tahun Pelajaran to system
     * @return number $insert_id : This is last inserted id
     */
    function addData($tpInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_tahun_pelajaran', $tpInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get Tahun Pelajaran information by id
     * @param number $id_tahun_pelajaran : This is Tahun Pelajaran ID
     * @return array $result : This is Tahun Pelajaran information
     */
    function gettpInfo($id_tahun_pelajaran)
    {
        $this->db->select('id_tahun_pelajaran, tahun_pelajaran, ket_tahun_pelajaran, id_aktif');
        $this->db->from('tbl_tahun_pelajaran');
        $this->db->where('isDeleted', 0);
        $this->db->where('id_aktif !=', 0);
		//$this->db->where('roleId !=', 1);
        $this->db->where('id_tahun_pelajaran', $id_tahun_pelajaran);
        $query = $this->db->get();
        
        return $query->result();
    }

    
    /**
     * This function is used to update the Tahun Pelajaran information
     * @param array $tpInfo : This is Tahun Pelajaran updated information
     * @param number $id_tahun_pelajaran : This is Tahun Pelajaran ID
     */
    function editData($tpInfo, $id_tahun_pelajaran)
    {
        $this->db->where('id_tahun_pelajaran', $id_tahun_pelajaran);
        $this->db->update('tbl_tahun_pelajaran', $tpInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the Tahun Pelajaran information
     * @param number $id_tahun_pelajaran : This is Tahun Pelajaran ID
     * @return boolean $result : TRUE / FALSE 
     */
    function deleteTP($id_tahun_pelajaran, $tpInfo)
    {
        $this->db->where('id_tahun_pelajaran', $id_tahun_pelajaran);
        $this->db->update('tbl_tahun_pelajaran', $tpInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get the hobi status information
     * @return array $result : This is result of the query
     */
    function getKeaktifan()
    {
        $this->db->select('id_aktif, keaktifan');
        $this->db->from('tbl_keaktifan');
        $this->db->where('id_aktif !=' , 0);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    /**
     * This function is used to get the Tahun Pelajaran roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('tbl_roles');
        //$this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
}