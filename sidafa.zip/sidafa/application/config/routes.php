<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "login";
$route['404_override'] = 'error';


/*********** USER DEFINED ROUTES *******************/

$route['loginMe'] = 'login/loginMe';
$route['dashboard'] = 'user';
$route['logout'] = 'user/logout';
$route['userListing'] = 'user/userListing';
$route['userListing/(:num)'] = "user/userListing/$1";
$route['addNew'] = "user/addNew";

$route['addNewUser'] = "user/addNewUser";
$route['editOld'] = "user/editOld";
$route['editOld/(:num)'] = "user/editOld/$1";
$route['editUser'] = "user/editUser";
$route['deleteUser'] = "user/deleteUser";
$route['loadChangePass'] = "user/loadChangePass";
$route['changePassword'] = "user/changePassword";
$route['pageNotFound'] = "user/pageNotFound";
$route['checkEmailExists'] = "user/checkEmailExists";

$route['forgotPassword'] = "login/forgotPassword";
$route['resetPasswordUser'] = "login/resetPasswordUser";
$route['resetPasswordConfirmUser'] = "login/resetPasswordConfirmUser";
$route['resetPasswordConfirmUser/(:any)'] = "login/resetPasswordConfirmUser/$1";
$route['resetPasswordConfirmUser/(:any)/(:any)'] = "login/resetPasswordConfirmUser/$1/$2";
$route['createPasswordUser'] = "login/createPasswordUser";

// routing for Profile Madrasah
$route['profile'] = 'profile';
$route['profileListing'] = 'profile/profileListing';
$route['profileListing/(:num)'] = "profile/profileListing/$1";
$route['addP'] = "profile/addNew";
$route['addNewProfile'] = "profile/addNewProfile";
$route['editP'] = "profile/edit";
$route['editP/(:num)'] = "profile/edit/$1";
$route['editProfile'] = "profile/editProfile";
$route['deleteProfile'] = "profile/deleteProfile";

// routing for Tahun Pelajaran
$route['tahunpelajaran'] = 'tahunpelajaran';
$route['TPList'] = 'tahunpelajaran/TPList';
$route['TPList/(:num)'] = "tahunpelajaran/TPList/$1";
$route['addData'] = "tahunpelajaran/addData";
$route['AddNew'] = "tahunpelajaran/addNew";
$route['EditTP'] = "tahunpelajaran/edit";
$route['EditTP/(:num)'] = "tahunpelajaran/edit/$1";
$route['editData'] = "tahunpelajaran/editData";
$route['deleteTP'] = "tahunpelajaran/deleteTP";

// routing for Hobi
$route['hobi'] = 'Hobi';
$route['list-hobi'] = 'Hobi/HobiList';
$route['list-hobi/(:num)'] = "Hobi/HobiList/$1";
$route['add-new-hobi'] = "Hobi/AddNew";
$route['add-data-hobi'] = "Hobi/AddData";
$route['edit-hobi'] = "Hobi/Edit";
$route['edit-hobi/(:num)'] = "Hobi/Edit/$1";
$route['edit-data-hobi'] = "Hobi/EditData";
$route['deleteHobi'] = "Hobi/deleteHobi";

// routing for Jurusan
$route['jurusan'] = 'jurusan';
$route['list-jurusan'] = 'jurusan/JrsList';
$route['list-jurusan/(:num)'] = "jurusan/JrsList/$1";
$route['add-new-jurusan'] = "jurusan/addNew";
$route['add-data-jurusan'] = "jurusan/AddData";
$route['edit-jurusan'] = "jurusan/Edit";
$route['edit-jurusan/(:num)'] = "jurusan/Edit/$1";
$route['edit-data-jurusan'] = "jurusan/EditData";
$route['deleteJurusan'] = "jurusan/deleteJurusan";

// routing for Cita - Cita
$route['citacita'] = 'citacita';
$route['list-citacita'] = 'citacita/CitaList';
$route['list-citacita/(:num)'] = "citacita/CitaList/$1";
$route['add-new-citacita'] = "citacita/addNew";
$route['add-data-citacita'] = "citacita/AddData";
$route['edit-citacita'] = "citacita/Edit";
$route['edit-citacita/(:num)'] = "citacita/Edit/$1";
$route['edit-data-citacita'] = "citacita/EditData";
$route['deleteCitacita'] = "citacita/deleteCitacita";

// routing for Pondok
$route['pondok'] = 'pondok';
$route['list-pondok'] = 'pondok/PondokList';
$route['list-pondok/(:num)'] = "pondok/PondokList/$1";
$route['add-new-pondok'] = "pondok/addNew";
$route['add-data-pondok'] = "pondok/AddData";
$route['edit-pondok'] = "pondok/Edit";
$route['edit-pondok/(:num)'] = "pondok/Edit/$1";
$route['edit-data-pondok'] = "pondok/EditData";
$route['deletePondok'] = "pondok/deletePondok";

// routing for Transportasi
$route['transportasi'] = 'transportasi';
$route['list-transportasi'] = 'transportasi/TransportasiList';
$route['list-transportasi/(:num)'] = "transportasi/TransportasiList/$1";
$route['add-new-transportasi'] = "transportasi/addNew";
$route['add-data-transportasi'] = "transportasi/AddData";
$route['edit-transportasi'] = "transportasi/Edit";
$route['edit-transportasi/(:num)'] = "transportasi/Edit/$1";
$route['edit-data-transportasi'] = "transportasi/EditData";
$route['deleteTransportasi'] = "transportasi/deleteTransportasi";

// routing for Jenis Biaya PSB
$route['psbbiaya'] = 'psbbiaya';
$route['list-biaya-psb'] = 'psbbiaya/PsbBiayaList';
$route['list-biaya-psb/(:num)'] = "psbbiaya/PsbBiayaList/$1";
$route['add-new-biaya-psb'] = "psbbiaya/addNew";
$route['add-data-biaya-psb'] = "psbbiaya/AddData";
$route['edit-biaya-psb'] = "psbbiaya/Edit";
$route['edit-biaya-psb/(:num)'] = "psbbiaya/Edit/$1";
$route['edit-data-biaya-psb'] = "psbbiaya/EditData";
$route['deletePsbBiaya'] = "psbbiaya/deletePsbBiaya";

// routing for Pekerjaan
$route['pekerjaan'] = 'Pekerjaan';
$route['list-pekerjaan'] = 'Pekerjaan/PekerjaanList';
$route['list-pekerjaan/(:num)'] = "Pekerjaan/PekerjaanList/$1";
$route['add-new-pekerjaan'] = "Pekerjaan/AddNew";
$route['add-data-pekerjaan'] = "Pekerjaan/AddData";
$route['edit-pekerjaan'] = "Pekerjaan/Edit";
$route['edit-pekerjaan/(:num)'] = "Pekerjaan/Edit/$1";
$route['edit-data-pekerjaan'] = "Pekerjaan/EditData";
$route['deletePekerjaan'] = "Pekerjaan/deletePekerjaan";

// routing for Penghasilan
$route['penghasilan'] = 'Penghasilan';
$route['list-penghasilan'] = 'Penghasilan/PenghasilanList';
$route['list-penghasilan/(:num)'] = "Penghasilan/PenghasilanList/$1";
$route['add-new-penghasilan'] = "Penghasilan/AddNew";
$route['add-data-penghasilan'] = "Penghasilan/AddData";
$route['edit-penghasilan'] = "Penghasilan/Edit";
$route['edit-penghasilan/(:num)'] = "Penghasilan/Edit/$1";
$route['edit-data-penghasilan'] = "Penghasilan/EditData";
$route['deletePenghasilan'] = "Penghasilan/deletePenghasilan";

// routing for SiswaPSB
$route['siswa-psb'] = 'PsbSiswa';
$route['list-siswa-psb'] = 'PsbSiswa/PsbSiswaList';
$route['list-siswa-psb/(:num)'] = "PsbSiswa/PsbSiswaList/$1";
$route['add-new-siswa-psb'] = "PsbSiswa/AddNew";
$route['add-data-siswa-psb'] = "PsbSiswa/AddData";
$route['edit-siswa-psb'] = "PsbSiswa/Edit";
$route['edit-siswa-psb/(:num)'] = "PsbSiswa/Edit/$1";
$route['edit-data-siswa-psb'] = "PsbSiswa/EditData";
$route['detail-siswa-psb'] = "PsbSiswa/Detail";
$route['detail-siswa-psb/(:num)'] = "PsbSiswa/Detail/$1";
$route['print-siswa-psb'] = "PsbSiswa/Cetak";
$route['print-siswa-psb/(:num)'] = "PsbSiswa/Cetak/$1";
$route['deletePsbSiswa'] = "PsbSiswa/deletePsbSiswa";

//route for pembayaran PSB
$route['pembayaran-psb'] = 'PsbBayar';
$route['list-bayar-psb'] = 'PsbBayar/PsbBayarList';
$route['list-bayar-psb/(:num)'] = "PsbBayar/PsbBayarList/$1";
$route['view-bayar'] = "PsbBayar/ViewBayar";
$route['view-bayar/(:num)'] = "PsbBayar/ViewBayar/$1";
$route['harus-bayar'] = "PsbBayar/dataPSBBayar";

// routing for Jenis Biaya
$route['jenisbiaya'] = 'jenisbiaya';
$route['list-jenisbiaya'] = 'jenisbiaya/JenisbiayaList';
$route['list-jenisbiaya/(:num)'] = "jenisbiaya/JenisbiayaList/$1";
$route['add-new-jenisbiaya'] = "jenisbiaya/addNew";
$route['add-data-jenisbiaya'] = "jenisbiaya/AddData";
$route['edit-jenisbiaya'] = "jenisbiaya/Edit";
$route['edit-jenisbiaya/(:num)'] = "jenisbiaya/Edit/$1";
$route['edit-data-jenisbiaya'] = "jenisbiaya/EditData";
$route['deleteJenisbiaya'] = "jenisbiaya/deleteJenisbiaya";

/* End of file routes.php */
/* Location: ./application/config/routes.php */